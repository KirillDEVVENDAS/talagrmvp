<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package prolancer
 */

get_header();

global $prolancer_opt;

$prolancer_sellers_layout = !empty( $prolancer_opt['prolancer_sellers_layout'] ) ? $prolancer_opt['prolancer_sellers_layout'] : '';

//HTTP GET
if(!empty($_GET['sellers-layout'])){
    $prolancer_sellers_layout = $_GET['sellers-layout'];
}
?>

<section class="section-padding">
	<div class="container">
		<div class="row justify-content-center <?php if ($prolancer_sellers_layout == 'sellers_left_sidebar'){echo'flex-row-reverse';} ?>">
			<div class="search-result <?php if ( is_active_sidebar('seller_archive_widgets') & $prolancer_sellers_layout == 'sellers_left_sidebar' ||  is_active_sidebar('seller_archive_widgets') & $prolancer_sellers_layout == 'sellers_right_sidebar'){ echo'col-xl-8'; } else { echo'col-lg-12'; } ?>">
				<?php
				
				if ( have_posts() ) :
				/* Start the Loop */
				while ( have_posts() ) : the_post();
					do_action( 'get_prolancer_seller_item', 'style-2' );
				endwhile; ?>

					<div class="text-center">
					<?php 
					the_posts_pagination( array(
					    'mid_size'  => 2,
					    'prev_text' => esc_html__( '&#10094; Prev', 'prolancer' ),
					    'next_text' => esc_html__( 'Next &#10095;', 'prolancer' ),
					) ); ?>
					</div>

				<?php

			else :

				get_template_part( 'template-parts/content', 'none' );

			endif;
			?>
			</div>
			<?php if ( is_active_sidebar('seller_archive_widgets') & $prolancer_sellers_layout == 'sellers_left_sidebar' ||  is_active_sidebar('seller_archive_widgets') & $prolancer_sellers_layout == 'sellers_right_sidebar'){ ?>
        		<div class="col-xl-4 position-relative">
        			<aside id="secondary" class="widget-area">
	        			<?php dynamic_sidebar( 'seller_archive_widgets' ); ?>
	        		</aside>
        		</div>
            <?php } ?>
		</div>
	</div>
</section>
<?php get_footer();
