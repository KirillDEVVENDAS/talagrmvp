<div class="container">
	<div class="row">
		<div class="col-sm-12">
			<div class="error-404 white-padding">
				<h1><?php echo esc_html__( 'Oops! That page can’t be found.', 'prolancer' ); ?></h1>
				<p><?php echo esc_html__( 'It looks like nothing was found at this location.', 'prolancer' ); ?></p>
				<a href="<?php if(function_exists('prolancer_get_page_url_by_template')){ echo esc_url(prolancer_get_page_url_by_template('prolancer-dashboard.php'));} if(get_option('permalink_structure')){echo"?";}else{echo"&";} ?>fed=dashboard" class="prolancer-btn"><i class="fal fa-fw fa-home"></i><?php echo esc_html__( 'Dashboard', 'prolancer' ); ?></a>
			</div>
		</div>
	</div>
</div>