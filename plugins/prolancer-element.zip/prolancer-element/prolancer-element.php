<?php
/**
* Plugin Name: ProLancer Element
* Plugin URI: https://github.com/ThemeBing/prolancer-element
* Description: After install the ProLancer WordPress Theme, you must need to install this "ProLancer Element" first to get all functions of prolancer WP Theme.
* Version: 1.3.1
* Author: ThemeBing
* Author URI: http://themeforest.net/user/ThemeBing
* Text Domain: prolancer
* License: GPL/GNU.
* Domain Path: /languages
*/

/**----------------------------------------------------------------*/
/* Include all file
/*-----------------------------------------------------------------*/  

include_once(dirname( __FILE__ ). '/inc/functions.php');