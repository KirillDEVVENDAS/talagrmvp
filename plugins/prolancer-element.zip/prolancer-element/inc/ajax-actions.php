<?php 

function prolancer_ajax_create_project(){

  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'create_project_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
      exit( "No naughty business please" );
  }

  global $prolancer_opt;
  $email_on_project_creation = !empty( $prolancer_opt['email_on_project_creation'] ) ? $prolancer_opt['email_on_project_creation'] : '';
  $email_on_project_creation_subject = !empty( $prolancer_opt['email_on_project_creation_subject'] ) ? $prolancer_opt['email_on_project_creation_subject'] : '';
  $email_on_project_creation_content = !empty( $prolancer_opt['email_on_project_creation_content'] ) ? $prolancer_opt['email_on_project_creation_content'] : '';

  $project_id = $_POST['project_id'];
  $params = array();
  parse_str($_POST['project_data'], $params);

  $result = wp_update_post(array(
    'ID' => $project_id,
    'post_title' => sanitize_text_field($params['title']),
    'post_content' => wp_kses_post($params['description']),
    'post_type' => 'projects',
    'post_author' => get_current_user_id(),
    'post_status'   => 'pending',
  ), true);

  if(isset($params['project_category'])) {
    update_post_meta( $project_id, 'project_category', get_term_by('id', $params['project_category'], 'project-categories','ARRAY_A')['name']);
    prolancer_set_hierarchical_terms('project-categories', $params['project_category'], $project_id);
  }

  if(isset($params['project_seller_type'])) {
    update_post_meta( $project_id, 'project_seller_type', get_term_by('id', $params['project_seller_type'], 'project-seller-type','ARRAY_A')['name']);
    $type_terms = array((int)$params['project_seller_type']);
    wp_set_post_terms( $project_id, $type_terms, 'project-seller-type', false );
  }

  if($params['project_type'] == 'Fixed') {
    update_post_meta( $project_id, 'project_type', sanitize_text_field($params['project_type']));
    update_post_meta( $project_id, 'project_price', sanitize_text_field($params['project_price']));  
  } elseif($params['project_type'] == 'Hourly') {
    update_post_meta( $project_id, 'project_type', sanitize_text_field($params['project_type']));
    update_post_meta( $project_id, 'estimated_hours', sanitize_text_field($params['estimated_hours']));
    update_post_meta( $project_id, 'project_price', sanitize_text_field($params['project_price']));
  }

  if(isset($params['project_duration'])) {
    update_post_meta( $project_id, 'project_duration', get_term_by('id', $params['project_duration'], 'project-duration','ARRAY_A')['name']);
    $type_terms = array((int)$params['project_duration']);
    wp_set_post_terms( $project_id, $type_terms, 'project-duration', false );
  }
  
  if(isset($params['project_level'])) {
    update_post_meta( $project_id, 'project_level', get_term_by('id', $params['project_level'], 'project-level','ARRAY_A')['name']);
    $type_terms = array((int)$params['project_level']);
    wp_set_post_terms( $project_id, $type_terms, 'project-level', false );
  }
  
  if(isset($params['english_level'])) {
    update_post_meta( $project_id, 'english_level', get_term_by('id', $params['english_level'], 'english-level','ARRAY_A')['name']);
    $type_terms = array((int)$params['english_level']);
    wp_set_post_terms( $project_id, $type_terms, 'english-level', false );
  }

  if(isset($params['locations'])) {
    update_post_meta( $project_id, 'locations', get_term_by('id', $params['locations'], 'locations','ARRAY_A')['name']);
    $type_terms = array((int)$params['locations']);
    wp_set_post_terms( $project_id, $type_terms, 'locations', false );
  }

  if(isset($params['skills'])) {
    $integerIDs = array_map('intval', $params['skills']);
    $integerIDs = array_unique($integerIDs);
    wp_set_post_terms( $project_id, $integerIDs, 'skills' );
  }

  if(isset($params['languages'])) {
    $integerIDs = array_map('intval', $params['languages']);
    $integerIDs = array_unique($integerIDs);
    wp_set_post_terms( $project_id, $integerIDs, 'languages' );
  }

  if(isset($params['attachments'])) {

    $img_ids = json_decode($params['attachments']);

    if ($img_ids) {
      foreach ( $img_ids as $key) {
        $url[$key] = wp_get_attachment_url($key);
      }
    }

    update_post_meta( $project_id, 'attachments', $url);
  }

  if($params['featured_project']) {
    update_post_meta( $project_id, 'featured_project', true);
  } else {
    update_post_meta( $project_id, 'featured_project', false);
  }

  if($params['project_update']) {
    update_post_meta( $project_id, 'project_update', true);
  }

  if (is_wp_error($result)) {
    wp_send_json_error(array('message' => esc_html__( 'Error!!! Please contact admin', 'prolancer' )));
  }else{
    
    if ($email_on_project_creation) {
      // wp_mail( $to, $subject, $message, $headers)
      wp_mail(
        get_option('admin_email'), 
        $email_on_project_creation_subject,
        str_replace(
          array('{{site_name}}', '{{buyer_name}}', '{{project_link}}', '{{project_title}}'),
          array(wp_specialchars_decode(get_bloginfo('name'),ENT_QUOTES), get_userdata(get_post( $project_id )->post_author)->display_name,get_permalink($project_id), get_the_title($project_id)), 
          $email_on_project_creation_content
        ), 
        array('Content-Type: text/html; charset=UTF-8', 'From: '.get_option('admin_email'))
      );
    }
    
    wp_send_json_success(array( 
      'message' => esc_html__( 'Project created!', 'prolancer' ),
      'projects_url' => prolancer_get_page_url_by_template('prolancer-dashboard.php').'=projects'
    ));
  }  
  wp_die();  
}
add_action( 'wp_ajax_prolancer_ajax_create_project',  'prolancer_ajax_create_project' );
add_action( 'wp_ajax_nopriv_prolancer_ajax_create_project',  'prolancer_ajax_create_project' );


function prolancer_ajax_create_service(){

  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'create_service_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
      exit( "No naughty business please" );
  }

  global $prolancer_opt;
  $email_on_service_creation = !empty( $prolancer_opt['email_on_service_creation'] ) ? $prolancer_opt['email_on_service_creation'] : '';
  $email_on_service_creation_subject = !empty( $prolancer_opt['email_on_service_creation_subject'] ) ? $prolancer_opt['email_on_service_creation_subject'] : '';
  $email_on_service_creation_content = !empty( $prolancer_opt['email_on_service_creation_content'] ) ? $prolancer_opt['email_on_service_creation_content'] : '';

  $prolancer_package_feature = !empty( $prolancer_opt['prolancer_package_feature'] ) ? $prolancer_opt['prolancer_package_feature'] : '';

  $service_id = $_POST['service_id'];
  $params = array();
  parse_str($_POST['service_data'], $params);

  $result = wp_update_post(array(
    'ID' => $service_id,
    'post_title' => sanitize_text_field($params['title']),
    'post_content' => wp_kses_post($params['description']),
    'post_type' => 'services',
    'post_author' => get_current_user_id(),
    'post_status'   => 'pending'
  ), true);


  if(isset($params['service_category'])) {
    update_post_meta( $service_id, 'service_category', get_term_by('id', $params['service_category'], 'service-categories','ARRAY_A')['name']);
    prolancer_set_hierarchical_terms('service-categories', $params['service_category'], $service_id);
  }
  
  if(isset($params['service_english_level'])) {
    update_post_meta( $service_id, 'service_english_level', get_term_by('id', $params['service_english_level'], 'service-english-level','ARRAY_A')['name']);
    $type_terms = array((int)$params['service_english_level']);
    wp_set_post_terms( $service_id, $type_terms, 'service-english-level', false );
  }

  if(isset($params['delivery_time'])) {
    update_post_meta( $service_id, 'delivery_time', get_term_by('id', $params['delivery_time'], 'delivery-time','ARRAY_A')['name']);
    $type_terms = array((int)$params['delivery_time']);
    wp_set_post_terms( $service_id, $type_terms, 'delivery-time', false );
  }

  if(isset($params['service_locations'])) {
    update_post_meta( $service_id, 'service_locations', get_term_by('id', $params['service_locations'], 'service-locations','ARRAY_A')['name']);
    $type_terms = array((int)$params['service_locations']);
    wp_set_post_terms( $service_id, $type_terms, 'service-locations', false );
  }

  if(isset($params['attachments'])) {
    $img_ids = json_decode($params['attachments']);

    if ($img_ids) {
      foreach ( $img_ids as $key) {
        $url[$key] = wp_get_attachment_url($key);
      }
    }
    update_post_meta( $service_id, 'service_attachments', $url);
  }

  if(isset($params['faq_title'])){
    $faq_title = $params['faq_title'];
    $faq_description = $params['faq_description'];
    
    for($i=0; $i<count($faq_title); $i++) {
      $title = $faq_title[$i];
      $description = $faq_description[$i];
      $faqs[] = array(
        "title" => $title,
        "description" =>$description
      );
    }
    
    $json_faqs =  json_encode($faqs, JSON_UNESCAPED_UNICODE);

    update_post_meta( $service_id, 'service_faqs', $json_faqs );
    
  } else if($params['faq_title'] == '') {
    update_post_meta( $service_id, 'service_faqs', '' );
  }


  if(isset($params['package_price'])){
    
    update_post_meta($service_id, 'service_price', json_encode((int)$params['package_price'][0]));

    $package_name = $params['package_name'];
    $package_description = $params['package_description'];
    $package_delivery_time = $params['package_delivery_time'];
    $package_revision = $params['package_revision'];

    $package_price = $params['package_price'];

    if ($prolancer_package_feature) {
      foreach ($prolancer_package_feature as $feature) {
        $package_features['packagefeature_'.str_replace(' ', '_', strtolower($feature))] = $params['packagefeature_'.str_replace(' ', '_', strtolower($feature))];
      }
    }

    for($i=0; $i<count($package_price); $i++) {
      $name = $package_name[$i];
      $description = $package_description[$i];
      $delivery_time = $package_delivery_time[$i];
      $revision = $package_revision[$i];
      $features = $package_features;
      $price = $package_price[$i];

      $packages[] = array(
        "name" => $name,
        "description" => $description,
        "delivery_time" => $delivery_time,
        "revision" => $revision,
        "features" => $features,
        "price" => $price
      );
    }
    
    $json_packages =  json_encode($packages, JSON_UNESCAPED_UNICODE);

    update_post_meta( $service_id, 'packages', $json_packages );
    
  } else if($params['package_price'] == '') {
    update_post_meta( $service_id, 'packages', '' );
  }


  if(isset($params['additional_service_title'])){
    $service_title = $params['additional_service_title'];
    $service_description = $params['additional_service_description'];
    $service_price = $params['additional_service_price'];
    $service_delivery_time = $params['additional_service_delivery_time'];
    
    for($i=0; $i<count($service_title); $i++) {
      $title = $service_title[$i];
      $description = $service_description[$i];
      $price = $service_price[$i];
      $delivery_time = $service_delivery_time[$i];
      $services[] = array(
        "title" => $title,
        "description" =>$description,
        "price" =>$price,
        "delivery_time" =>$delivery_time
      );
    }
    
    $json_additional_services =  json_encode($services, JSON_UNESCAPED_UNICODE);

    update_post_meta( $service_id, 'additional_services', $json_additional_services );
          
  } else if($params['additional_service_title'] == '') {
    update_post_meta( $service_id, 'additional_services', '' );
  }

  if($params['featured_service']) {
    update_post_meta( $service_id, 'featured_service', true);
  } else {
    update_post_meta( $service_id, 'featured_service', false);
  }

  if($params['service_update']) {
    update_post_meta( $service_id, 'service_update', true);
  }

  if (is_wp_error($result)) {
    wp_send_json_error(array('message' => esc_html__( 'Error!!! Please contact admin', 'prolancer' )));
  } else {

    if ($email_on_service_creation) {
      // wp_mail( $to, $subject, $message, $headers)
      wp_mail(
        get_option('admin_email'), 
        $email_on_service_creation_subject,
        str_replace(
          array('{{site_name}}', '{{seller_name}}', '{{service_link}}', '{{service_title}}'),
          array(wp_specialchars_decode(get_bloginfo('name'),ENT_QUOTES), get_userdata(get_post( $service_id )->post_author)->display_name,get_permalink($service_id), get_the_title($service_id)), 
          $email_on_service_creation_content
        ),
        array('Content-Type: text/html; charset=UTF-8', 'From: '.get_option('admin_email'))
      );
    }

    wp_send_json_success(array( 
      'message' => esc_html__( 'Service created!', 'prolancer' ),
      'services_url' => prolancer_get_page_url_by_template('prolancer-dashboard.php').'=services'
    ));
  }
  wp_die();
}
add_action( 'wp_ajax_prolancer_ajax_create_service',  'prolancer_ajax_create_service' );
add_action( 'wp_ajax_nopriv_prolancer_ajax_create_service',  'prolancer_ajax_create_service' );


function prolancer_ajax_order_service(){
    
  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'order_service_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
      exit( "No naughty business please" );
  }

  global $wpdb;
  global $prolancer_opt;

  $prolancer_service_fee = !empty( $prolancer_opt['prolancer_service_fee'] ) ? $prolancer_opt['prolancer_service_fee'] : '';
  $email_on_order_a_service = !empty( $prolancer_opt['email_on_order_a_service'] ) ? $prolancer_opt['email_on_order_a_service'] : '';
  $email_on_order_a_service_subject = !empty( $prolancer_opt['email_on_order_a_service_subject'] ) ? $prolancer_opt['email_on_order_a_service_subject'] : '';
  $email_on_order_a_service_content = !empty( $prolancer_opt['email_on_order_a_service_content'] ) ? $prolancer_opt['email_on_order_a_service_content'] : '';

  $permalink_structure = get_option('permalink_structure') ? '?' : '&';
  
  $service_id = $_POST['service_id'];
  $package_id = $_POST['package_id'];

  $additional_service_ids = json_decode($_POST['additional_service_ids'], true);
  $additional_services =  json_decode(stripslashes(get_post_meta($service_id, 'additional_services', true)), true);

  $additional_service_price = 0;

  if($additional_service_ids){
    foreach ($additional_service_ids as $additional_service_id) {
      $additional_service_price += $additional_services[$additional_service_id]['price'];
    }
  }

  $service = get_post($service_id);
  $packages = json_decode(get_post_meta($service_id, 'packages', true ), true);
  $service_price = $packages[$package_id]['price']+$additional_service_price;

  $seller_id = get_user_meta( get_post($service_id)->post_author, 'seller_id' , true );
  $buyer_id = get_user_meta( get_current_user_id(), 'buyer_id' , true );    
  $admin_fee = $service_price/100*$prolancer_service_fee;
  $get_balance = get_user_meta( get_current_user_id(), 'wallet_balance', true );

  if(!empty($get_balance)){
    $wallet_balance = $get_balance;
  } else {
    $wallet_balance = 0;
  }
  
  $updated_wallet_amount = $wallet_balance - $service_price;
  if (is_user_logged_in()) {
    if (get_current_user_id() != $service->post_author) {
      if ( $wallet_balance >= $service_price ) { 
        update_user_meta( get_current_user_id(), 'wallet_balance', $updated_wallet_amount);
        $wpdb->insert('prolancer_service_orders',array(
            'timestamp' => current_time('mysql'),
            'updated_on' => current_time('mysql'),
            'service_id' => $service_id,
            'delivery_time_id' => $packages[$package_id]['delivery_time'],
            'service_price' => sanitize_text_field($service_price),
            'total_price' => sanitize_text_field($service_price - $admin_fee),
            'seller_id' => $seller_id,
            'buyer_id' => $buyer_id,
            'status' => 'ongoing',
        ));

        $permalink_structure = get_option('permalink_structure') ? '?' : '&';
        //prolancer_notifications($sender_id, $receiver_id, $type, $title, $image, $url)
        prolancer_notifications(
          $buyer_id, 
          $seller_id,
          'other',
          esc_html__( 'You recieved an order from ', 'prolancer' ).get_post_meta($buyer_id, 'buyer_profile_name', true ),
          wp_get_attachment_image_src(array_keys(get_post_meta($service_id, 'service_attachments', false )[0])[0],array('60','60'),true)[0], 
          prolancer_get_page_url_by_template('prolancer-dashboard.php').'=ongoing-services'
        );

        if ($email_on_order_a_service) {
          // wp_mail( $to, $subject, $message, $headers)
          wp_mail( 
            get_userdata(get_post( $service_id )->post_author)->user_email, 
            $email_on_order_a_service_subject,
            str_replace(
              array( '{{site_name}}', '{{seller_name}}', '{{buyer_name}}', '{{service_link}}', '{{service_title}}'),
              array(wp_specialchars_decode(get_bloginfo('name'),ENT_QUOTES), get_userdata(get_post( $service_id )->post_author)->display_name,get_userdata(get_post( $buyer_id )->post_author)->display_name,get_permalink($service_id), get_the_title($service_id)), 
              $email_on_order_a_service_content
            ), 
            array('Content-Type: text/html; charset=UTF-8', 'From: '.get_option('admin_email'))
          );
        }

        wp_send_json_success(array( 
          'message' => esc_html__( 'Service ordered successfully!', 'prolancer' ),
          'ongoing_services_url' => prolancer_get_page_url_by_template('prolancer-dashboard.php').'=ongoing-services'
        ));
      } else {
        wp_send_json_error(array( 
          'message' => esc_html__( 'Please recharge your wallet', 'prolancer' ),
          'wallet_url' => prolancer_get_page_url_by_template('prolancer-dashboard.php').'=wallet'
        ));
      }
    } else {
        wp_send_json_error(array( 'message' => esc_html__( 'This is one of your own services!', 'prolancer' )));
    }
  } else {
    wp_send_json_error(array( 
      'message' => esc_html__( 'User must logged in', 'prolancer' ),
      'wallet_url' => prolancer_get_page_url_by_template('prolancer-dashboard.php').'=wallet'
    ));
  }
  wp_die();
}
add_action( 'wp_ajax_prolancer_ajax_order_service',  'prolancer_ajax_order_service' );
add_action( 'wp_ajax_nopriv_prolancer_ajax_order_service',  'prolancer_ajax_order_service' );


function prolancer_ajax_service_order_complete(){
  
  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'service_order_complete_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
    exit( "No naughty business please" );
  }

  global $wpdb;
  global $prolancer_opt;

  $email_on_service_complete = !empty( $prolancer_opt['email_on_service_complete'] ) ? $prolancer_opt['email_on_service_complete'] : '';
  $email_on_service_complete_subject = !empty( $prolancer_opt['email_on_service_complete_subject'] ) ? $prolancer_opt['email_on_service_complete_subject'] : '';
  $email_on_service_complete_content = !empty( $prolancer_opt['email_on_service_complete_content'] ) ? $prolancer_opt['email_on_service_complete_content'] : '';

  $seller_id = $_POST['seller_id'];
  $order_id = $_POST['order_id'];
  parse_str($_POST['review_data'], $params);

  if ($params['review'] !='' & $params['rating-stars'] > 0 ) {
    $wpdb->insert('prolancer_reviews',array(
      'timestamp' => current_time('mysql'),
      'updated_on' => current_time('mysql'),
      'project_id' => $params['service-id'],
      'review' => sanitize_text_field($params['review']),
      'star' => $params['rating-stars'],
      'seller_id' => $seller_id,
      'buyer_id' => $params['buyer-id'],
      'type' => 'service'
    ));
  }    

  $table ='prolancer_service_orders';

  if($wpdb->get_var("SHOW TABLES LIKE '${table}'") == $table) {
    $query = "SELECT * FROM ${table} WHERE `id` = '".$order_id."' AND `seller_id` = ${seller_id} AND `status` = 'ongoing' ORDER BY timestamp DESC LIMIT 1";
    $result = $wpdb->get_results($query, ARRAY_A)[0];
  }

  $seller_user_id = get_users(array( 
    'meta_key' => 'seller_id', 
    'meta_value' => $seller_id
  ))[0]->data->ID;

  $get_balance = get_user_meta( $seller_user_id, 'wallet_balance', true );

  if(!empty($get_balance)){
    $seller_wallet_balance = $get_balance;
  }else{
    $seller_wallet_balance = 0;
  }

  if ( $order_id !=='' ) { 
    update_user_meta( $seller_user_id, 'wallet_balance', $seller_wallet_balance+$result['total_price']);
    $wpdb->update('prolancer_service_orders',
        array( 
          'updated_on' => current_time('mysql'),
          'status' => 'complete', 
        ),
        array(
          'id' => $order_id
        )
    );

    $permalink_structure = get_option('permalink_structure') ? '?' : '&';
    //prolancer_notifications($sender_id, $receiver_id, $type, $title, $image, $url)
    prolancer_notifications(
      $params['buyer-id'], 
      $seller_id,
      'other',
      esc_html__( 'You order mark as completed and accepted by ', 'prolancer' ).get_post_meta($params['buyer-id'], 'buyer_profile_name', true ),
      wp_get_attachment_image_src(array_keys(get_post_meta($params['service-id'], 'service_attachments', false )[0])[0],array('60','60'),true)[0], 
      esc_url( prolancer_get_page_url_by_template('prolancer-dashboard.php').'=completed-services')
    );

    if ($email_on_service_complete) {
      // wp_mail( $to, $subject, $message, $headers)
      wp_mail( 
        get_userdata(get_post( $params['service-id'] )->post_author)->user_email, 
        $email_on_service_complete_subject,
        str_replace(
          array( '{{site_name}}', '{{seller_name}}', '{{buyer_name}}', '{{service_link}}', '{{service_title}}'),
          array(wp_specialchars_decode(get_bloginfo('name'),ENT_QUOTES), get_userdata(get_post( $params['service-id'] )->post_author)->display_name, get_userdata(get_post( $params['buyer-id'] )->post_author)->display_name,get_permalink($params['service-id']), get_the_title($params['service-id'])), 
          $email_on_service_complete_content
        ), 
        array('Content-Type: text/html; charset=UTF-8', 'From: '.get_option('admin_email'))
      );    
    }

    wp_send_json_success(array( 
      'message' => esc_html__( 'Order completed successfully!', 'prolancer' ),
      'completed_services_url' => prolancer_get_page_url_by_template('prolancer-dashboard.php').'=completed-services'
    ));

  } else {
    wp_send_json_error(array( 'message' => esc_html__( 'Something went wrong!', 'prolancer' )));
  }
  wp_die();
}
add_action( 'wp_ajax_prolancer_ajax_service_order_complete',  'prolancer_ajax_service_order_complete' );
add_action( 'wp_ajax_nopriv_prolancer_ajax_service_order_complete',  'prolancer_ajax_service_order_complete' );


function prolancer_ajax_service_order_cancel(){
  
  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'service_order_cancel_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
      exit( "No naughty business please" );
  }

  global $wpdb;
  global $prolancer_opt;

  $email_on_service_cancel = !empty( $prolancer_opt['email_on_service_cancel'] ) ? $prolancer_opt['email_on_service_cancel'] : '';
  $email_on_service_cancel_subject = !empty( $prolancer_opt['email_on_service_cancel_subject'] ) ? $prolancer_opt['email_on_service_cancel_subject'] : '';
  $email_on_service_cancel_content = !empty( $prolancer_opt['email_on_service_cancel_content'] ) ? $prolancer_opt['email_on_service_cancel_content'] : '';

  $seller_id = $_POST['seller_id'];
  $order_id = $_POST['order_id'];

  $table ='prolancer_service_orders';

  if($wpdb->get_var("SHOW TABLES LIKE '${table}'") == $table) {
    $query = "SELECT * FROM ${table} WHERE `id` = '".$order_id."' AND `seller_id` = ${seller_id} AND `status` = 'ongoing' ORDER BY timestamp DESC LIMIT 1";
    $result = $wpdb->get_results($query, ARRAY_A)[0];
  }

  $buyer_id = $result['buyer_id'];

  if ( $order_id !=='' ) {
    $wpdb->update('prolancer_service_orders',
        array(
          'updated_on' => current_time('mysql'),
          'status' => 'cancel', 
        ),
        array(
          'id' => $order_id
        )
    );

    $permalink_structure = get_option('permalink_structure') ? '?' : '&';
    //prolancer_notifications($sender_id, $receiver_id, $type, $title, $image, $url)
    prolancer_notifications(
      $buyer_id, 
      $seller_id,
      'other',
      esc_html__( 'You order has been cancelled by ', 'prolancer' ).get_post_meta($buyer_id, 'buyer_profile_name', true ),
      wp_get_attachment_image_src(array_keys(get_post_meta($result['service_id'], 'service_attachments', false )[0])[0],array('60','60'),true)[0], 
      esc_url( prolancer_get_page_url_by_template('prolancer-dashboard.php').'=cancelled-services')
    );

    if ($email_on_service_cancel) {
      // wp_mail( $to, $subject, $message, $headers)
      wp_mail( 
        get_userdata(get_post( $result['service_id'] )->post_author)->user_email, 
        $email_on_service_cancel_subject,
        str_replace(
          array( '{{site_name}}', '{{seller_name}}', '{{buyer_name}}', '{{service_link}}', '{{service_title}}'),
          array(wp_specialchars_decode(get_bloginfo('name'),ENT_QUOTES), get_userdata(get_post( $result['service_id'] )->post_author)->display_name, get_userdata(get_post( $buyer_id )->post_author)->display_name,get_permalink($result['service_id']), get_the_title($result['service_id'])), 
          $email_on_service_cancel_content
        ), 
        array('Content-Type: text/html; charset=UTF-8', 'From: '.get_option('admin_email'))
      );    
    }

    wp_send_json_success(array( 
      'message' => esc_html__( 'Order cancelled successfully!', 'prolancer' ),
      'cancelled_services_url' => prolancer_get_page_url_by_template('prolancer-dashboard.php').'=cancelled-services'
    ));

  } else {
    wp_send_json_error(array( 'message' => esc_html__( 'Something went wrong!', 'prolancer' )));
  }
  wp_die();
}
add_action( 'wp_ajax_prolancer_ajax_service_order_cancel',  'prolancer_ajax_service_order_cancel' );
add_action( 'wp_ajax_nopriv_prolancer_ajax_service_order_cancel',  'prolancer_ajax_service_order_cancel' );


function prolancer_ajax_send_service_message(){

  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'send_service_message_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
      exit( "No naughty business please" );
  }

  global $prolancer_opt;

  $email_on_sending_service_messages = !empty( $prolancer_opt['email_on_sending_service_messages'] ) ? $prolancer_opt['email_on_sending_service_messages'] : '';
  $email_on_sending_service_messages_subject = !empty( $prolancer_opt['email_on_sending_service_messages_subject'] ) ? $prolancer_opt['email_on_sending_service_messages_subject'] : '';
  $email_on_sending_service_messages_content = !empty( $prolancer_opt['email_on_sending_service_messages_content'] ) ? $prolancer_opt['email_on_sending_service_messages_content'] : '';

  $permalink_structure = get_option('permalink_structure') ? '?' : '&';

  $order_id = $_POST['order_id'];
  $sender_id = $_POST['sender_id'];
  $receiver_id = $_POST['receiver_id'];

  $params = array();
  parse_str($_POST['message_data'], $params);

  if( $params['message'] != '' ) {

    global $wpdb;

    $wpdb->insert('prolancer_service_messages',array(
      'timestamp' => current_time('mysql'),
      'updated_on' => current_time('mysql'),
      'order_id' => $order_id,
      'message' => sanitize_text_field($params['message']),
      'attachment_id' => sanitize_text_field($params['attachment_id']),
      'sender_id' => sanitize_text_field($sender_id),
      'receiver_id' => sanitize_text_field($receiver_id)
    ));

    $msg_id = $wpdb->insert_id;

    if($msg_id) {

      $permalink_structure = get_option('permalink_structure') ? '?' : '&';
      //prolancer_notifications($sender_id, $receiver_id, $type, $title, $image, $url)
      prolancer_notifications(
        $sender_id,
        $receiver_id,
        'message',
        get_post_meta(get_user_meta($sender_id, 'buyer_id' , true ), 'buyer_profile_name', true ).esc_html__( ' has sent a message', 'prolancer' ),
        $sender_id,
        esc_url( prolancer_get_page_url_by_template('prolancer-dashboard.php').'=ongoing-service-details&order_id='.$order_id )
      );

      if ($email_on_sending_service_messages) {
        // wp_mail( $to, $subject, $message, $headers)
        wp_mail(
          get_userdata(get_post( $receiver_id )->post_author)->user_email, 
          $email_on_sending_service_messages_subject,
          str_replace(
            array('{{site_name}}', '{{sender_name}}', '{{receiver_name}}', '{{message}}', '{{message_link}}'),
            array(wp_specialchars_decode(get_bloginfo('name'),ENT_QUOTES), get_userdata(get_post( $sender_id )->post_author)->display_name, get_userdata(get_post( $receiver_id )->post_author)->display_name,sanitize_text_field($params['message']),prolancer_get_page_url_by_template('prolancer-dashboard.php').$permalink_structure.'fed=ongoing-service-details&order_id='.$order_id), 
            $email_on_sending_service_messages_content
          ), 
          array('Content-Type: text/html; charset=UTF-8', 'From: '.get_option('admin_email'))
        );
      }

      wp_send_json_success(array('message' => esc_html__( 'Message sent', 'prolancer' )));

    } else {
      wp_send_json_error(array('message' => esc_html__( 'Error!!! Message sending failed.', 'prolancer' )));  
    }
  } else {
    $return = array('message' => esc_html__( 'Message field can not be empty', 'prolancer' ));
    wp_send_json_error($return);  
  }
  wp_die();
}
add_action( 'wp_ajax_prolancer_ajax_send_service_message',  'prolancer_ajax_send_service_message' );
add_action( 'wp_ajax_nopriv_prolancer_ajax_send_service_message',  'prolancer_ajax_send_service_message' );


function prolancer_ajax_submit_proposal(){
  
  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'create_project_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
      exit( "No naughty business please" );
  }

  global $wpdb;
  global $prolancer_opt;

  $prolancer_project_fee = !empty( $prolancer_opt['prolancer_service_fee'] ) ? $prolancer_opt['prolancer_service_fee'] : '';
  $email_on_proposal = !empty( $prolancer_opt['email_on_proposal'] ) ? $prolancer_opt['email_on_proposal'] : '';
  $email_on_proposal_subject = !empty( $prolancer_opt['email_on_proposal_subject'] ) ? $prolancer_opt['email_on_proposal_subject'] : '';
  $email_on_proposal_content = !empty( $prolancer_opt['email_on_proposal_content'] ) ? $prolancer_opt['email_on_proposal_content'] : '';
  
  $project_id = $_POST['project_id'];
  $project   =   get_post($project_id);
  $params = array();
  parse_str($_POST['proposal_data'], $params);
  $seller_id = get_user_meta( get_current_user_id(), 'seller_id' , true );
  $buyer_id = get_user_meta( get_post($project_id)->post_author, 'buyer_id' , true );    
  $admin_fee = $params['proposal_price']/100*$prolancer_project_fee;

  if (is_user_logged_in()) {
    if ( get_current_user_id() != $project->post_author ) {  
      if (!empty($params['proposal_cover_letter'])) {

        $if_query_exist = $wpdb->get_results("SELECT * FROM prolancer_project_proposals WHERE `seller_id` = ${seller_id} AND `project_id` = ${project_id} AND `status` ='pending'", ARRAY_A)[0];
      
        if (empty($if_query_exist)) {
            $wpdb->insert('prolancer_project_proposals',array(
              'timestamp' => current_time('mysql'),
              'updated_on' => current_time('mysql'),
              'project_id' => $project_id,
              'proposed_price' => sanitize_text_field($params['proposal_price']),
              'earned_money' => sanitize_text_field($params['proposal_price'] - $admin_fee),
              'day_to_complete' => sanitize_text_field($params['proposal_project_duration']),
              'cover_letter' => sanitize_text_field($params['proposal_cover_letter']),
              'seller_id' => $seller_id,
              'buyer_id' => $buyer_id,
              'status' => 'pending'
            ));

            $permalink_structure = get_option('permalink_structure') ? '?' : '&';
            //prolancer_notifications($sender_id, $receiver_id, $type, $title, $image, $url)
            prolancer_notifications(
              $seller_id, 
              $buyer_id,
              'other',
              esc_html__( 'You recieved a proposal from ', 'prolancer' ).get_post_meta($seller_id, 'seller_profile_name', true ),
              wp_get_attachment_image_src( prolancer_get_image_id(get_post_meta($seller_id, 'seller_profile_attachment', true )),array('60', '60') ,true)[0], 
              esc_url( prolancer_get_page_url_by_template('prolancer-dashboard.php').'=proposals&project_id='.$project_id)
            );

            if ($email_on_proposal) {
              // wp_mail( $to, $subject, $message, $headers)
              wp_mail( 
                get_userdata(get_post( $project_id )->post_author)->user_email, 
                $email_on_proposal_subject,
                str_replace(
                  array( '{{site_name}}','{{buyer_name}}','{{seller_name}}','{{project_link}}', '{{project_title}}'),
                  array(wp_specialchars_decode(get_bloginfo('name'),ENT_QUOTES), get_userdata(get_post( $project_id )->post_author)->display_name, get_userdata(get_post( $seller_id )->post_author)->display_name,get_permalink($project_id), get_the_title($project_id)), 
                  $email_on_proposal_content
                ), 
                array('Content-Type: text/html; charset=UTF-8', 'From: '.get_option('admin_email'))
              );
            }

            wp_send_json_success(array( 
              'message' => esc_html__( 'Proposal submitted successfully!', 'prolancer' ),
              'ongoing_projects_url' => prolancer_get_page_url_by_template('prolancer-dashboard.php').'=ongoing-projects'
            ));
             
          } else {
            wp_send_json_error(array( 'message' => esc_html__( 'You have already submitted a proposal', 'prolancer' )));
          }
      } else {
        wp_send_json_error(array( 'message' => esc_html__( 'Please write a cover letter!', 'prolancer' )));
      }
    } else {
        wp_send_json_error(array( 'message' => esc_html__( 'This is one of your own projects!', 'prolancer' )));
    }
  } else {
    wp_send_json_error(array( 'message' => esc_html__( 'User must logged in', 'prolancer' )));
  }
  wp_die();
}
add_action( 'wp_ajax_prolancer_ajax_submit_proposal',  'prolancer_ajax_submit_proposal' );
add_action( 'wp_ajax_nopriv_prolancer_ajax_submit_proposal',  'prolancer_ajax_submit_proposal' );


function prolancer_ajax_hire_seller(){

  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'hire_seller_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
      exit( "No naughty business please" );
  }

  global $wpdb;
  global $prolancer_opt;

  $email_on_project_assigned = !empty( $prolancer_opt['email_on_project_assigned'] ) ? $prolancer_opt['email_on_project_assigned'] : '';
  $email_on_project_assigned_subject = !empty( $prolancer_opt['email_on_project_assigned_subject'] ) ? $prolancer_opt['email_on_project_assigned_subject'] : '';
  $email_on_project_assigned_content = !empty( $prolancer_opt['email_on_project_assigned_content'] ) ? $prolancer_opt['email_on_project_assigned_content'] : '';

  $project_id = $_POST['project_id'];
  $buyer_id = get_post( $project_id )->post_author;
  $seller_id = $_POST['seller_id'];
  $proposal_id = $_POST['proposal_id'];

  $table ='prolancer_project_proposals';
    
  if($wpdb->get_var("SHOW TABLES LIKE '${table}'") == $table) {
    $query = "SELECT * FROM ${table} WHERE `id` = ${proposal_id} AND `seller_id` = ${seller_id} AND `status` = 'pending'";
    $result = $wpdb->get_results($query, ARRAY_A)[0];
  }

  $get_balance = get_user_meta( get_current_user_id(), 'wallet_balance', true );

  if(!empty($get_balance)){
    $buyer_wallet_balance = $get_balance;
  }else{
    $buyer_wallet_balance = 0;
  }

  if ($buyer_wallet_balance >= $result['proposed_price']) {
    if ( $proposal_id !=='' ) {
      update_user_meta( get_current_user_id(), 'wallet_balance', $buyer_wallet_balance-$result['proposed_price']);
      $wpdb->update('prolancer_project_proposals',
        array(
          'updated_on' => current_time('mysql'),
          'status' => 'ongoing',
        ),
        array(
          'id' => $proposal_id
        )
      );

      $permalink_structure = get_option('permalink_structure') ? '?' : '&';
      //prolancer_notifications($sender_id, $receiver_id, $type, $title, $image, $url)
      prolancer_notifications(
        $buyer_id,
        $seller_id, 
        'other',
        esc_html__( 'Your proposal accepted and hired for ', 'prolancer' ).'('.get_the_title($project_id).')',
        wp_get_attachment_image_src( prolancer_get_image_id(get_post_meta($buyer_id, 'buyer_profile_attachment', true )),array('60', '60') ,true)[0],
        esc_url( prolancer_get_page_url_by_template('prolancer-dashboard.php').'=ongoing-project-details&proposal_id='.$proposal_id)
      );

      if ($email_on_project_assigned) {
        // wp_mail( $to, $subject, $message, $headers)
        wp_mail( 
          get_userdata(get_post( $seller_id )->post_author)->user_email, 
          $email_on_project_assigned_subject,
          str_replace(
            array( '{{site_name}}', '{{buyer_name}}','{{seller_name}}', '{{project_link}}', '{{project_title}}'),
            array(wp_specialchars_decode(get_bloginfo('name'),ENT_QUOTES), get_userdata(get_post( $buyer_id )->post_author)->display_name, get_userdata(get_post( $seller_id )->post_author)->display_name,get_permalink($project_id), get_the_title($project_id)), 
            $email_on_project_assigned_content
          ), 
          array('Content-Type: text/html; charset=UTF-8', 'From: '.get_option('admin_email'))
        );    
      }

      wp_send_json_success(array( 
        'message' => esc_html__( 'Hired!', 'prolancer' ),
        'ongoing_projects_url' => prolancer_get_page_url_by_template('prolancer-dashboard.php').'=ongoing-projects'
      ));

    } else {
      wp_send_json_error(array( 'message' => esc_html__( 'Something went wrong!', 'prolancer' )));
    }
  } else {
    wp_send_json_error(array( 
      'message' => esc_html__( 'Please recharge your wallet', 'prolancer' ),
      'wallet_url' => prolancer_get_page_url_by_template('prolancer-dashboard.php').'=wallet'
    ));
  }
  wp_die();
}
add_action('wp_ajax_prolancer_ajax_hire_seller', 'prolancer_ajax_hire_seller');
add_action('wp_ajax_nopriv_prolancer_ajax_hire_seller', 'prolancer_ajax_hire_seller');


function prolancer_ajax_proposal_cancel(){

  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'project_proposal_cancel_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
      exit( "No naughty business please" );
  }

  global $wpdb;
  global $prolancer_opt;

  $email_on_proposal_cancel = !empty( $prolancer_opt['email_on_proposal_cancel'] ) ? $prolancer_opt['email_on_proposal_cancel'] : '';
  $email_on_proposal_cancel_subject = !empty( $prolancer_opt['email_on_proposal_cancel_subject'] ) ? $prolancer_opt['email_on_proposal_cancel_subject'] : '';
  $email_on_proposal_cancel_content = !empty( $prolancer_opt['email_on_proposal_cancel_content'] ) ? $prolancer_opt['email_on_proposal_cancel_content'] : '';

  $project_id = $_POST['project_id'];
  $buyer_id = get_post( $project_id )->post_author;
  $seller_id = $_POST['seller_id'];    
  $proposal_id = $_POST['proposal_id'];

  if ( $proposal_id !=='' ) {
    $wpdb->delete('prolancer_project_proposals',
      array(
        'id' => $proposal_id
      )
    );

    //prolancer_notifications($sender_id, $receiver_id, $type, $title, $image, $url)
    prolancer_notifications(
      $buyer_id,
      $seller_id, 
      'other',
      esc_html__( 'Your proposal declined for ', 'prolancer' ).'('.get_the_title($project_id).')',
      wp_get_attachment_image_src( prolancer_get_image_id(get_post_meta($buyer_id, 'buyer_profile_attachment', true )),array('60', '60') ,true)[0],
      esc_url(get_permalink($project_id))
    );

    if ($email_on_proposal_cancel) {
      // wp_mail( $to, $subject, $message, $headers)
      wp_mail( 
        get_userdata(get_post( $seller_id )->post_author)->user_email, 
        $email_on_proposal_cancel_subject,
        str_replace(
          array( '{{site_name}}', '{{buyer_name}}','{{seller_name}}', '{{project_link}}', '{{project_title}}'),
          array(wp_specialchars_decode(get_bloginfo('name'),ENT_QUOTES), get_userdata(get_post( $project_id )->post_author)->display_name, get_userdata(get_post( $seller_id )->post_author)->display_name,get_permalink($project_id), get_the_title($project_id)), 
          $email_on_proposal_cancel_content
        ),
        array('Content-Type: text/html; charset=UTF-8', 'From: '.get_option('admin_email'))
      );    
    }

    wp_send_json_success(array( 
      'message' => esc_html__( 'Proposal cancelled!', 'prolancer' ),
      'proposals_url' => prolancer_get_page_url_by_template('prolancer-dashboard.php').'=proposals&project_id='.$project_id
    ));
  } else {
    wp_send_json_error(array( 'message' => esc_html__( 'Something went wrong!', 'prolancer' )));
  }
  wp_die();
}
add_action('wp_ajax_prolancer_ajax_proposal_cancel', 'prolancer_ajax_proposal_cancel');
add_action('wp_ajax_nopriv_prolancer_ajax_proposal_cancel', 'prolancer_ajax_proposal_cancel');


function prolancer_ajax_project_cancel(){

  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'project_project_cancel_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
      exit( "No naughty business please" );
  }

  global $wpdb;
  global $prolancer_opt;

  $email_on_project_cancel = !empty( $prolancer_opt['email_on_project_cancel'] ) ? $prolancer_opt['email_on_project_cancel'] : '';
  $email_on_project_cancel_subject = !empty( $prolancer_opt['email_on_project_cancel_subject'] ) ? $prolancer_opt['email_on_project_cancel_subject'] : '';
  $email_on_project_cancel_content = !empty( $prolancer_opt['email_on_project_cancel_content'] ) ? $prolancer_opt['email_on_project_cancel_content'] : '';

  $buyer_id = $_POST['buyer_id'];
  $seller_id = $_POST['seller_id'];    
  $project_id = $_POST['project_id'];
  $proposal_id = $_POST['proposal_id'];

  if ( $project_id !=='' ) {
    $wpdb->update('prolancer_project_proposals',
      array(
          'updated_on' => current_time('mysql'),
          'status' => 'cancel', 
      ),
      array(
        'id' => $proposal_id
      )
    );

    //prolancer_notifications($sender_id, $receiver_id, $type, $title, $image, $url)
    prolancer_notifications(
      $buyer_id,
      $seller_id, 
      'other',
      esc_html__( 'Your project cancelled ', 'prolancer' ).'('.get_the_title($project_id).')',
      wp_get_attachment_image_src( prolancer_get_image_id(get_post_meta($buyer_id, 'buyer_profile_attachment', true )),array('60', '60') ,true)[0],
      esc_url(get_permalink($project_id))
    );

    if ($email_on_project_cancel) {
      // wp_mail( $to, $subject, $message, $headers)
      wp_mail( 
        get_userdata(get_post( $seller_id )->post_author)->user_email, 
        $email_on_project_cancel_subject,
        str_replace(
          array( '{{site_name}}', '{{buyer_name}}','{{seller_name}}', '{{project_link}}', '{{project_title}}'),
          array(wp_specialchars_decode(get_bloginfo('name'),ENT_QUOTES), get_userdata(get_post( $buyer_id )->post_author)->display_name, get_userdata(get_post( $seller_id )->post_author)->display_name,get_permalink($project_id), get_the_title($project_id)), 
          $email_on_project_cancel_content
        ), 
        array('Content-Type: text/html; charset=UTF-8', 'From: '.get_option('admin_email'))
      );    
    }

    wp_send_json_success(array( 
      'message' => esc_html__( 'Project cancelled successfully!', 'prolancer' ),
      'cancelled_projects_url' => prolancer_get_page_url_by_template('prolancer-dashboard.php').'=cancelled-projects'
    ));

  } else {
    wp_send_json_error(array( 'message' => esc_html__( 'Something went wrong!', 'prolancer' )));
  }
  wp_die();
}
add_action('wp_ajax_prolancer_ajax_project_cancel', 'prolancer_ajax_project_cancel');
add_action('wp_ajax_nopriv_prolancer_ajax_project_cancel', 'prolancer_ajax_project_cancel');


function prolancer_ajax_project_complete(){

  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'project_complete_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
      exit( "No naughty business please" );
  }

  global $wpdb;
  global $prolancer_opt;

  $email_on_project_complete = !empty( $prolancer_opt['email_on_project_complete'] ) ? $prolancer_opt['email_on_project_complete'] : '';
  $email_on_project_complete_subject = !empty( $prolancer_opt['email_on_project_complete_subject'] ) ? $prolancer_opt['email_on_project_complete_subject'] : '';
  $email_on_project_complete_content = !empty( $prolancer_opt['email_on_project_complete_content'] ) ? $prolancer_opt['email_on_project_complete_content'] : '';

  
  $seller_id = $_POST['seller_id'];
  $proposal_id = $_POST['proposal_id'];
  parse_str($_POST['review_data'], $params);
  $buyer_id = $params['buyer-id'];

  if ($params['review'] !='' & $params['rating-stars'] > 0 ) {
    $wpdb->insert('prolancer_reviews',array(
      'timestamp' => current_time('mysql'),
      'updated_on' => current_time('mysql'),
      'project_id' => $params['project-id'],
      'review' => sanitize_text_field($params['review']),
      'star' => $params['rating-stars'],
      'seller_id' => $seller_id,
      'buyer_id' => $buyer_id,
      'type' => 'project'
    ));
  } 

  $table ='prolancer_project_proposals';
    
  if($wpdb->get_var("SHOW TABLES LIKE '${table}'") == $table) {
    $query = "SELECT * FROM ${table} WHERE `id` = ${proposal_id} AND `seller_id` = ${seller_id} AND `status` ='ongoing' ORDER BY timestamp DESC LIMIT 1";
    $result = $wpdb->get_results($query, ARRAY_A)[0];
  }

  $seller_user_id = get_users(array( 
    'meta_key' => 'seller_id', 
    'meta_value' => $seller_id
  ))[0]->data->ID;

  $get_balance = get_user_meta( $seller_user_id, 'wallet_balance', true );

  if(!empty($get_balance)){
    $seller_wallet_balance = $get_balance;
  }else{
    $seller_wallet_balance = 0;
  }
  
  if ( $proposal_id !=='' ) {
    update_user_meta( $seller_user_id, 'wallet_balance', $seller_wallet_balance+$result['earned_money']);
    $wpdb->update('prolancer_project_proposals',
      array(
        'updated_on' => current_time('mysql'),
        'status' => 'complete',
      ),
      array(
        'id' => $proposal_id
      )
    );

    $permalink_structure = get_option('permalink_structure') ? '?' : '&';
    //prolancer_notifications($sender_id, $receiver_id, $type, $title, $image, $url)
    prolancer_notifications(
      $buyer_id,
      $seller_id, 
      'other',
      esc_html__( 'Your project mark as completed by ', 'prolancer' ).get_post_meta($buyer_id, 'buyer_profile_name', true ),
      wp_get_attachment_image_src( prolancer_get_image_id(get_post_meta($buyer_id, 'buyer_profile_attachment', true )),array('60', '60') ,true)[0],
      esc_url( prolancer_get_page_url_by_template('prolancer-dashboard.php').'=completed-project-details&proposal_id='.$proposal_id)
    );


    if ($email_on_project_complete) {
      // wp_mail( $to, $subject, $message, $headers)
      wp_mail( 
        get_userdata(get_post( $seller_id )->post_author)->user_email, 
        $email_on_project_complete_subject,
        str_replace(
          array( '{{site_name}}', '{{buyer_name}}', '{{seller_name}}', '{{project_link}}', '{{project_title}}'),
          array(wp_specialchars_decode(get_bloginfo('name'),ENT_QUOTES), get_userdata(get_post( $buyer_id )->post_author)->display_name,get_userdata(get_post( $seller_id )->post_author)->display_name,get_permalink($params['project-id']), get_the_title($params['project-id'])), 
          $email_on_project_complete_content
        ), 
        array('Content-Type: text/html; charset=UTF-8', 'From: '.get_option('admin_email'))
      );    
    }

    wp_send_json_success(array( 
      'message' => esc_html__( 'Project completed successfully!', 'prolancer' ),
      'completed_projects_url' => prolancer_get_page_url_by_template('prolancer-dashboard.php').'=completed-projects'
    ));

  } else {
    wp_send_json_error(array( 'message' => esc_html__( 'Something went wrong!', 'prolancer' )));
  }
  wp_die();
}
add_action('wp_ajax_prolancer_ajax_project_complete', 'prolancer_ajax_project_complete');
add_action('wp_ajax_nopriv_prolancer_ajax_project_complete', 'prolancer_ajax_project_complete');


function prolancer_ajax_send_project_message(){

  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'send_project_message_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
      exit( "No naughty business please" );
  }

  global $prolancer_opt;

  $email_on_sending_project_messages = !empty( $prolancer_opt['email_on_sending_project_messages'] ) ? $prolancer_opt['email_on_sending_project_messages'] : '';
  $email_on_sending_project_messages_subject = !empty( $prolancer_opt['email_on_sending_project_messages_subject'] ) ? $prolancer_opt['email_on_sending_project_messages_subject'] : '';
  $email_on_sending_project_messages_content = !empty( $prolancer_opt['email_on_sending_project_messages_content'] ) ? $prolancer_opt['email_on_sending_project_messages_content'] : '';

  $proposal_id = $_POST['proposal_id'];
  $sender_id = $_POST['sender_id'];
  $receiver_id = $_POST['receiver_id'];
  $params = array();
  parse_str($_POST['message_data'], $params);

  if( $params['message'] != '' ) {

    global $wpdb;

    $wpdb->insert('prolancer_project_messages',array(
      'timestamp' => current_time('mysql'),
      'updated_on' => current_time('mysql'),
      'proposal_id' => $proposal_id,
      'message' => sanitize_text_field($params['message']),
      'attachment_id' => sanitize_text_field($params['attachment_id']),
      'sender_id' => sanitize_text_field($sender_id),
      'receiver_id' => sanitize_text_field($receiver_id)
    ));


    $msg_id = $wpdb->insert_id;

    if($msg_id) {

      $permalink_structure = get_option('permalink_structure') ? '?' : '&';
      //prolancer_notifications($sender_id, $receiver_id, $type, $title, $image, $url)
      prolancer_notifications(
        $sender_id,
        $receiver_id,
        'message', 
        get_post_meta(get_user_meta($sender_id, 'buyer_id' , true ), 'buyer_profile_name', true ).esc_html__( ' has sent a message', 'prolancer' ),
        $sender_id, 
        esc_url( prolancer_get_page_url_by_template('prolancer-dashboard.php').'=ongoing-project-details&proposal_id='.$proposal_id )
      );

      if ($email_on_sending_project_messages) {
        // wp_mail( $to, $subject, $message, $headers)
        wp_mail(
          get_userdata(get_post( $receiver_id )->post_author)->user_email, 
          $email_on_sending_project_messages_subject,
          str_replace(
            array('{{site_name}}', '{{sender_name}}', '{{receiver_name}}', '{{message}}', '{{message_link}}'),
            array(wp_specialchars_decode(get_bloginfo('name'),ENT_QUOTES), get_userdata(get_post( $sender_id )->post_author)->display_name, get_userdata(get_post( $receiver_id )->post_author)->display_name, sanitize_text_field($params['message']), prolancer_get_page_url_by_template('prolancer-dashboard.php').$permalink_structure.'fed=ongoing-project-details&proposal_id='.$proposal_id), 
            $email_on_sending_project_messages_content
          ), 
          array('Content-Type: text/html; charset=UTF-8', 'From: '.get_option('admin_email'))
        );
      }
      
      $return = array('message' => esc_html__( 'Message sent', 'prolancer' ));
      wp_send_json_success($return);

    } else {
      $return = array('message' => esc_html__( 'Error!!! Message sending failed.', 'prolancer' ));
      wp_send_json_error($return);  
    }
  } else {
    $return = array('message' => esc_html__( 'Message field can not be empty', 'prolancer' ));
    wp_send_json_error($return);  
  }
  wp_die();
}
add_action( 'wp_ajax_prolancer_ajax_send_project_message',  'prolancer_ajax_send_project_message' );
add_action( 'wp_ajax_nopriv_prolancer_ajax_send_project_message',  'prolancer_ajax_send_project_message' );


function prolancer_ajax_update_buyer_profile(){

  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'create_buyer_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
      exit( "No naughty business please" );
  }

  $buyer_id = $_POST['buyer_id'];
  $params = array();
  parse_str($_POST['buyer_data'], $params);

  $result = wp_update_post(array(
    'ID' => $buyer_id,
    'post_title' => sanitize_text_field($params['buyer_username']),
    'post_content' => wp_kses_post($params['description']),
    'post_type' => 'buyers',
    'post_author' => get_current_user_id(),
  ), true);


  if(isset($params['buyer_profile_name'])) {
    update_post_meta( $buyer_id, 'buyer_profile_name', sanitize_text_field($params['buyer_profile_name']));
  }

  if(isset($params['buyer_profile_title'])) {
    update_post_meta( $buyer_id, 'buyer_profile_title', sanitize_text_field($params['buyer_profile_title']));
  }

  if(isset($params['buyer_departments'])) {
    update_post_meta( $buyer_id, 'buyer_departments', get_term_by('id', $params['buyer_departments'], 'buyer-departments','ARRAY_A')['name']);
    $type_terms = array((int)$params['buyer_departments']);
    wp_set_post_terms( $buyer_id, $type_terms, 'buyer-departments', false );
  }

  if(isset($params['employees_number'])) {
    update_post_meta( $buyer_id, 'employees_number', get_term_by('id', $params['employees_number'], 'employees-number','ARRAY_A')['name']);
    $type_terms = array((int)$params['employees_number']);
    wp_set_post_terms( $buyer_id, $type_terms, 'employees-number', false );
  }
  
  if(isset($params['buyer_locations'])) {
    update_post_meta( $buyer_id, 'buyer_locations', get_term_by('id', $params['buyer_locations'], 'buyer-locations','ARRAY_A')['name']);
    $type_terms = array((int)$params['buyer_locations']);
    wp_set_post_terms( $buyer_id, $type_terms, 'buyer-locations', false );
  }

  if(isset($params['buyer_profile_attachment'])) {
    update_post_meta( $buyer_id, 'buyer_profile_attachment', wp_get_attachment_url(json_decode($params['buyer_profile_attachment'])));
  }

  if(isset($params['buyer_cover_attachment'])) {
    update_post_meta( $buyer_id, 'buyer_cover_attachment', wp_get_attachment_url($params['buyer_cover_attachment']));
  }

  if(isset($params['facebook'])) {
    update_user_meta( get_current_user_id(), 'facebook', esc_url_raw($params['facebook']));
  }

  if(isset($params['twitter'])) {
    update_user_meta( get_current_user_id(), 'twitter', esc_url_raw($params['twitter']));
  }

  if(isset($params['linkedin'])) {
    update_user_meta( get_current_user_id(), 'linkedin', esc_url_raw($params['linkedin']));
  }

  if(isset($params['github'])) {
    update_user_meta( get_current_user_id(), 'github', esc_url_raw($params['github']));
  }

  if(isset($params['dribbble'])) {
    update_user_meta( get_current_user_id(), 'dribbble', esc_url_raw($params['dribbble']));
  }

  if (is_wp_error($result)) {
    wp_send_json_error(array('message' => esc_html__( 'Error!!! Please contact admin', 'prolancer' )));
  } else {
    wp_send_json_success(array('message' => esc_html__( 'Profile data has been saved!', 'prolancer' )));
  }
  wp_die();
}
add_action( 'wp_ajax_prolancer_ajax_update_buyer_profile',  'prolancer_ajax_update_buyer_profile' );
add_action( 'wp_ajax_nopriv_prolancer_ajax_update_buyer_profile',  'prolancer_ajax_update_buyer_profile' );


function prolancer_ajax_update_seller_profile(){

  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'create_seller_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
      exit( "No naughty business please" );
  }

  $seller_id = $_POST['seller_id'];
  $params = array();
  parse_str($_POST['seller_data'], $params);

  $result = wp_update_post(array(
    'ID' => $seller_id,
    'post_title' => sanitize_text_field($params['seller_username']),
    'post_content' => wp_kses_post($params['description']),
    'post_type' => 'sellers',
    'post_author' => get_current_user_id(),
  ), true);


  if(isset($params['seller_profile_name'])) {
    update_post_meta( $seller_id, 'seller_profile_name', sanitize_text_field($params['seller_profile_name']));
  }

  if(isset($params['seller_profile_title'])) {
    update_post_meta( $seller_id, 'seller_profile_title', sanitize_text_field($params['seller_profile_title']));
  }

  if(isset($params['seller_hourly_rate'])) {
    update_post_meta( $seller_id, 'seller_hourly_rate', sanitize_text_field($params['seller_hourly_rate']));
  }

  if(isset($params['seller_gender'])) {
    update_post_meta( $seller_id, 'seller_gender', sanitize_text_field($params['seller_gender']));
  }

  if(isset($params['seller_type'])) {
    update_post_meta( $seller_id, 'seller_type', get_term_by('id', $params['seller_type'], 'seller-type','ARRAY_A')['name']);
    $type_terms = array((int)$params['seller_type']);
    wp_set_post_terms( $seller_id, $type_terms, 'seller-type', false );
  } 

  if(isset($params['seller_english_level'])) {
    update_post_meta( $seller_id, 'seller_english_level', get_term_by('id', $params['seller_english_level'], 'seller-english-level','ARRAY_A')['name']);
    $type_terms = array((int)$params['seller_english_level']);
    wp_set_post_terms( $seller_id, $type_terms, 'seller-english-level', false );
  } 

  if(isset($params['seller_languages'])) {
    update_post_meta( $seller_id, 'seller_languages', get_term_by('id', $params['seller_languages'], 'seller-languages','ARRAY_A')['name']);
    $type_terms = array((int)$params['seller_languages']);
    wp_set_post_terms( $seller_id, $type_terms, 'seller-languages', false );
  } 

  if(isset($params['seller_locations'])) {
    update_post_meta( $seller_id, 'seller_locations', get_term_by('id', $params['seller_locations'], 'seller-locations','ARRAY_A')['name']);
    $type_terms = array((int)$params['seller_locations']);
    wp_set_post_terms( $seller_id, $type_terms, 'seller-locations', false );
  }

  if(isset($params['seller_profile_attachment'])) {
    update_post_meta( $seller_id, 'seller_profile_attachment', wp_get_attachment_url(json_decode($params['seller_profile_attachment'])));
  }

  if(isset($params['seller_cover_attachment'])) {
    update_post_meta( $seller_id, 'seller_cover_attachment', wp_get_attachment_url($params['seller_cover_attachment']));
  }

  if(isset($params['seller_address'])) {
    update_post_meta( $seller_id, 'seller_address', sanitize_text_field($params['seller_address']));
  }

  if(isset($params['seller_skills'])){
    $skill_name = array_unique($params['seller_skills']);
    $skill_percent = $params['skills_percent'];
    $integerIDs = array_map('intval', $params['seller_skills']);
    
    for($i=0; $i<count($skill_name); $i++)
    {
      $skill_id = $skill_name[$i];
      $percent = $skill_percent[$i];
      $skills[] = array(
        "skill" => $skill_id,
        "percent" =>$percent
      );
    }
    
    $json_skills =  json_encode($skills, JSON_UNESCAPED_UNICODE);
     
    wp_set_post_terms( $seller_id, $integerIDs, 'seller-skills', false );
    update_post_meta( $seller_id, 'seller_skills', $json_skills );
    
  } else if($params['seller_skills'] == '') {
    wp_set_post_terms( $seller_id, '', 'seller-skills', false );
    update_post_meta( $seller_id, 'seller_skills', '' );
  }

  if(isset($params['facebook'])) {
    update_user_meta( get_current_user_id(), 'facebook', esc_url_raw($params['facebook']));
  }

  if(isset($params['twitter'])) {
    update_user_meta( get_current_user_id(), 'twitter', esc_url_raw($params['twitter']));
  }

  if(isset($params['linkedin'])) {
    update_user_meta( get_current_user_id(), 'linkedin', esc_url_raw($params['linkedin']));
  }

  if(isset($params['github'])) {
    update_user_meta( get_current_user_id(), 'github', esc_url_raw($params['github']));
  }

  if(isset($params['dribbble'])) {
    update_user_meta( get_current_user_id(), 'dribbble', esc_url_raw($params['dribbble']));
  }

  if (is_wp_error($result)) {
    wp_send_json_error(array('message' => esc_html__( 'Error!!! Please contact admin', 'prolancer' )));
  } else {
    wp_send_json_success(array('message' => esc_html__( 'Profile data has been saved!', 'prolancer' )));
  }
  wp_die();
}
add_action( 'wp_ajax_prolancer_ajax_update_seller_profile',  'prolancer_ajax_update_seller_profile' );
add_action( 'wp_ajax_nopriv_prolancer_ajax_update_seller_profile',  'prolancer_ajax_update_seller_profile' );


function prolancer_ajax_upload_file(){
  
  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'upload_file_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
      exit( "No naughty business please" );
  }

  require_once( ABSPATH . 'wp-admin/includes/image.php' );
  require_once( ABSPATH . 'wp-admin/includes/file.php' );
  require_once( ABSPATH . 'wp-admin/includes/media.php' );

  $attachment_id = media_handle_upload( 'file', $_POST['post_id']);

  //Check for errors
  if ( is_wp_error( $attachment_id ) ) {
      wp_send_json_error(array('message' => esc_html__( 'Something went wrong!', 'prolancer' )));
  } else {
      wp_send_json_success(
        array(
          'id' => $attachment_id,
          'type' => get_post_mime_type( $attachment_id ),
          'image' => wp_get_attachment_image( $attachment_id, 'full'),
          'video' => wp_get_attachment_url( $attachment_id )
        )
      );
  }
  wp_die();
}
add_action( 'wp_ajax_prolancer_ajax_upload_file',  'prolancer_ajax_upload_file' );
add_action( 'wp_ajax_nopriv_prolancer_ajax_upload_file',  'prolancer_ajax_upload_file' );


function prolancer_ajax_upload_project_attachments(){
  
  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'upload_file_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
      exit( "No naughty business please" );
  }

  require_once( ABSPATH . 'wp-admin/includes/image.php' );
  require_once( ABSPATH . 'wp-admin/includes/file.php' );
  require_once( ABSPATH . 'wp-admin/includes/media.php' );


  if ( $_FILES ) { 
  $files = $_FILES["attachments"];

    foreach ($files['name'] as $key => $value) {            
      if ($files['name'][$key]) {
        $file = array( 
          'name' => $files['name'][$key],
          'type' => $files['type'][$key], 
          'tmp_name' => $files['tmp_name'][$key], 
          'error' => $files['error'][$key],
          'size' => $files['size'][$key]
        ); 
        $_FILES = array ("attachments" => $file);                
        foreach ($_FILES as $file => $array) {
          $attachment_id[] = array(
            'id' => media_handle_upload( $file, $_POST['project_id']),
            'name' => $array['name'],
            'type' => $array['type'],
            'size' => $array['size']
          );
        }
      } 
    }

    // Add existing id for update
    $exist_ids = get_post_meta($_POST["project_id"], 'attachments', false );       

    if ($exist_ids) {
      foreach ($exist_ids as $exist_id) {
        if ($exist_id) {
          $exist_attachment_ids = array_keys($exist_id);
        }
      }
    }

    if ($attachment_id) {
      foreach ($attachment_id as $attachment) {
        $attachments.='
        <div>
          <img src="'.esc_url( wp_get_attachment_image_src($attachment['id'],'prolancer-100x80',true)[0] ).'">
          <div>
            <h6>'.esc_html($attachment['name']).'</h6>
            <span>File size: '.esc_html($attachment['size']).' KB</span>
            <a href="#" class="delete-attachment" data-project-id="'.$_POST["project_id"].'" data-attachment-id="'.esc_attr( $attachment['id'] ).'" data-nonce="'.wp_create_nonce('delete_attachment_nonce').'"><i class="fas fa-trash-alt"></i></a>
          </div>
        </div>';
        $attachment_ids[] = $attachment['id'];
      }
    }

    if ($exist_attachment_ids) {
      $ids = json_encode(array_merge($attachment_ids,$exist_attachment_ids));
    } else {
      $ids = json_encode($attachment_ids);
    }

    wp_send_json_success(
      array(
        'ids' => $ids,
        'attachments' => $attachments
      )
    );
  } else {
    wp_send_json_error(array('message' => esc_html__( 'Something went wrong!', 'prolancer' )));
  }
  wp_die();
}
add_action('wp_ajax_prolancer_ajax_upload_project_attachments', 'prolancer_ajax_upload_project_attachments');
add_action('wp_ajax_nopriv_prolancer_ajax_upload_project_attachments', 'prolancer_ajax_upload_project_attachments');


function prolancer_ajax_delete_project(){
  
  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'delete_project_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
    exit( "No naughty business please" );
  }

  if ($_POST['project_id']) {
    global $wpdb;
    
    $wpdb->delete('prolancer_reviews',
      array(
        'type' => 'project',
        'project_id' => $_POST['project_id']
      )
    );
    
    $wpdb->delete('prolancer_project_proposals',
      array(
        'project_id' => $_POST['project_id']
      )
    );

    wp_delete_post($_POST['project_id'],true);

    wp_send_json_success(array(
      'message' => esc_html__( 'Project Deleted!', 'prolancer' ),
      'projects_url' => prolancer_get_page_url_by_template('prolancer-dashboard.php').'=projects'
    ));
  } else {
    wp_send_json_error(array('message' => esc_html__( 'Something went wrong!', 'prolancer' )));
  }
  wp_die();
}
add_action('wp_ajax_prolancer_ajax_delete_project', 'prolancer_ajax_delete_project');
add_action('wp_ajax_nopriv_prolancer_ajax_delete_project', 'prolancer_ajax_delete_project');


function prolancer_ajax_upload_message_attachment(){

  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'upload_file_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
      exit( "No naughty business please" );
  }

  require_once( ABSPATH . 'wp-admin/includes/image.php' );
  require_once( ABSPATH . 'wp-admin/includes/file.php' );
  require_once( ABSPATH . 'wp-admin/includes/media.php' );

  $attachment_id = media_handle_upload( 'attachment', $_POST['post_id']);

  if($attachment_id) {
    wp_send_json_success(array(
      'message' => esc_html__( 'Successfully uploaded!', 'prolancer' ),
      'id' => $attachment_id
    ));
  } else {
    wp_send_json_error(array('message' => esc_html__( 'Something went wrong!', 'prolancer' )));
  }
  wp_die();
}
add_action('wp_ajax_prolancer_ajax_upload_message_attachment', 'prolancer_ajax_upload_message_attachment');
add_action('wp_ajax_nopriv_prolancer_ajax_upload_message_attachment', 'prolancer_ajax_upload_message_attachment');


function prolancer_ajax_upload_service_attachments(){

  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'upload_file_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
      exit( "No naughty business please" );
  }

  require_once( ABSPATH . 'wp-admin/includes/image.php' );
  require_once( ABSPATH . 'wp-admin/includes/file.php' );
  require_once( ABSPATH . 'wp-admin/includes/media.php' );


  if ( $_FILES ) { 
  $files = $_FILES["attachments"];

    foreach ($files['name'] as $key => $value) {            
      if ($files['name'][$key]) {
        $file = array( 
          'name' => $files['name'][$key],
          'type' => $files['type'][$key], 
          'tmp_name' => $files['tmp_name'][$key], 
          'error' => $files['error'][$key],
          'size' => $files['size'][$key]
        ); 
        $_FILES = array ("attachments" => $file);                
        foreach ($_FILES as $file => $array) {
          $attachment_id[] = array(
            'id' => media_handle_upload( $file, $_POST['service_id']),
            'name' => $array['name'],
            'type' => $array['type'],
            'size' => $array['size']
          );
        }
      } 
    }

    // Add existing id for update
    $exist_ids = get_post_meta($_POST["service_id"], 'service_attachments', false );       

    if ($exist_ids) {
      foreach ($exist_ids as $exist_id) {
        if ($exist_id) {
          $exist_attachment_ids = array_keys($exist_id);
        }
      }
    }

    if ($attachment_id) {
      foreach ($attachment_id as $attachment) {
        $attachments.='
        <div>
          <img src="'.esc_url( wp_get_attachment_image_src($attachment['id'],'prolancer-100x80',true)[0] ).'">
          <div>
            <h6>'.esc_html($attachment['name']).'</h6>
            <span>File size: '.esc_html($attachment['size']).' KB</span>
            <a href="#" class="delete-attachment" data-service-id="'.$_POST["service_id"].'" data-attachment-id="'.esc_attr( $attachment['id'] ).'" data-nonce="'.wp_create_nonce('delete_attachment_nonce').'"><i class="fas fa-trash-alt"></i></a>
          </div>
        </div>';
      
        $attachment_ids[] = $attachment['id'];
      }
    }

    if ($exist_attachment_ids) {
      $ids = json_encode(array_merge($attachment_ids,$exist_attachment_ids));
    } else {
      $ids = json_encode($attachment_ids);
    }

    wp_send_json_success(
      array(
        'ids' => $ids,
        'attachments' => $attachments
      )
    );
  } else {
    wp_send_json_error(array('message' => esc_html__( 'Something went wrong!', 'prolancer' )));
  }
  wp_die();
}
add_action('wp_ajax_prolancer_ajax_upload_service_attachments', 'prolancer_ajax_upload_service_attachments');
add_action('wp_ajax_nopriv_prolancer_ajax_upload_service_attachments', 'prolancer_ajax_upload_service_attachments');


function prolancer_ajax_delete_service(){
  
  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'delete_service_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
    exit( "No naughty business please" );
  }

  if ($_POST['service_id']) {
    global $wpdb;

    $wpdb->delete('prolancer_reviews',
      array(
        'type' => 'service',
        'project_id' => $_POST['service_id']
      )
    );

    wp_delete_post($_POST['service_id'],true);

    wp_send_json_success(array(
      'message' => esc_html__( 'Service Deleted!', 'prolancer' ),
      'services_url' => prolancer_get_page_url_by_template('prolancer-dashboard.php').'=services'
    ));
  } else {
    wp_send_json_error(array('message' => esc_html__( 'Something went wrong!', 'prolancer' )));
  }
  wp_die();
}
add_action('wp_ajax_prolancer_ajax_delete_service', 'prolancer_ajax_delete_service');
add_action('wp_ajax_nopriv_prolancer_ajax_delete_service', 'prolancer_ajax_delete_service');


function prolancer_ajax_wallet_recharge(){

  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'create_wallet_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
    exit( "No naughty business please" );
  }

  $params = array();
  parse_str($_POST['wallet_data'], $params);

  if ( class_exists( 'WooCommerce' ) ){
    if ($params['wallet_amount'] > 0) {

      global $woocommerce;

      $product_id = wp_insert_post(array(
        'post_title' => 'Recharge wallet',
        'post_status' => 'publish',
        'post_author' => get_current_user_id(),
        'post_type' => 'product'
      ));

      // Product category
      wp_set_object_terms($product_id, 'wallet-deleted', 'product_cat', true);

      // Product type
      wp_set_object_terms( $product_id, 'simple', 'product_type' );  

      // Get the WC_Product Object instance
      $product = wc_get_product( $product_id );

      // Set the product active price (regular)
      $product->set_price( $params['wallet_amount'] );
      $product->set_regular_price( $params['wallet_amount'] ); // To be sure

      // Save product data (sync data and refresh caches)
      $product->save();

      // Add to cart
      if( $woocommerce->cart->add_to_cart($product_id, 1) ) {
        wp_send_json_success(array(
          'message' => esc_html__( 'Redirecting to checkout page', 'prolancer' ),
          'checkout_page' => $woocommerce->cart->get_checkout_url()
        ));
      }            
    }
  } else {
    wp_send_json_error(array('message' => esc_html__( 'WooCommerce plugin is not active', 'prolancer' )));
    exit();
  }
  wp_die();
}
add_action('wp_ajax_prolancer_ajax_wallet_recharge', 'prolancer_ajax_wallet_recharge');
add_action('wp_ajax_nopriv_prolancer_ajax_wallet_recharge', 'prolancer_ajax_wallet_recharge');


function prolancer_ajax_delete_attachment(){

  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'delete_attachment_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
      exit( "No naughty business please" );
  }

  if ($_POST['attachment_id']) {

    if ($_POST['project_id']) {
      $exist_attachment = get_post_meta( $_POST['project_id'], 'attachments', true );
    }elseif ($_POST['service_id']) {
      $exist_attachment = get_post_meta( $_POST['service_id'], 'service_attachments', true );
    }
    
    
    $array1 = array($_POST['attachment_id']);
    $array2 = explode(',', $exist_attachment);
    $array3 = array_diff($array2, $array1);
    wp_delete_attachment( $_POST['attachment_id'] );
    $new_data = implode(',', $array3);

    if ($_POST['project_id']) {
      update_post_meta( $_POST['project_id'], 'attachments', $new_data);
    }elseif ($_POST['service_id']) {
      update_post_meta( $_POST['service_id'], 'service_attachments', $new_data);
    }      

    wp_send_json_success(array('message' => esc_html__( 'Attachment Deleted!', 'prolancer' )));
  } else {
    wp_send_json_error(array('message' => esc_html__( 'Something went wrong!', 'prolancer' )));
  }
  wp_die();
}
add_action('wp_ajax_prolancer_ajax_delete_attachment', 'prolancer_ajax_delete_attachment');
add_action('wp_ajax_nopriv_prolancer_ajax_delete_attachment', 'prolancer_ajax_delete_attachment');


function prolancer_ajax_payout_methods(){

  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'payout_methods_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
      exit( "No naughty business please" );
  }

  $params = array();
  parse_str($_POST['payout_data'], $params);

  update_user_meta( get_current_user_id(), 'payout_methods_data', json_encode($params) );

  if (is_wp_error($params)) {
    wp_send_json_error(array('message' => esc_html__( 'Something went wrong!', 'prolancer' )));
  } else {
    wp_send_json_success(array('message' => esc_html__( 'Data Saved!', 'prolancer' )));
  }
  wp_die();
}
add_action( 'wp_ajax_prolancer_ajax_payout_methods',  'prolancer_ajax_payout_methods' );
add_action( 'wp_ajax_nopriv_prolancer_ajax_payout_methods',  'prolancer_ajax_payout_methods' );


function prolancer_ajax_withdrawal_request(){

  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'payment_withdraw_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
      exit( "No naughty business please" );
  }

  global $prolancer_opt;

  $minimum_threshold = !empty( $prolancer_opt['minimum_threshold'] ) ? $prolancer_opt['minimum_threshold'] : ''; 
  $email_on_withdrawal_money_request = !empty( $prolancer_opt['email_on_withdrawal_money_request'] ) ? $prolancer_opt['email_on_withdrawal_money_request'] : ''; 
  $email_on_withdrawal_money_request_subject = !empty( $prolancer_opt['email_on_withdrawal_money_request_subject'] ) ? $prolancer_opt['email_on_withdrawal_money_request_subject'] : ''; 
  $email_on_withdrawal_money_request_content = !empty( $prolancer_opt['email_on_withdrawal_money_request_content'] ) ? $prolancer_opt['email_on_withdrawal_money_request_content'] : ''; 
  $payout_methods_data = json_decode(get_user_meta( get_current_user_id(), 'payout_methods_data' , true ), true);
  $get_balance = get_user_meta( get_current_user_id(), 'wallet_balance', true );

  if(!empty($get_balance)){
    $wallet_balance = $get_balance;
  }else{
    $wallet_balance = 0;
  }  
  
  $params = array();
  parse_str($_POST['withdraw_data'], $params);

  if ( $wallet_balance >= $params['payout-amount'] ) {

    if ($params['payout-amount'] >= $minimum_threshold) {

      update_user_meta( get_current_user_id(), 'wallet_balance', $wallet_balance-$params['payout-amount']);

      $result = wp_insert_post(array(
        'post_type' => 'payouts',
        'post_title' => get_the_title(get_user_meta( get_current_user_id(), 'seller_id' , true )),
        'post_author' => get_current_user_id(),
        'post_status'   => 'pending'
      ));

      if(isset($params['payout-method'])) {
        update_post_meta( $result, 'payout_method', sanitize_text_field($params['payout-method']));
      }

      if(isset($params['payout-amount'])) {
        update_post_meta( $result, 'payout_amount', sanitize_text_field($params['payout-amount']));
      }

      if(isset($payout_methods_data['paypal-email'])) {
        update_post_meta( $result, 'paypal_email', sanitize_text_field($payout_methods_data['paypal-email']));
      }

      if(isset($payout_methods_data['payoneer-email'])) {
        update_post_meta( $result, 'payoneer_email', sanitize_text_field($payout_methods_data['payoneer-email']));
      }

      if(isset($payout_methods_data['bank-name'])) {
        update_post_meta( $result, 'bank_name', sanitize_text_field($payout_methods_data['bank-name']));
      }

      if(isset($payout_methods_data['bank-account-number'])) {
        update_post_meta( $result, 'bank_account_number', sanitize_text_field($payout_methods_data['bank-account-number']));
      }

      if(isset($payout_methods_data['routing-number'])) {
        update_post_meta( $result, 'routing_number', sanitize_text_field($payout_methods_data['routing-number']));
      }

      if(isset($payout_methods_data['iban'])) {
        update_post_meta( $result, 'iban', sanitize_text_field($payout_methods_data['iban']));
      }

      if(isset($payout_methods_data['bic-swift-code'])) {
        update_post_meta( $result, 'bic_swift_code', sanitize_text_field($payout_methods_data['bic-swift-code']));
      }

      if(isset($payout_methods_data['bank-address'])) {
        update_post_meta( $result, 'bank_address', sanitize_text_field($payout_methods_data['bank-address']));
      }

      if(isset($payout_methods_data['first-name'])) {
        update_post_meta( $result, 'payout_first_name', sanitize_text_field($payout_methods_data['first-name']));
      }

      if(isset($payout_methods_data['last-name'])) {
        update_post_meta( $result, 'payout_last_name', sanitize_text_field($payout_methods_data['last-name']));
      }

      if(isset($payout_methods_data['address'])) {
        update_post_meta( $result, 'payout_address', sanitize_text_field($payout_methods_data['address']));
      }

      if(isset($payout_methods_data['country'])) {
        update_post_meta( $result, 'payout_country', sanitize_text_field($payout_methods_data['country']));
      }

      if (is_wp_error($result)) {
        wp_send_json_error(array('message' => esc_html__( 'Something went wrong!', 'prolancer' )));
      } else {
        if ($email_on_withdrawal_money_request) {
          // wp_mail( $to, $subject, $message, $headers)
          wp_mail( 
            get_option('admin_email'), 
            $email_on_withdrawal_money_request_subject,
            str_replace(
              array('{{site_name}}', '{{username}}', '{{method}}','{{withdrawal_amount}}'),
              array(wp_specialchars_decode(get_bloginfo('name'),ENT_QUOTES), get_user_meta( get_current_user_id(), 'nickname', true ), $params['payout-method'], prolancer_get_currency_symbol($params['payout-amount'])), 
              $email_on_withdrawal_money_request_content
            ), 
            array('Content-Type: text/html; charset=UTF-8', 'From: '.get_option('admin_email'))
          );    
        }

        wp_send_json_success(array('message' => esc_html__( 'Withdrawal request has been submitted!', 'prolancer' )));
      }
    } else {
      wp_send_json_error(array('message' => esc_html__( 'Minimum withdrow amount is ', 'prolancer' ).prolancer_get_currency_symbol($minimum_threshold)));
    }
  } else {
    wp_send_json_error(array('message' => 'You don\'t have enough balance to withdraw' ));
  } 
  wp_die();   
}
add_action( 'wp_ajax_prolancer_ajax_withdrawal_request',  'prolancer_ajax_withdrawal_request' );
add_action( 'wp_ajax_nopriv_prolancer_ajax_withdrawal_request',  'prolancer_ajax_withdrawal_request' );


function prolancer_ajax_verification(){

  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'verification_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
      exit( "No naughty business please" );
  }

  global $prolancer_opt;

  $minimum_threshold = !empty( $prolancer_opt['minimum_threshold'] ) ? $prolancer_opt['minimum_threshold'] : '';
  
  $params = array();
  parse_str($_POST['verification_data'].'&verified=no', $params);

  if($params['user_passport_attachment'] || $params['user_drivers_license_attachment'] || $params['user_id_front_attachment'] || $params['user_id_back_attachment']) {

    if (!empty($params['user_id_front_attachment']) and empty($params['user_id_back_attachment'])) {
      wp_send_json_error(array('message' => esc_html__( 'Please upload a backside picture of the ID card!', 'prolancer' )));
      return;
    }

    if (empty($params['user_id_front_attachment']) and !empty($params['user_id_back_attachment'])) {
      wp_send_json_error(array('message' => esc_html__( 'Please upload a frontside picture of the ID card!', 'prolancer' )));
      return;
    }

    update_user_meta( get_current_user_id(), 'verification' , json_encode($params) );

    $result = wp_insert_post(array(
      'post_type' => 'verification',
      'post_title' => get_user_by( 'id', get_current_user_id())->user_login,
      'post_author' => get_current_user_id(),
      'post_status'   => 'pending'
    ));

    if (is_wp_error($result)) {
      wp_send_json_error(array('message' => esc_html__( 'Something went wrong!', 'prolancer' )));
    } else {
      wp_send_json_success(array('message' => esc_html__( 'Your verification data has been submitted!', 'prolancer' )));
    }  
  } else {
    wp_send_json_error(array('message' => esc_html__( 'Something went wrong!', 'prolancer' )));
  }
  wp_die();
}
add_action( 'wp_ajax_prolancer_ajax_verification',  'prolancer_ajax_verification' );
add_action( 'wp_ajax_nopriv_prolancer_ajax_verification',  'prolancer_ajax_verification' );


function prolancer_ajax_open_dispute(){

  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'open_dispute_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
      exit( "No naughty business please" );
  }

  $buyer_id = get_user_meta( get_current_user_id(), 'buyer_id' , true );

  $params = array();
  parse_str($_POST['disputes_data'], $params);

  if ($params['dispute-details'] !== '') {

    $result = wp_insert_post(array(
      'post_type' => 'disputes',
      'post_title' => get_the_title($params['dispute-id']),
      'post_content' => $params['dispute-details'],
      'post_author' => get_current_user_id(),
      'post_status'   => 'pending'
    ));

    if(isset($buyer_id)) {
      update_post_meta( $result, 'dispute_buyer', sanitize_text_field(get_the_title($buyer_id)));
      update_post_meta( $result, 'dispute_buyer_id',$buyer_id);
    }

    if(isset($params['seller-id'])) {
      update_post_meta( $result, 'dispute_seller', sanitize_text_field(get_the_title($params['seller-id'])));
      update_post_meta( $result, 'dispute_seller_id',$params['seller-id']);
    }

    if(isset($params['amount'])) {
      update_post_meta( $result, 'dispute_price', sanitize_text_field($params['amount']));
    }

    wp_send_json_success(array('message' => esc_html__( 'Your dispute has been submitted!', 'prolancer' )));
  } else {
    wp_send_json_error(array('message' => esc_html__( 'You cannot empty detail field!', 'prolancer' )));
  }
  wp_die();
}
add_action( 'wp_ajax_prolancer_ajax_open_dispute',  'prolancer_ajax_open_dispute' );
add_action( 'wp_ajax_nopriv_prolancer_ajax_open_dispute',  'prolancer_ajax_open_dispute' );


function prolancer_project_ajax_search_form(){

  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'search_form_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
      exit( "No naughty business please" );
  }

  $params = array();
  parse_str($_GET['search_data'], $params);

  $price_from = '';
  if (isset($params['price-from']) && $params['price-from'] != "") {
    $price_from = $params['price-from'];
  }

  $price_to = '';
  if (isset($params['price-to']) && $params['price-to'] != "") {
    $price_to = $params['price-to'];
  }
  
  $project_price = '';
  if ($price_from != "" && $price_to != "") {
    $project_price = array(
      'key' => 'project_price',
      'value' => array($price_from, $price_to),
      'type' => 'numeric',
      'compare' => 'BETWEEN',
    );
  }

  $project_type = '';
  if (isset($params['project_type']) && $params['project_type'] != "") {
    $project_type = array(
      'key' => 'project_type',
      'value' => $params['project_type'],
      'compare' => '=',
    );
  }

  $project_categories = '';
  if (isset($params['project_categories']) && $params['project_categories'] != "") {
    $project_categories = array(
      array(
        'taxonomy' => 'project-categories',
        'field' => 'term_id',
        'terms' => $params['project_categories'],
      ),
    );
  }

  $project_seller_type = '';
  if (isset($params['project_seller_type']) && $params['project_seller_type'] != "") {
    $project_seller_type = array(
      array(
        'taxonomy' => 'project-seller-type',
        'field' => 'id',
        'terms' => $params['project_seller_type'],
      ),
    );
  }

  $project_level = '';
  if (isset($params['project_level']) && $params['project_level'] != "") {
    $project_level = array(
      array(
        'taxonomy' => 'project-level',
        'field' => 'id',
        'terms' => $params['project_level'],
      ),
    );
  }

  $english_level = '';
  if (isset($params['english_level']) && $params['english_level'] != "") {
    $english_level = array(
      array(
        'taxonomy' => 'english-level',
        'field' => 'id',
        'terms' => $params['english_level'],
      ),
    );
  }

  $locations = '';
  if (isset($params['locations']) && $params['locations'] != "") {
    $locations = array(
      array(
        'taxonomy' => 'locations',
        'field' => 'id',
        'terms' => $params['locations'],
      ),
    );
  }

  $languages = '';
  if (isset($params['languages']) && $params['languages'] != "") {
    $languages = array(
      array(
        'taxonomy' => 'languages',
        'field' => 'id',
        'terms' => $params['languages'],
      ),
    );
  }

  $posts = new WP_Query(array(
    // 's' => $title,
    'post_type' => 'projects',
    'post_status' => 'publish',
    'posts_per_page' => -1,
    'meta_query'    => array(
      'relation' => 'OR',
      $project_price,
      $project_type
    ),
    'tax_query' => array(
      $project_categories,
      $project_seller_type,
      $project_level,
      $english_level,
      $locations,
      $languages
    )
  ));

  /* Start the Loop */
  if ( $posts->have_posts() ) {
    while ( $posts->have_posts() ) { $posts->the_post();
      do_action( 'get_prolancer_project_item', 'style-2' );
    }; wp_reset_postdata(); ?>
      <div class="text-center">
      <?php 
      the_posts_pagination( array(
          'mid_size'  => 2,
          'prev_text' => esc_html__( '&#10094; Prev', 'prolancer' ),
          'next_text' => esc_html__( 'Next &#10095;', 'prolancer' ),
      ) ); ?>
      </div>
    <?php
  } else {
    get_template_part( 'template-parts/content', 'none' );
  };
  wp_die();   
}
add_action( 'wp_ajax_prolancer_project_ajax_search_form',  'prolancer_project_ajax_search_form' );
add_action( 'wp_ajax_nopriv_prolancer_project_ajax_search_form',  'prolancer_project_ajax_search_form' );


function prolancer_service_ajax_search_form(){

  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'search_form_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
      exit( "No naughty business please" );
  }

  $params = array();
  parse_str($_GET['search_data'], $params);

  $price_from = '';
  if (isset($params['price-from']) && $params['price-from'] != "") {
    $price_from = $params['price-from'];
  }

  $price_to = '';
  if (isset($params['price-to']) && $params['price-to'] != "") {
    $price_to = $params['price-to'];
  }

  $service_price = '';
  if ($price_from != "" && $price_to != "") {
    $service_price = array(
      'key' => 'service_price',
      'value' => array($price_from, $price_to),
      'type' => 'numeric',
      'compare' => 'BETWEEN',
    );
  }

  $service_categories = '';
  if (isset($params['service_categories']) && $params['service_categories'] != "") {
    $service_categories = array(
      array(
        'taxonomy' => 'service-categories',
        'field' => 'term_id',
        'terms' => $params['service_categories'],
      ),
    );
  }

  $service_locations = '';
  if (isset($params['service_locations']) && $params['service_locations'] != "") {
    $service_locations = array(
      array(
        'taxonomy' => 'service-locations',
        'field' => 'id',
        'terms' => $params['service_locations'],
      ),
    );
  }

  $delivery_time = '';
  if (isset($params['delivery_time']) && $params['delivery_time'] != "") {
    $delivery_time = array(
      array(
        'taxonomy' => 'delivery-time',
        'field' => 'id',
        'terms' => $params['delivery_time'],
      ),
    );
  }

  $posts = new WP_Query(array(
    // 's' => $title,
    'post_type' => 'services',
    'post_status' => 'publish',
    'posts_per_page' => -1,
    'meta_query'    => array(
      'relation' => 'OR',
      $service_price
    ),
    'tax_query' => array(
      $service_categories,
      $service_locations,
      $delivery_time
    )
  ));

  /* Start the Loop */
  if ( $posts->have_posts() ) {
    while ( $posts->have_posts() ) { $posts->the_post(); 
      do_action( 'get_prolancer_service_item', 'style-2' );
    }; wp_reset_postdata(); ?>

      <div class="text-center">
      <?php 
      the_posts_pagination( array(
          'mid_size'  => 2,
          'prev_text' => esc_html__( '&#10094; Prev', 'prolancer' ),
          'next_text' => esc_html__( 'Next &#10095;', 'prolancer' ),
      ) ); ?>
      </div>
    <?php
  } else {
    get_template_part( 'template-parts/content', 'none' );
  };
  wp_die();  
}
add_action( 'wp_ajax_prolancer_service_ajax_search_form',  'prolancer_service_ajax_search_form' );
add_action( 'wp_ajax_nopriv_prolancer_service_ajax_search_form',  'prolancer_service_ajax_search_form' );


function prolancer_buyer_ajax_search_form(){

  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'search_form_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
      exit( "No naughty business please" );
  }

  $params = array();
  parse_str($_GET['search_data'], $params);

  $buyer_departments = '';
  if (isset($params['buyer_departments']) && $params['buyer_departments'] != "") {
    $buyer_departments = array(
      array(
        'taxonomy' => 'buyer-departments',
        'field' => 'term_id',
        'terms' => $params['buyer_departments'],
      ),
    );
  }

  $buyer_locations = '';
  if (isset($params['buyer_locations']) && $params['buyer_locations'] != "") {
    $buyer_locations = array(
      array(
        'taxonomy' => 'buyer-locations',
        'field' => 'id',
        'terms' => $params['buyer_locations'],
      ),
    );
  }

  $employees_number = '';
  if (isset($params['employees_number']) && $params['employees_number'] != "") {
    $employees_number = array(
      array(
        'taxonomy' => 'employees-number',
        'field' => 'id',
        'terms' => $params['employees_number'],
      ),
    );
  }
  
  $posts = new WP_Query(array(
    // 's' => $title,
    'post_type' => 'buyers',
    'post_status' => 'publish',
    'posts_per_page' => -1,
    'tax_query' => array(
      $buyer_departments,
      $buyer_locations,
      $employees_number
    )
  ));

  /* Start the Loop */
  if ( $posts->have_posts() ) {
    while ( $posts->have_posts() ) { $posts->the_post(); 
      do_action( 'get_prolancer_buyer_item', 'style-2' );
    }; wp_reset_postdata(); ?>

      <div class="text-center">
      <?php 
      the_posts_pagination( array(
          'mid_size'  => 2,
          'prev_text' => esc_html__( '&#10094; Prev', 'prolancer' ),
          'next_text' => esc_html__( 'Next &#10095;', 'prolancer' ),
      ) ); ?>
      </div>
    <?php
  } else {
    get_template_part( 'template-parts/content', 'none' );
  };
  wp_die();
}
add_action( 'wp_ajax_prolancer_buyer_ajax_search_form',  'prolancer_buyer_ajax_search_form' );
add_action( 'wp_ajax_nopriv_prolancer_buyer_ajax_search_form',  'prolancer_buyer_ajax_search_form' );


function prolancer_seller_ajax_search_form(){

  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'search_form_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
      exit( "No naughty business please" );
  }

  $params = array();
  parse_str($_GET['search_data'], $params);    

  $price_from = '';
  if (isset($params['price-from']) && $params['price-from'] != "") {
    $price_from = $params['price-from'];
  }

  $price_to = '';
  if (isset($params['price-to']) && $params['price-to'] != "") {
    $price_to = $params['price-to'];
  }

  $seller_hourly_rate = '';
  if ($price_from != "" && $price_to != "") {
    $seller_hourly_rate = array(
      'key' => 'seller_hourly_rate',
      'value' => array($price_from, $price_to),
      'type' => 'numeric',
      'compare' => 'BETWEEN',
    );
  }

  $seller_skills = '';
  if (isset($params['seller_skills']) && $params['seller_skills'] != "") {
    $seller_skills = array(
      array(
        'taxonomy' => 'seller-skills',
        'field' => 'term_id',
        'terms' => $params['seller_skills'],
      ),
    );
  }

  $seller_type = '';
  if (isset($params['seller_type']) && $params['seller_type'] != "") {
    $seller_type = array(
      array(
        'taxonomy' => 'seller-type',
        'field' => 'id',
        'terms' => $params['seller_type'],
      ),
    );
  }

  $seller_locations = '';
  if (isset($params['seller_locations']) && $params['seller_locations'] != "") {
    $seller_locations = array(
      array(
        'taxonomy' => 'seller-locations',
        'field' => 'id',
        'terms' => $params['seller_locations'],
      ),
    );
  }

  $seller_languages = '';
  if (isset($params['seller_languages']) && $params['seller_languages'] != "") {
    $seller_languages = array(
      array(
        'taxonomy' => 'seller-languages',
        'field' => 'id',
        'terms' => $params['seller_languages'],
      ),
    );
  }

  $posts = new WP_Query(array(
    // 's' => $title,
    'post_type' => 'sellers',
    'post_status' => 'publish',
    'posts_per_page' => -1,
    'meta_query'    => array(
      'relation' => 'OR',
      $seller_hourly_rate
    ),
    'tax_query' => array(
      $seller_skills,
      $seller_type,
      $seller_locations,
      $seller_languages
    )
  ));

  /* Start the Loop */
  if ( $posts->have_posts() ) {
    while ( $posts->have_posts() ) { $posts->the_post(); 
      do_action( 'get_prolancer_seller_item', 'style-2' );
    }; wp_reset_postdata(); ?>

      <div class="text-center">
      <?php 
      the_posts_pagination( array(
          'mid_size'  => 2,
          'prev_text' => esc_html__( '&#10094; Prev', 'prolancer' ),
          'next_text' => esc_html__( 'Next &#10095;', 'prolancer' ),
      ) ); ?>
      </div>
    <?php
  } else {
    get_template_part( 'template-parts/content', 'none' );
  };
  wp_die();   
}
add_action( 'wp_ajax_prolancer_seller_ajax_search_form',  'prolancer_seller_ajax_search_form' );
add_action( 'wp_ajax_nopriv_prolancer_seller_ajax_search_form',  'prolancer_seller_ajax_search_form' );


function prolancer_ajax_register(){

  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'register_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
      exit( "No naughty business please" );
  }

  global $prolancer_opt;
  $email_on_registration = !empty( $prolancer_opt['email_on_registration'] ) ? $prolancer_opt['email_on_registration'] : '';
  $email_on_registration_subject = !empty( $prolancer_opt['email_on_registration_subject'] ) ? $prolancer_opt['email_on_registration_subject'] : '';
  $email_on_registration_content = !empty( $prolancer_opt['email_on_registration_content'] ) ? $prolancer_opt['email_on_registration_content'] : '';

  $prolancer_signup_email_verification = !empty( $prolancer_opt['prolancer_signup_email_verification'] ) ? $prolancer_opt['prolancer_signup_email_verification'] : ''; 

  $generate_password = wp_generate_password( 12, true, true );

  $params = array();
  parse_str($_POST['register_data'], $params);

  if (true ==! $prolancer_signup_email_verification) {
    if ($params['password'] == $params['re-password']) {
      $password = $params['password'];
    }

    if (empty($params['password']) and empty($params['re-password'])) {
      wp_send_json_error(array('message' => 'Password Can\'t be empty', 'prolancer' ));
      return;
    }

    if ($params['password'] !== $params['re-password']) {
      wp_send_json_error(array('message' => 'Password didn\'t match', 'prolancer' ));
      return;
    }
  }

  if (get_site_url() !== 'https://themebing.com/wp/prolancer') {
    if (is_email($params['email'])) {
      $user_id = wp_insert_user(array(
        'user_login' => $params['username'],
        'user_email' => $params['email'],
        'first_name' => $params['firstname'],
        'last_name' => $params['lastname'],
        'user_pass' => $prolancer_signup_email_verification ? $generate_password : $password,
        'display_name' => $params['firstname'].' '.$params['lastname'],
        'role' => 'subscriber'
      ));

      if (true == $prolancer_signup_email_verification) {
        if (!is_wp_error( $user_id )) {
          wp_mail( $params['email'], 'Your password is:', $generate_password);
        }
      }

      if (is_wp_error($user_id)) {
        $error  = $user_id->get_error_codes();
      
        if(in_array('empty_user_login', $error))
          wp_send_json_error(array('message'=> $user_id->get_error_message('empty_user_login')));
        elseif(in_array('existing_user_login',$error))
          wp_send_json_error(array('message'=> esc_html__( 'This username is already registered.','prolancer')));
        elseif(in_array('existing_user_email',$error))
            wp_send_json_error(array('message'=> esc_html__('This email address is already registered.','prolancer')));
      } else {
        if (true == $prolancer_signup_email_verification) {
          if ($email_on_registration) {
            // wp_mail( $to, $subject, $message, $headers)
            wp_mail( 
              get_option('admin_email'), 
              $email_on_registration_subject,
              str_replace(
                array('{{site_name}}', '{{full_name}}', '{{email}}'),
                array(wp_specialchars_decode(get_bloginfo('name'),ENT_QUOTES), $params['firstname'].' '.$params['lastname'], $params['email']), 
                $email_on_registration_content
              ), 
              array('Content-Type: text/html; charset=UTF-8', 'From: '.get_option('admin_email'))
            );    
          }
          
          wp_send_json_success(array('message' => esc_html__( 'We have sent password to your mail!', 'prolancer' )));
        } else {

          if ($email_on_registration) {
            // wp_mail( $to, $subject, $message, $headers)
            wp_mail( 
              get_option('admin_email'), 
              $email_on_registration_subject,
              str_replace(
                array('{{site_name}}', '{{full_name}}', '{{email}}'),
                array(wp_specialchars_decode(get_bloginfo('name'),ENT_QUOTES), $params['firstname'].' '.$params['lastname'], $params['email']), 
                $email_on_registration_content
              ), 
              array('Content-Type: text/html; charset=UTF-8', 'From: '.get_option('admin_email'))
            );    
          }

          wp_send_json_success(array('message' => esc_html__( 'Successfully registered!', 'prolancer' )));
        }          
      }
  
    } else {
      wp_send_json_error(array('message' => esc_html__( 'Plesae enter a valid email', 'prolancer' )));
    }
  } else {
    wp_send_json_error(array('message' => esc_html__( 'Registration is not allowed to the demo version!', 'prolancer' )));
  }
  wp_die();
}
add_action( 'wp_ajax_prolancer_ajax_register',  'prolancer_ajax_register' );
add_action( 'wp_ajax_nopriv_prolancer_ajax_register',  'prolancer_ajax_register' );


function prolancer_ajax_login(){

  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'login_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
      exit( "No naughty business please" );
  }

  $params = array();
  parse_str($_POST['login_data'], $params);

  $user = wp_signon( array(
      'user_login'    => $params['username'],
      'user_password' => $params['password'], 
      'remember'      => true
  ), false );

  if ( is_wp_error( $user ) ) {
    wp_send_json_error(array('message' => $user->get_error_message()));
  } else {
    wp_send_json_success(array(
      'redirect' => prolancer_get_page_url_by_template('prolancer-dashboard.php').'=dashboard',
      'message'  => esc_html__( 'Succesfully logged in!', 'prolancer' )
    ));
  }
  wp_die();
}
add_action( 'wp_ajax_prolancer_ajax_login',  'prolancer_ajax_login' );
add_action( 'wp_ajax_nopriv_prolancer_ajax_login',  'prolancer_ajax_login' );


function prolancer_ajax_profile_switcher(){

  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'profile_switcher' ) || ! isset( $_REQUEST['nonce'] ) ) {
      exit( "No naughty business please" );
  }
  
  update_user_meta( get_current_user_id(), 'visit_as', $_POST['visit_as'] );
  wp_send_json_success(array(
    'message'  => esc_html__( 'Successfully switched as a ', 'prolancer' ).$_POST['visit_as']
  ));
  wp_die();
}
add_action( 'wp_ajax_prolancer_ajax_profile_switcher',  'prolancer_ajax_profile_switcher' );
add_action( 'wp_ajax_nopriv_prolancer_ajax_profile_switcher',  'prolancer_ajax_profile_switcher' );


function prolancer_ajax_change_password(){
  
  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'change_password_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
    exit( "No naughty business please" );
  }

  $params = array();
  parse_str($_POST['password_data'], $params);

  $user = get_userdata( $_POST['user_id'] );
  

  if ($_POST['user_id']) {
    if ( wp_check_password( $params['old_password'], $user->data->user_pass, $user->ID ) ) {
      if ($params['new_password']!=='' and $params['confirm_password']!=='') {
        if ($params['new_password'] !== $params['confirm_password'] ) {
          wp_send_json_error(array(
            'message' => esc_html__( 'password not maching', 'prolancer' )
          ));
        } else {
          wp_set_password( $params['new_password'], $_POST['user_id'] );
          wp_send_json_success(array(
            'message' => esc_html__( 'Password changed successfully!', 'prolancer' )
          ));
        }
      } else {
        wp_send_json_error(array('message' => esc_html__( 'Password cannot be empty!', 'prolancer' )));
      }
    } else {
        wp_send_json_error(array('message' => esc_html__( 'Old password not maching!', 'prolancer' )));
    }    
  } else {
    wp_send_json_error(array('message' => esc_html__( 'Something went wrong!', 'prolancer' )));
  }
  wp_die();
}
add_action('wp_ajax_prolancer_ajax_change_password', 'prolancer_ajax_change_password');
add_action('wp_ajax_nopriv_prolancer_ajax_change_password', 'prolancer_ajax_change_password');


function prolancer_ajax_delete_account(){
  
  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'delete_account_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
    exit( "No naughty business please" );
  }

  if ($_POST['user_id']) {
    if( current_user_can('administrator') ) { 
      wp_send_json_success(array(
        'message' => esc_html__( 'Administrator cannot be deleted', 'prolancer' ),
        'home_url' => prolancer_get_page_url_by_template('prolancer-dashboard.php').'=profile'
      ));
    } else {
      wp_delete_user($_POST['user_id'],true);
      wp_send_json_success(array(
        'message' => esc_html__( 'Account Deleted!', 'prolancer' ),
        'home_url' => home_url()
      ));
    }
    
  } else {
    wp_send_json_error(array('message' => esc_html__( 'Something went wrong!', 'prolancer' )));
  }
  wp_die();
}
add_action('wp_ajax_prolancer_ajax_delete_account', 'prolancer_ajax_delete_account');
add_action('wp_ajax_nopriv_prolancer_ajax_delete_account', 'prolancer_ajax_delete_account');


function prolancer_ajax_get_skills_list(){
  
  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'skill_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
    exit( "No naughty business please" );
  }

  $terms = get_terms( array(
    'taxonomy' => 'seller-skills',
    'hide_empty' => false,
    'orderby' => 'name',
  )); ?>

  <div class="row mb-3">
    <div class="col-sm-1">
        <i class="dashicons dashicons-menu"></i>
    </div>
    <div class="col-sm-5 my-auto">
      <select name="seller_skills[]" class="form-control">
        <option><?php echo esc_html__('Skills','prolancer'); ?></option>
        <?php if ($terms) { 
          foreach ($terms as $term) { ?>     
            <option value="<?php echo esc_attr($term->term_id) ?>"><?php echo esc_html($term->name) ?></option>
          <?php }
        } ?>      
      </select>
    </div>
    <div class="col-sm-5 my-auto">
      <input type="number" name='skills_percent[]' class="form-control" min="0" max="100" placeholder="<?php echo esc_html__( 'Percentage', 'prolancer' ); ?>">
    </div>
    <div class="col-sm-1">
      <i class="dashicons dashicons-trash"></i>
    </div>
  </div>

  <?php
  wp_die();
}
add_action('wp_ajax_prolancer_ajax_get_skills_list', 'prolancer_ajax_get_skills_list');
add_action('wp_ajax_nopriv_prolancer_ajax_get_skills_list', 'prolancer_ajax_get_skills_list');


function prolancer_ajax_follow_buyer(){
  
  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'follow_buyer_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
    exit( "No naughty business please" );
  }

  if (get_current_user_id() == "" || get_current_user_id() == 0) {
    wp_send_json_error(array('message' => esc_html__( 'User must logged in', 'prolancer' )));
  }

  if($_POST['post_id'] != '') {
    if( get_user_meta( get_current_user_id(), 'buyer_follow_id_'.$_POST['post_id'], true ) == $_POST['post_id'] ) {
      wp_send_json_error(array('message' => esc_html__( 'You are already following', 'prolancer' )));
    } else {
      update_user_meta( get_current_user_id(), 'buyer_follow_id_' . $_POST['post_id'], $_POST['post_id'] );
      wp_send_json_success(array('message' => esc_html__( 'Added to your following list', 'prolancer' )));
    }
  } else {
    wp_send_json_error(array('message' => esc_html__( 'Something went wrong!', 'prolancer' )));  
  }
  wp_die();
}
add_action('wp_ajax_prolancer_ajax_follow_buyer', 'prolancer_ajax_follow_buyer');
add_action('wp_ajax_nopriv_prolancer_ajax_follow_buyer', 'prolancer_ajax_follow_buyer');


function prolancer_ajax_remove_following_buyer(){
  
  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'remove_following_buyer_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
    exit( "No naughty business please" );
  }

  if ( delete_user_meta(get_current_user_id(), 'buyer_follow_id_'.$_POST['post_id']) ) {
    wp_send_json_success(array('message' => esc_html__( 'Removed from following list', 'prolancer' )));
  } else {
    wp_send_json_error(array('message' => esc_html__( 'Something went wrong!', 'prolancer' )));
  }
  wp_die();
}
add_action('wp_ajax_prolancer_ajax_remove_following_buyer', 'prolancer_ajax_remove_following_buyer');
add_action('wp_ajax_nopriv_prolancer_ajax_remove_following_buyer', 'prolancer_ajax_remove_following_buyer');


function prolancer_ajax_follow_seller(){
  
  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'follow_seller_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
    exit( "No naughty business please" );
  }

  if (get_current_user_id() == "" || get_current_user_id() == 0) {
    wp_send_json_error(array('message' => esc_html__( 'User must logged in', 'prolancer' )));
  }

  if($_POST['post_id'] != '') {
    if( get_user_meta( get_current_user_id(), 'seller_follow_id_'.$_POST['post_id'], true ) == $_POST['post_id'] ) {
      wp_send_json_error(array('message' => esc_html__( 'You are already following', 'prolancer' )));
    } else {
      update_user_meta( get_current_user_id(), 'seller_follow_id_' . $_POST['post_id'], $_POST['post_id'] );
      wp_send_json_success(array('message' => esc_html__( 'Added to your following list', 'prolancer' )));
    }
  } else {
    wp_send_json_error(array('message' => esc_html__( 'Something went wrong!', 'prolancer' )));  
  }
  wp_die();
}
add_action('wp_ajax_prolancer_ajax_follow_seller', 'prolancer_ajax_follow_seller');
add_action('wp_ajax_nopriv_prolancer_ajax_follow_seller', 'prolancer_ajax_follow_seller');


function prolancer_ajax_remove_following_seller(){
  
  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'remove_following_seller_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
    exit( "No naughty business please" );
  }

  if ( delete_user_meta(get_current_user_id(), 'seller_follow_id_'.$_POST['post_id']) ) {
    wp_send_json_success(array('message' => esc_html__( 'Removed from following list', 'prolancer' )));
  } else {
    wp_send_json_error(array('message' => esc_html__( 'Something went wrong!', 'prolancer' )));
  }
  wp_die();
}
add_action('wp_ajax_prolancer_ajax_remove_following_seller', 'prolancer_ajax_remove_following_seller');
add_action('wp_ajax_nopriv_prolancer_ajax_remove_following_seller', 'prolancer_ajax_remove_following_seller');


function prolancer_ajax_wishlist_project(){
  
  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'wishlist_project_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
    exit( "No naughty business please" );
  }

  if (get_current_user_id() == "" || get_current_user_id() == 0) {
    wp_send_json_error(array('message' => esc_html__( 'User must logged in', 'prolancer' )));
  }

  if($_POST['post_id'] != '') {
    if( get_user_meta( get_current_user_id(), 'project_wishlist_id_'.$_POST['post_id'], true ) == $_POST['post_id'] ) {
      wp_send_json_error(array('message' => esc_html__( 'Already added to the wishlist', 'prolancer' )));
    } else {
      update_user_meta( get_current_user_id(), 'project_wishlist_id_' . $_POST['post_id'], $_POST['post_id'] );
      wp_send_json_success(array('message' => esc_html__( 'Added to your wishlist', 'prolancer' )));
    }
  } else {
    wp_send_json_error(array('message' => esc_html__( 'Something went wrong!', 'prolancer' )));  
  }
  wp_die();
}
add_action('wp_ajax_prolancer_ajax_wishlist_project', 'prolancer_ajax_wishlist_project');
add_action('wp_ajax_nopriv_prolancer_ajax_wishlist_project', 'prolancer_ajax_wishlist_project');


function prolancer_ajax_remove_wishlist_project(){
  
  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'remove_wishlist_project_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
    exit( "No naughty business please" );
  }

  if ( delete_user_meta(get_current_user_id(), 'project_wishlist_id_'.$_POST['post_id']) ) {
    wp_send_json_success(array('message' => esc_html__( 'Removed from wishlist', 'prolancer' )));
  } else {
    wp_send_json_error(array('message' => esc_html__( 'Something went wrong!', 'prolancer' )));
  }
  wp_die();
}
add_action('wp_ajax_prolancer_ajax_remove_wishlist_project', 'prolancer_ajax_remove_wishlist_project');
add_action('wp_ajax_nopriv_prolancer_ajax_remove_wishlist_project', 'prolancer_ajax_remove_wishlist_project');


function prolancer_ajax_wishlist_service(){
  
  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'wishlist_service_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
    exit( "No naughty business please" );
  }

  if (get_current_user_id() == "" || get_current_user_id() == 0) {
    wp_send_json_error(array('message' => esc_html__( 'User must logged in', 'prolancer' )));
  }

  if($_POST['post_id'] != '') {
    if( get_user_meta( get_current_user_id(), 'service_wishlist_id_'.$_POST['post_id'], true ) == $_POST['post_id'] ) {
      wp_send_json_error(array('message' => esc_html__( 'Already added to the wishlist', 'prolancer' )));
    } else {
      update_user_meta( get_current_user_id(), 'service_wishlist_id_' . $_POST['post_id'], $_POST['post_id'] );
      wp_send_json_success(array('message' => esc_html__( 'Added to your wishlist', 'prolancer' )));
    }
  } else {
    wp_send_json_error(array('message' => esc_html__( 'Something went wrong!', 'prolancer' )));  
  }
  wp_die();
}
add_action('wp_ajax_prolancer_ajax_wishlist_service', 'prolancer_ajax_wishlist_service');
add_action('wp_ajax_nopriv_prolancer_ajax_wishlist_service', 'prolancer_ajax_wishlist_service');


function prolancer_ajax_remove_wishlist_service(){
  
  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'remove_wishlist_service_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
    exit( "No naughty business please" );
  }

  if ( delete_user_meta(get_current_user_id(), 'service_wishlist_id_'.$_POST['post_id']) ) {
    wp_send_json_success(array('message' => esc_html__( 'Removed from wishlist', 'prolancer' )));
  } else {
    wp_send_json_error(array('message' => esc_html__( 'Something went wrong!', 'prolancer' )));
  }
  wp_die();
}
add_action('wp_ajax_prolancer_ajax_remove_wishlist_service', 'prolancer_ajax_remove_wishlist_service');
add_action('wp_ajax_nopriv_prolancer_ajax_remove_wishlist_service', 'prolancer_ajax_remove_wishlist_service');


function prolancer_ajax_messages(){
  
  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'messages_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
    exit( "No naughty business please" );
  }

  $receiver_id = $_POST['receiver_id'];
  $sender_id = $_POST['sender_id'];
  parse_str($_POST['message_data'], $params);

  if( $params['message'] != '' ) {

    if ($receiver_id == get_current_user_id()) {
      wp_send_json_error(array('message' => esc_html__( 'You cannot send message your own', 'prolancer' )));
      return;
    }

    global $wpdb;

    $wpdb->insert('prolancer_messages',array(
      'timestamp' => current_time('mysql'),
      'updated_on' => current_time('mysql'),
      'message' => sanitize_text_field($params['message']),
      'sender_id' => sanitize_text_field($sender_id),
      'receiver_id' => sanitize_text_field($receiver_id)
    ));

    $msg_id = $wpdb->insert_id;
    
    if($msg_id) {

      $permalink_structure = get_option('permalink_structure') ? '?' : '&';

      prolancer_notifications(
        get_user_meta($sender_id, 'buyer_id' , true ), 
        get_user_meta($receiver_id, 'buyer_id' , true ),
        'message', 
        get_post_meta(get_user_meta($sender_id, 'buyer_id' , true ), 'buyer_profile_name', true ).esc_html__( ' has sent a message', 'prolancer' ),
        get_user_meta($sender_id, 'buyer_id' , true ), 
        esc_url( prolancer_get_page_url_by_template('prolancer-dashboard.php').'=message' )
      );

      prolancer_notifications(
        get_user_meta($sender_id, 'seller_id' , true ), 
        get_user_meta($receiver_id, 'seller_id' , true ),
        'message', 
        get_post_meta(get_user_meta($sender_id, 'seller_id' , true ), 'seller_profile_name', true ).esc_html__( ' has sent a message', 'prolancer' ),
        get_user_meta($sender_id, 'seller_id' , true ), 
        esc_url( prolancer_get_page_url_by_template('prolancer-dashboard.php').'=message' )
      );

      wp_send_json_success(array('message' => esc_html__( 'Message sent', 'prolancer' )));
    } else {
      wp_send_json_error(array('message' => esc_html__( 'Error!!! Message sending failed.', 'prolancer' )));  
    }
  } else {
    wp_send_json_error(array('message' => esc_html__( 'Message field can not be empty', 'prolancer' )));  
  }
  wp_die();
}
add_action('wp_ajax_prolancer_ajax_messages', 'prolancer_ajax_messages');
add_action('wp_ajax_nopriv_prolancer_ajax_messages', 'prolancer_ajax_messages');


function prolancer_ajax_get_additional_service(){

  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'additional_service_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
    exit( "No naughty business please" );
  } ?>

  <div class="row mb-3">
    <div class="col-sm-1">
      <i class="dashicons dashicons-menu"></i>
    </div>
    <div class="col-sm-10 my-auto">
      <input type="text" name='additional_service_title[]' class="form-control" placeholder="<?php echo esc_html__( 'Title', 'prolancer' ); ?>">
      <textarea name='additional_service_description[]' class="form-control" value="<?php echo esc_attr($faqs[$i]['description']) ?>" placeholder="<?php echo esc_html__( 'Description', 'prolancer' ); ?>"></textarea>
      <div class="input-group mb-3">
        <span class="input-group-text"><?php if(class_exists( 'WooCommerce' )){echo esc_html(get_woocommerce_currency_symbol());} ?></span>
        <input type="number" name='additional_service_price[]' class="form-control mb-0" placeholder="<?php echo esc_html__( 'Price', 'prolancer' ); ?>">
      </div>    
    </div>
    <div class="col-sm-1">
      <i class="dashicons dashicons-trash"></i>
    </div>
  </div>

  <?php
  wp_die();
}
add_action('wp_ajax_prolancer_ajax_get_additional_service', 'prolancer_ajax_get_additional_service');
add_action('wp_ajax_nopriv_prolancer_ajax_get_additional_service', 'prolancer_ajax_get_additional_service');


function prolancer_ajax_get_additional_service_price(){ 
  
  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'additional_service_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
    exit( "No naughty business please" );
  }

  $service_id = $_POST['service_id'];
  $additional_service_id = $_POST['additional_service_id'];

  parse_str($_POST['additional_service_data'], $params);
  $additional_service_ids = $params['additional_services'];

  $additional_services =  json_decode(stripslashes(get_post_meta($service_id, 'additional_services', true)), true);

  $total_price = 0;
  $additional_ids = [];

  if($additional_service_ids){
    foreach ($additional_service_ids as $additional_service_id) {
      $total_price += $additional_services[$additional_service_id]['price'];
      $additional_ids[] += $additional_service_id;
    }
  }

  if (isset($total_price)) {
    wp_send_json_success(array(
      'message' => esc_html__( 'Price Updated', 'prolancer' ),
      'total_price' => $total_price,
      'additional_service_ids' => json_encode($additional_ids)
    ));
  }
  wp_die();
}
add_action('wp_ajax_prolancer_ajax_get_additional_service_price', 'prolancer_ajax_get_additional_service_price');
add_action('wp_ajax_nopriv_prolancer_ajax_get_additional_service_price', 'prolancer_ajax_get_additional_service_price');


function prolancer_ajax_notification_clicked(){
  
  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'notification_clicked_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
    exit( "No naughty business please" );
  }

  global $wpdb;
  $wpdb->update('prolancer_notifications',
      array( 
        'updated_on' => current_time('mysql'),
        'read' => true
      ),
      array(
        'id' => $_POST['notification_id']
      )
  );
  
  if(is_wp_error($wpdb)) {
    wp_send_json_error(array('message' => esc_html__( 'Error!', 'prolancer' ))); 
  } else {
    wp_send_json_success(array('message' => esc_html__( 'Success!', 'prolancer' ))); 
  }
  wp_die();
}
add_action('wp_ajax_prolancer_ajax_notification_clicked', 'prolancer_ajax_notification_clicked');
add_action('wp_ajax_nopriv_prolancer_ajax_notification_clicked', 'prolancer_ajax_notification_clicked');


function prolancer_ajax_message_notification_clicked(){
  
  if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'notification_clicked_nonce' ) || ! isset( $_REQUEST['nonce'] ) ) {
    exit( "No naughty business please" );
  }

  global $wpdb;
  $wpdb->update('prolancer_messages',
      array( 
        'updated_on' => current_time('mysql'),
        'read' => true
      ),
      array(
        'id' => $_POST['notification_id']
      )
  );
  
  if(is_wp_error($wpdb)) {
    wp_send_json_error(array('message' => esc_html__( 'Error!', 'prolancer' ))); 
  } else {
    wp_send_json_success(array('message' => esc_html__( 'Success!', 'prolancer' ))); 
  }
  wp_die();
}
add_action('wp_ajax_prolancer_ajax_message_notification_clicked', 'prolancer_ajax_message_notification_clicked');
add_action('wp_ajax_nopriv_prolancer_ajax_message_notification_clicked', 'prolancer_ajax_message_notification_clicked');