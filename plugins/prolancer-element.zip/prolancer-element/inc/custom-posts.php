<?php

if ( ! function_exists('prolancer_custom_post_type') ) {
	
    /**
     * Register a custom post type.
     *
     * @link http://codex.wordpress.org/Function_Reference/register_post_type
     */
    function prolancer_custom_post_type() {

        //Project
        register_post_type(
            'projects', array(
            'labels' => array(
                'name' => __('Projects', 'prolancer'),
                'singular_name' => __('Project', 'prolancer'),
                'menu_name' => __('Projects', 'prolancer'),
                'name_admin_bar' => __('Project', 'prolancer'),
                'add_new' => __('Add New Project', 'prolancer'),
                'add_new_item' => __('Add New Project', 'prolancer'),
                'new_item' => __('New Project', 'prolancer'),
                'edit_item' => __('Edit Project', 'prolancer'),
                'view_item' => __('View Project', 'prolancer'),
                'all_items' => __('All Projects', 'prolancer'),
                'search_items' => __('Search Projects', 'prolancer'),
                'not_found' => __('No Project Found.', 'prolancer'),
            ),
            'description'    => __( 'Description.', 'prolancer' ),
            'menu_icon'      => 'dashicons-clipboard',
            'public'         => true,
            'has_archive'    => true,
            'show_ui'        => true,
            'show_in_menu'   => true,
            'rewrite'        => array( 'slug' => 'projects' ),
            'supports'       => array( 'title','editor', 'author' )
        ));

        // Project taxonomy
        register_taxonomy('project-categories', array('projects'), array(
            'hierarchical' => true,
            'show_ui' => true,
            'label' => __('Project Categories', 'prolancer'),
            'show_admin_column' => true,
            'query_var' => true,
            'meta_box_cb' => false,
            'rewrite' => array('slug' => 'projects-categories'),
        ));

        register_taxonomy('project-seller-type', array('projects'), array(
            'hierarchical' => false,
            'show_ui' => true,
            'labels' => array(
                'name'                       => __( 'Seller Type', 'prolancer' ),
                'search_items'               => __( 'Search Seller Type', 'prolancer' ),
                'popular_items'              => __( 'Popular Seller Type', 'prolancer' ),
                'all_items'                  => __( 'All Seller Type', 'prolancer' ),
                'edit_item'                  => __( 'Edit Seller Type', 'prolancer' ),
                'update_item'                => __( 'Update Seller Type', 'prolancer' ),
                'add_new_item'               => __( 'Add New Seller Type', 'prolancer' ),
                'new_item_name'              => __( 'New Seller Type Name', 'prolancer' ),
                'separate_items_with_commas' => __( 'Separate Seller Type with commas', 'prolancer' ),
                'add_or_remove_items'        => __( 'Add or remove Seller Type', 'prolancer' ),
                'choose_from_most_used'      => __( 'Choose from the most used Seller Type', 'prolancer' ),
                'not_found'                  => __( 'No Seller Type found.', 'prolancer' ),
                'menu_name'                  => __( 'Seller Type', 'prolancer' ),
            ),
            'show_admin_column' => true,
            'query_var' => true,
            'meta_box_cb' => false,
            'rewrite' => array('slug' => 'project-seller-type'),
        ));

        register_taxonomy('project-duration', array('projects'), array(
            'hierarchical' => false,
            'show_ui' => true,
            'labels' => array(
                'name'                       => __( 'Project Duration', 'prolancer' ),
                'search_items'               => __( 'Search Project Duration', 'prolancer' ),
                'popular_items'              => __( 'Popular Project Duration', 'prolancer' ),
                'all_items'                  => __( 'All Project Duration', 'prolancer' ),
                'edit_item'                  => __( 'Edit Project Duration', 'prolancer' ),
                'update_item'                => __( 'Update Project Duration', 'prolancer' ),
                'add_new_item'               => __( 'Add New Project Duration', 'prolancer' ),
                'new_item_name'              => __( 'New Project Duration Name', 'prolancer' ),
                'separate_items_with_commas' => __( 'Separate Project Duration with commas', 'prolancer' ),
                'add_or_remove_items'        => __( 'Add or remove Project Duration', 'prolancer' ),
                'choose_from_most_used'      => __( 'Choose from the most used Project Duration', 'prolancer' ),
                'not_found'                  => __( 'No Project Duration found.', 'prolancer' ),
                'menu_name'                  => __( 'Project Duration', 'prolancer' ),
            ),
            'show_admin_column' => true,
            'query_var' => true,
            'meta_box_cb' => false,
            'rewrite' => array('slug' => 'project-duration'),
        ));

        register_taxonomy('english-level', array('projects'), array(
            'hierarchical' => false,
            'show_ui' => true,
            'labels' => array(
                'name'                       => __( 'English Level', 'prolancer' ),
                'search_items'               => __( 'Search English Level', 'prolancer' ),
                'popular_items'              => __( 'Popular English Level', 'prolancer' ),
                'all_items'                  => __( 'All English Levels', 'prolancer' ),
                'edit_item'                  => __( 'Edit English Level', 'prolancer' ),
                'update_item'                => __( 'Update English Level', 'prolancer' ),
                'add_new_item'               => __( 'Add New English Level', 'prolancer' ),
                'new_item_name'              => __( 'New English Level Name', 'prolancer' ),
                'separate_items_with_commas' => __( 'Separate English Level with commas', 'prolancer' ),
                'add_or_remove_items'        => __( 'Add or remove English Level', 'prolancer' ),
                'choose_from_most_used'      => __( 'Choose from the most used English Levels', 'prolancer' ),
                'not_found'                  => __( 'No English Level found.', 'prolancer' ),
                'menu_name'                  => __( 'English Level', 'prolancer' ),
            ),
            'show_admin_column' => true,
            'query_var' => true,
            'meta_box_cb' => false,
            'rewrite' => array('slug' => 'english-level'),
        )); 


        register_taxonomy('project-level', array('projects'), array(
            'hierarchical' => false,
            'show_ui' => true,
            'labels' => array(
                'name'                       => __( 'Project Level', 'prolancer' ),
                'search_items'               => __( 'Search Project Level', 'prolancer' ),
                'popular_items'              => __( 'Popular Project Level', 'prolancer' ),
                'all_items'                  => __( 'All Project Level', 'prolancer' ),
                'edit_item'                  => __( 'Edit Project Level', 'prolancer' ),
                'update_item'                => __( 'Update Project Level', 'prolancer' ),
                'add_new_item'               => __( 'Add New Project Level', 'prolancer' ),
                'new_item_name'              => __( 'New Project Level Name', 'prolancer' ),
                'separate_items_with_commas' => __( 'Separate Project Levels with commas', 'prolancer' ),
                'add_or_remove_items'        => __( 'Add or remove Project Level', 'prolancer' ),
                'choose_from_most_used'      => __( 'Choose from the most used Project Levels', 'prolancer' ),
                'not_found'                  => __( 'No Project Level found.', 'prolancer' ),
                'menu_name'                  => __( 'Project Level', 'prolancer' ),
            ),
            'show_admin_column' => true,
            'query_var' => true,
            'meta_box_cb' => false,
            'rewrite' => array('slug' => 'project-level'),
        ));

        register_taxonomy('skills', array('projects'), array(
            'hierarchical' => false,
            //'show_ui' => true,
            'labels' => array(
                'name'                       => __( 'Skills', 'prolancer' ),
                'search_items'               => __( 'Search Skills', 'prolancer' ),
                'popular_items'              => __( 'Popular Skills', 'prolancer' ),
                'all_items'                  => __( 'All Skills', 'prolancer' ),
                'edit_item'                  => __( 'Edit Skill', 'prolancer' ),
                'update_item'                => __( 'Update Skill', 'prolancer' ),
                'add_new_item'               => __( 'Add New Skill', 'prolancer' ),
                'new_item_name'              => __( 'New Skill Name', 'prolancer' ),
                'separate_items_with_commas' => __( 'Separate Skills with commas', 'prolancer' ),
                'add_or_remove_items'        => __( 'Add or remove Skills', 'prolancer' ),
                'choose_from_most_used'      => __( 'Choose from the most used Skills', 'prolancer' ),
                'not_found'                  => __( 'No Skill found.', 'prolancer' ),
                'menu_name'                  => __( 'Skills', 'prolancer' ),
            ),
            'show_admin_column' => true,
            'query_var' => true,
            //'meta_box_cb' => false,
            'meta_box_cb' => false,
            'rewrite' => array('slug' => 'skills'),
        ));

        register_taxonomy('languages', array('projects'), array(
            'hierarchical' => false,
            'show_ui' => true,
            'labels' => array(
                'name'                       => __( 'Languages', 'prolancer' ),
                'search_items'               => __( 'Search Languages', 'prolancer' ),
                'popular_items'              => __( 'Popular Languages', 'prolancer' ),
                'all_items'                  => __( 'All Languages', 'prolancer' ),
                'edit_item'                  => __( 'Edit Language', 'prolancer' ),
                'update_item'                => __( 'Update Language', 'prolancer' ),
                'add_new_item'               => __( 'Add New Language', 'prolancer' ),
                'new_item_name'              => __( 'New Language Name', 'prolancer' ),
                'separate_items_with_commas' => __( 'Separate Languages with commas', 'prolancer' ),
                'add_or_remove_items'        => __( 'Add or remove Languages', 'prolancer' ),
                'choose_from_most_used'      => __( 'Choose from the most used Languages', 'prolancer' ),
                'not_found'                  => __( 'No Language found.', 'prolancer' ),
                'menu_name'                  => __( 'Languages', 'prolancer' ),
            ),
            'show_admin_column' => true,
            'query_var' => true,
            'meta_box_cb' => false,
            'rewrite' => array('slug' => 'languages'),
        ));
        
        register_taxonomy('locations', array('projects'), array(
            'hierarchical' => true,
            'show_ui' => true,
            'labels' => array(
                'name'                       => __( 'Locations', 'prolancer' ),
                'search_items'               => __( 'Search Locations', 'prolancer' ),
                'popular_items'              => __( 'Popular Locations', 'prolancer' ),
                'all_items'                  => __( 'All Locations', 'prolancer' ),
                'edit_item'                  => __( 'Edit Location', 'prolancer' ),
                'update_item'                => __( 'Update Location', 'prolancer' ),
                'add_new_item'               => __( 'Add New Location', 'prolancer' ),
                'new_item_name'              => __( 'New Locations Name', 'prolancer' ),
                'separate_items_with_commas' => __( 'Separate Locations with commas', 'prolancer' ),
                'add_or_remove_items'        => __( 'Add or remove Locations', 'prolancer' ),
                'choose_from_most_used'      => __( 'Choose from the most used Locations', 'prolancer' ),
                'not_found'                  => __( 'No Location found.', 'prolancer' ),
                'menu_name'                  => __( 'Locations', 'prolancer' ),
            ),
            'show_admin_column' => true,
            'query_var' => true,
            'meta_box_cb' => false,
            'rewrite' => array('slug' => 'locations'),
        ));


        // Services
        register_post_type('services', array(
            'labels' => array(
                'name' => __('Services', 'prolancer'),
                'singular_name' => __('Services', 'prolancer'),
                'menu_name' => __('Services', 'prolancer'),
                'name_admin_bar' => __('Services', 'prolancer'),
                'add_new' => __('Add New Service', 'prolancer'),
                'add_new_item' => __('Add New Service', 'prolancer'),
                'new_item' => __('New Services', 'prolancer'),
                'edit_item' => __('Edit Services', 'prolancer'),
                'view_item' => __('View Services', 'prolancer'),
                'all_items' => __('All Services', 'prolancer'),
                'search_items' => __('Search Services', 'prolancer'),
                'not_found' => __('No Service Found.', 'prolancer'),
            ),
            'menu_icon'      => 'dashicons-media-archive',
            'public'         => true,
            'has_archive'    => true,
            'show_ui'        => true,
            'show_in_menu'   => true,
            'rewrite'        => array( 'slug' => 'services' ),
            'supports'       => array( 'title','editor','author' )
        ));

        // Services taxonomy
        register_taxonomy('service-categories', array('services'), array(
            'hierarchical' => true,
            'show_ui' => true,
            'label' => __('Service Categories', 'prolancer'),
            'show_admin_column' => true,
            'query_var' => true,
            'meta_box_cb' => false,
            'rewrite' => array('slug' => 'service-categories'),
        ));

        register_taxonomy('delivery-time', array('services'), array(
            'hierarchical' => false,
            'show_ui' => true,
            'labels' => array(
                'name'                       => __( 'Delivery Time', 'prolancer' ),
                'search_items'               => __( 'Search Delivery Time', 'prolancer' ),
                'popular_items'              => __( 'Popular Delivery Times', 'prolancer' ),
                'all_items'                  => __( 'All Delivery Times', 'prolancer' ),
                'edit_item'                  => __( 'Edit Delivery Time', 'prolancer' ),
                'update_item'                => __( 'Update Delivery Time', 'prolancer' ),
                'add_new_item'               => __( 'Add New Delivery Time', 'prolancer' ),
                'new_item_name'              => __( 'New Delivery Time Name', 'prolancer' ),
                'separate_items_with_commas' => __( 'Separate Delivery Times with commas', 'prolancer' ),
                'add_or_remove_items'        => __( 'Add or remove Delivery Time', 'prolancer' ),
                'choose_from_most_used'      => __( 'Choose from the most used Delivery Times', 'prolancer' ),
                'not_found'                  => __( 'No Delivery Time found.', 'prolancer' ),
                'menu_name'                  => __( 'Delivery Time', 'prolancer' ),
            ),
            'show_admin_column' => true,
            'query_var' => true,
            'meta_box_cb' => false,
            'rewrite' => array('slug' => 'delivery-time'),
        ));

        register_taxonomy('service-english-level', array('services'), array(
            'hierarchical' => false,
            'show_ui' => true,
            'labels' => array(
                'name'                       => __( 'English Level', 'prolancer' ),
                'search_items'               => __( 'Search English Level', 'prolancer' ),
                'popular_items'              => __( 'Popular English Level', 'prolancer' ),
                'all_items'                  => __( 'All English Levels', 'prolancer' ),
                'edit_item'                  => __( 'Edit English Level', 'prolancer' ),
                'update_item'                => __( 'Update English Level', 'prolancer' ),
                'add_new_item'               => __( 'Add New English Level', 'prolancer' ),
                'new_item_name'              => __( 'New English Level Name', 'prolancer' ),
                'separate_items_with_commas' => __( 'Separate English Level with commas', 'prolancer' ),
                'add_or_remove_items'        => __( 'Add or remove English Level', 'prolancer' ),
                'choose_from_most_used'      => __( 'Choose from the most used English Levels', 'prolancer' ),
                'not_found'                  => __( 'No English Level found.', 'prolancer' ),
                'menu_name'                  => __( 'English Level', 'prolancer' ),
            ),
            'show_admin_column' => true,
            'query_var' => true,
            'meta_box_cb' => false,
            'rewrite' => array('slug' => 'service-english-level'),
        ));

        register_taxonomy('service-locations', array('services'), array(
            'hierarchical' => true,
            'show_ui' => true,
            'labels' => array(
                'name'                       => __( 'Locations', 'prolancer' ),
                'search_items'               => __( 'Search Locations', 'prolancer' ),
                'popular_items'              => __( 'Popular Locations', 'prolancer' ),
                'all_items'                  => __( 'All Locations', 'prolancer' ),
                'edit_item'                  => __( 'Edit Location', 'prolancer' ),
                'update_item'                => __( 'Update Location', 'prolancer' ),
                'add_new_item'               => __( 'Add New Location', 'prolancer' ),
                'new_item_name'              => __( 'New Locations Name', 'prolancer' ),
                'separate_items_with_commas' => __( 'Separate Locations with commas', 'prolancer' ),
                'add_or_remove_items'        => __( 'Add or remove Locations', 'prolancer' ),
                'choose_from_most_used'      => __( 'Choose from the most used Locations', 'prolancer' ),
                'not_found'                  => __( 'No Location found.', 'prolancer' ),
                'menu_name'                  => __( 'Locations', 'prolancer' ),
            ),
            'show_admin_column' => true,
            'query_var' => true,
            'meta_box_cb' => false,
            'rewrite' => array('slug' => 'service-locations'),
        ));


        //Buyers
        register_post_type(
            'buyers', array(
            'labels' => array(
                'name' => __('Buyers', 'prolancer'),
                'singular_name' => __('Buyer', 'prolancer'),
                'menu_name' => __('Buyers', 'prolancer'),
                'name_admin_bar' => __('Buyers', 'prolancer'),
                'add_new' => __('Add New Buyer', 'prolancer'),
                'add_new_item' => __('Add New Buyer', 'prolancer'),
                'new_item' => __('New Buyer', 'prolancer'),
                'edit_item' => __('Edit Buyer', 'prolancer'),
                'view_item' => __('View Buyer', 'prolancer'),
                'all_items' => __('All Buyers', 'prolancer'),
                'search_items' => __('Search Buyer', 'prolancer'),
                'not_found' => __('No Buyer Found.', 'prolancer'),
            ),
            'menu_icon'      => 'dashicons-businessperson',
            'public'         => true,
            'has_archive'    => true,
            'show_ui'        => true,
            'show_in_menu'   => true,
            'rewrite'        => array( 'slug' => 'buyers' ),
            'supports'       => array( 'title','editor' ),
            'capabilities' => array(
                'create_posts' => false,
            ),
            'map_meta_cap' => true
        ));

        // Buyers taxonomy
        register_taxonomy('buyer-departments', array('buyers'), array(
            'hierarchical' => false,
            'show_ui' => true,
            'labels' => array(
                'name'                       => __( 'Departments', 'prolancer' ),
                'search_items'               => __( 'Search Department', 'prolancer' ),
                'popular_items'              => __( 'Popular Departments', 'prolancer' ),
                'all_items'                  => __( 'All Departments', 'prolancer' ),
                'edit_item'                  => __( 'Edit Department', 'prolancer' ),
                'update_item'                => __( 'Update Department', 'prolancer' ),
                'add_new_item'               => __( 'Add New Department', 'prolancer' ),
                'new_item_name'              => __( 'New Department Name', 'prolancer' ),
                'separate_items_with_commas' => __( 'Separate Departments with commas', 'prolancer' ),
                'add_or_remove_items'        => __( 'Add or remove Department', 'prolancer' ),
                'choose_from_most_used'      => __( 'Choose from the most used Departments', 'prolancer' ),
                'not_found'                  => __( 'No Department found.', 'prolancer' ),
                'menu_name'                  => __( 'Departments', 'prolancer' ),
            ),
            'hierarchical' => false,
            'show_ui' => true,
            'show_admin_column' => true,
            'query_var' => true,
            'meta_box_cb' => false,
            'rewrite' => array('slug' => 'departments'),
        ));

        register_taxonomy('employees-number', array('buyers'), array(
            'hierarchical' => false,
            'show_ui' => true,
            'labels' => array(
                'name'                       => __( 'No. of Employees', 'prolancer' ),
                'search_items'               => __( 'Search No. of Employees', 'prolancer' ),
                'popular_items'              => __( 'Popular No. of Employees', 'prolancer' ),
                'all_items'                  => __( 'All No. of Employees', 'prolancer' ),
                'edit_item'                  => __( 'Edit No. of Employees', 'prolancer' ),
                'update_item'                => __( 'Update No. of Employees', 'prolancer' ),
                'add_new_item'               => __( 'Add New No. of Employee', 'prolancer' ),
                'new_item_name'              => __( 'New No. of Employee Name', 'prolancer' ),
                'separate_items_with_commas' => __( 'Separate No. of Employees with commas', 'prolancer' ),
                'add_or_remove_items'        => __( 'Add or remove No. of Employees', 'prolancer' ),
                'choose_from_most_used'      => __( 'Choose from the most used No. of Employees', 'prolancer' ),
                'not_found'                  => __( 'No No. of Employee found.', 'prolancer' ),
                'menu_name'                  => __( 'No. of Employees', 'prolancer' ),
            ),
            'show_admin_column' => true,
            'query_var' => true,
            'meta_box_cb' => false,
            'rewrite' => array('slug' => 'employees-number'),
        ));

        register_taxonomy('buyer-locations', array('buyers'), array(
            'hierarchical' => true,
            'show_ui' => true,
            'labels' => array(
                'name'                       => __( 'Locations', 'prolancer' ),
                'search_items'               => __( 'Search Locations', 'prolancer' ),
                'popular_items'              => __( 'Popular Locations', 'prolancer' ),
                'all_items'                  => __( 'All Locations', 'prolancer' ),
                'edit_item'                  => __( 'Edit Location', 'prolancer' ),
                'update_item'                => __( 'Update Location', 'prolancer' ),
                'add_new_item'               => __( 'Add New Location', 'prolancer' ),
                'new_item_name'              => __( 'New Locations Name', 'prolancer' ),
                'separate_items_with_commas' => __( 'Separate Locations with commas', 'prolancer' ),
                'add_or_remove_items'        => __( 'Add or remove Locations', 'prolancer' ),
                'choose_from_most_used'      => __( 'Choose from the most used Locations', 'prolancer' ),
                'not_found'                  => __( 'No Location found.', 'prolancer' ),
                'menu_name'                  => __( 'Locations', 'prolancer' ),
            ),
            'show_admin_column' => true,
            'query_var' => true,
            'meta_box_cb' => false,
            'rewrite' => array('slug' => 'buyer-locations'),
        ));


        //Sellers
        register_post_type(
            'sellers', array(
            'labels' => array(
                'name' => __('Sellers', 'prolancer'),
                'singular_name' => __('Seller', 'prolancer'),
                'menu_name' => __('Sellers', 'prolancer'),
                'name_admin_bar' => __('Seller', 'prolancer'),
                'add_new' => __('Add New Seller', 'prolancer'),
                'add_new_item' => __('Add New seller', 'prolancer'),
                'new_item' => __('New seller', 'prolancer'),
                'edit_item' => __('Edit seller', 'prolancer'),
                'view_item' => __('View seller', 'prolancer'),
                'all_items' => __('All sellers', 'prolancer'),
                'search_items' => __('Search seller', 'prolancer'),
                'not_found' => __('No seller Found.', 'prolancer'),
            ),
            'menu_icon'      => 'dashicons-nametag',
            'public'         => true,
            'has_archive'    => true,
            'show_ui'        => true,
            'show_in_menu'   => true,
            'rewrite'        => array( 'slug' => 'sellers' ),
            'supports'       => array( 'title','editor' ),
            'capabilities' => array(
                'create_posts' => false,
            ),
            'map_meta_cap' => true
        ));

        // Sellers taxonomy
        register_taxonomy('seller-skills', array('sellers'), array(
            'hierarchical' => false,
            'show_ui' => true,
            'labels' => array(
                'name'                       => __( 'Skills', 'prolancer' ),
                'search_items'               => __( 'Search Skills', 'prolancer' ),
                'popular_items'              => __( 'Popular Skills', 'prolancer' ),
                'all_items'                  => __( 'All Skills', 'prolancer' ),
                'edit_item'                  => __( 'Edit Skill', 'prolancer' ),
                'update_item'                => __( 'Update Skill', 'prolancer' ),
                'add_new_item'               => __( 'Add New Skill', 'prolancer' ),
                'new_item_name'              => __( 'New Skill Name', 'prolancer' ),
                'separate_items_with_commas' => __( 'Separate Skills with commas', 'prolancer' ),
                'add_or_remove_items'        => __( 'Add or remove Skills', 'prolancer' ),
                'choose_from_most_used'      => __( 'Choose from the most used Skills', 'prolancer' ),
                'not_found'                  => __( 'No Skills found.', 'prolancer' ),
                'menu_name'                  => __( 'Skills', 'prolancer' ),
            ),
            'show_admin_column' => true,
            'query_var' => true,
            'meta_box_cb' => false,
            'rewrite' => array('slug' => 'skills'),
        ));

        register_taxonomy('seller-locations', array('sellers'), array(
            'hierarchical' => true,
            'show_ui' => true,
            'labels' => array(
                'name'                       => __( 'Locations', 'prolancer' ),
                'search_items'               => __( 'Search Locations', 'prolancer' ),
                'popular_items'              => __( 'Popular Locations', 'prolancer' ),
                'all_items'                  => __( 'All Locations', 'prolancer' ),
                'edit_item'                  => __( 'Edit Location', 'prolancer' ),
                'update_item'                => __( 'Update Location', 'prolancer' ),
                'add_new_item'               => __( 'Add New Location', 'prolancer' ),
                'new_item_name'              => __( 'New Locations Name', 'prolancer' ),
                'separate_items_with_commas' => __( 'Separate Locations with commas', 'prolancer' ),
                'add_or_remove_items'        => __( 'Add or remove Locations', 'prolancer' ),
                'choose_from_most_used'      => __( 'Choose from the most used Locations', 'prolancer' ),
                'not_found'                  => __( 'No Location found.', 'prolancer' ),
                'menu_name'                  => __( 'Locations', 'prolancer' ),
            ),
            'show_admin_column' => true,
            'query_var' => true,
            'meta_box_cb' => false,
            'rewrite' => array('slug' => 'seller-locations'),
        ));

        register_taxonomy('seller-languages', array('sellers'), array(
            'hierarchical' => false,
            'show_ui' => true,
            'labels' => array(
                'name'                       => __( 'Languages', 'prolancer' ),
                'search_items'               => __( 'Search Languages', 'prolancer' ),
                'popular_items'              => __( 'Popular Languages', 'prolancer' ),
                'all_items'                  => __( 'All Languages', 'prolancer' ),
                'edit_item'                  => __( 'Edit Language', 'prolancer' ),
                'update_item'                => __( 'Update Language', 'prolancer' ),
                'add_new_item'               => __( 'Add New Language', 'prolancer' ),
                'new_item_name'              => __( 'New Language Name', 'prolancer' ),
                'separate_items_with_commas' => __( 'Separate Languages with commas', 'prolancer' ),
                'add_or_remove_items'        => __( 'Add or remove Languages', 'prolancer' ),
                'choose_from_most_used'      => __( 'Choose from the most used Languages', 'prolancer' ),
                'not_found'                  => __( 'No Language found.', 'prolancer' ),
                'menu_name'                  => __( 'Languages', 'prolancer' ),
            ),
            'show_admin_column' => true,
            'query_var' => true,
            'meta_box_cb' => false,
            'rewrite' => array('slug' => 'languages'),
        ));
        

        register_taxonomy('seller-type', array('sellers'), array(
            'hierarchical' => false,
            'show_ui' => true,
            'labels' => array(
                'name'                       => __( 'Seller Type', 'prolancer' ),
                'search_items'               => __( 'Search Seller Type', 'prolancer' ),
                'popular_items'              => __( 'Popular Seller Type', 'prolancer' ),
                'all_items'                  => __( 'All Selle Type', 'prolancer' ),
                'edit_item'                  => __( 'Edit Seller Type', 'prolancer' ),
                'update_item'                => __( 'Update Seller Type', 'prolancer' ),
                'add_new_item'               => __( 'Add New Seller Type', 'prolancer' ),
                'new_item_name'              => __( 'New Seller Type Name', 'prolancer' ),
                'separate_items_with_commas' => __( 'Separate Seller Type with commas', 'prolancer' ),
                'add_or_remove_items'        => __( 'Add or remove Seller Type', 'prolancer' ),
                'choose_from_most_used'      => __( 'Choose from the most used Seller Type', 'prolancer' ),
                'not_found'                  => __( 'No Seller Type found.', 'prolancer' ),
                'menu_name'                  => __( 'Seller Type', 'prolancer' ),
            ),
            'show_admin_column' => true,
            'query_var' => true,
            'meta_box_cb' => false,
            'rewrite' => array('slug' => 'seller-type'),
        ));

        register_taxonomy('seller-english-level', array('sellers'), array(
            'hierarchical' => false,
            'show_ui' => true,
            'labels' => array(
                'name'                       => __( 'English Level', 'prolancer' ),
                'search_items'               => __( 'Search English Level', 'prolancer' ),
                'popular_items'              => __( 'Popular English Level', 'prolancer' ),
                'all_items'                  => __( 'All English Levels', 'prolancer' ),
                'edit_item'                  => __( 'Edit English Level', 'prolancer' ),
                'update_item'                => __( 'Update English Level', 'prolancer' ),
                'add_new_item'               => __( 'Add New English Level', 'prolancer' ),
                'new_item_name'              => __( 'New English Level Name', 'prolancer' ),
                'separate_items_with_commas' => __( 'Separate English Level with commas', 'prolancer' ),
                'add_or_remove_items'        => __( 'Add or remove English Level', 'prolancer' ),
                'choose_from_most_used'      => __( 'Choose from the most used English Levels', 'prolancer' ),
                'not_found'                  => __( 'No English Level found.', 'prolancer' ),
                'menu_name'                  => __( 'English Level', 'prolancer' ),
            ),
            'show_admin_column' => true,
            'query_var' => true,
            'meta_box_cb' => false,
            'rewrite' => array('slug' => 'seller-english-level'),
        ));

        // Payouts
        register_post_type('payouts', array(
            'labels' => array(
                'name' => __('Payouts', 'prolancer'),
                'singular_name' => __('Payouts', 'prolancer'),
                'menu_name' => __('Payouts', 'prolancer'),
                'name_admin_bar' => __('Payouts', 'prolancer'),
                'add_new' => __('Add New Payout', 'prolancer'),
                'add_new_item' => __('Add New Payout', 'prolancer'),
                'new_item' => __('New Payouts', 'prolancer'),
                'edit_item' => __('Edit Payouts', 'prolancer'),
                'view_item' => __('View Payouts', 'prolancer'),
                'all_items' => __('All Payouts', 'prolancer'),
                'search_items' => __('Search Payouts', 'prolancer'),
                'not_found' => __('No Payout Found.', 'prolancer'),
            ),
            'menu_icon'      => 'dashicons-money-alt',
            'public'         => true,
            'show_ui'        => true,
            'rewrite'        => array( 'slug' => 'payouts' ),
            'supports'       => array( 'title' ),
            'hierarchical'   => true,
            'has_archive'    => true,
            'capabilities'   => array(
                'create_posts' => false,
            ),
            'map_meta_cap' => true
        ));


        //Verification
        register_post_type(
            'verification', array(
            'labels' => array(
                'name' => __('Verification', 'prolancer'),
                'singular_name' => __('Verification', 'prolancer'),
                'menu_name' => __('Verification', 'prolancer'),
                'name_admin_bar' => __('Verification', 'prolancer'),
                'edit_item' => __('Edit Verification', 'prolancer'),
                'view_item' => __('View Verification', 'prolancer'),
                'all_items' => __('All Verification', 'prolancer'),
                'search_items' => __('Search Verification', 'prolancer'),
                'not_found' => __('No Verification Found.', 'prolancer'),
            ),
            'menu_icon'      => 'dashicons-yes-alt',
            'public'         => false,
            'show_ui'        => true,
            'rewrite'        => array( 'slug' => 'verification' ),
            'supports'       => array( 'title' ),
            'capabilities' => array(
                'create_posts' => false,
            ),
            'map_meta_cap' => true
        ));


        // Disputes
        register_post_type('disputes', array(
            'public' => true,
            'labels' => array(
                'name' => __('Disputes', 'prolancer'),
                'singular_name' => __('Disputes', 'prolancer'),
                'menu_name' => __('Disputes', 'prolancer'),
                'name_admin_bar' => __('Disputes', 'prolancer'),
                'add_new' => __('Add New Dispute', 'prolancer'),
                'add_new_item' => __('Add New Dispute', 'prolancer'),
                'new_item' => __('New Disputes', 'prolancer'),
                'edit_item' => __('Edit Disputes', 'prolancer'),
                'view_item' => __('View Disputes', 'prolancer'),
                'all_items' => __('All Disputes', 'prolancer'),
                'search_items' => __('Search Disputes', 'prolancer'),
                'not_found' => __('No Dispute Found.', 'prolancer'),
            ),
            'menu_icon'      => 'dashicons-hammer',
            'public'         => false,
            'show_ui'        => true,
            'rewrite'        => array( 'slug' => 'disputes' ),
            'supports'       => array( 'title','editor' ),
            'hierarchical'   => false,
            'has_archive'    => false,
            'capabilities'   => array(
                'create_posts' => false,
            ),
            'map_meta_cap' => true
        ));

    }

    add_action( 'init', 'prolancer_custom_post_type' );

}