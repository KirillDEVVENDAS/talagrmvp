<?php 
namespace Elementor;
 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// categories
class prolancer_Widget_Service_Categories extends Widget_Base {
 
   public function get_name() {
      return 'service-categories';
   }
 
   public function get_title() {
      return esc_html__( 'Service Categories', 'prolancer' );
   }
 
   public function get_icon() { 
        return 'eicon-product-categories';
   }
 
   public function get_categories() {
      return [ 'prolancer-elements' ];
   }

   protected function register_controls() {

      $this->start_controls_section(
         'categories_section',
         [
            'label' => esc_html__( 'Service Categories', 'prolancer' ),
            'type' => Controls_Manager::SECTION,
         ]
      );

      $this->add_control(
         'columns',
         [
            'label' => esc_html__( 'Columns', 'prolancer' ),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'col-md-4',
            'options' => [
               'col-xl-12'  => esc_html__( 'Column 1', 'prolancer' ),
               'col-xl-6' => esc_html__( 'Column 2', 'prolancer' ),
               'col-xl-4 col-md-6' => esc_html__( 'Column 3', 'prolancer' ),
               'col-xl-3 col-lg-4 col-md-6' => esc_html__( 'Column 4', 'prolancer' ),
               'col' => esc_html__( 'Column 5', 'prolancer' ),
               'col-xl-2' => esc_html__( 'Column 6', 'prolancer' ),
               'col-xl-1' => esc_html__( 'Column 12', 'prolancer' ),
            ]
         ]
      );

      $this->add_control(
         'category',
         [
            'label' => esc_html__( 'Category', 'prolancer' ),
            'type' => Controls_Manager::SELECT2, 
            'title' => esc_html__( 'Select a category', 'prolancer' ),
            'multiple' => true,
            'options' => prolancer_get_terms_dropdown_array([
               'taxonomy' => 'service-categories',
               'hide_empty' => false,
               'parent' => 0
            ]),
         ]
      );


      $this->add_control(
         'slide',
         [
            'label' => esc_html__( 'Slide', 'prolancer' ),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'label_on' => esc_html__( 'On', 'prolancer' ),
            'label_off' => esc_html__( 'Off', 'prolancer' ),
            'return_value' => true,
            'default' => false,
         ]
      );


      $this->add_control(
         'slidestoshow',
         [
            'label' => esc_html__('Slides To Show', 'prolancer' ),
            'type' => Controls_Manager::NUMBER,
            'min' => 1,
            'max' => 100,
            'step' => 1,
            'default' => 4,
            'condition' => [
               'slide' => ['true']
            ]
         ]
      );

      $this->add_control(
         'slidestoscroll',
         [
            'label' => esc_html__( 'Slides To Scroll', 'prolancer' ),
            'type' => Controls_Manager::NUMBER,
            'min' => 1,
            'max' => 10,
            'step' => 1,
            'default' => 4,
            'condition' => [
               'slide' => ['true']
            ]
         ]
      );
            
      $this->end_controls_section();

   }

  protected function render( $instance = [] ) {
 
    // get our input from the widget settings.
     
    $settings = $this->get_settings_for_display(); ?>

   <?php
   $terms =  $settings['category'];
   if ( $terms ) { ?>
      <div class="container">
         <div class="row" <?php if ($settings['slide'] == true){ ?> id="service-categories" data-slick='{"slidesToShow": <?php echo esc_attr( $settings['slidestoshow'] ) ?>, "slidesToScroll": <?php echo esc_attr( $settings['slidestoscroll'] ) ?>}'<?php } ?>>
            <?php foreach( $terms as $term ) { ?>
               <div class="<?php echo esc_attr($settings['columns']) ?> <?php if ($settings['slide'] == true){echo esc_attr('pr-15 pl-15');} ?>">
                  <a class="service-category-item" href="<?php echo esc_url( get_category_link( $term ) ) ?>" style="background: url('<?php echo wp_get_attachment_image_src( get_term_meta( $term, 'category-image-id', true ),'prolancer-400-400' )[0]  ?>');">
                     <span><?php echo esc_html( get_the_category_by_ID( $term ) ) ?></span>
                  </a>
               </div>
            <?php } ?>
         </div>
      </div>
      <?php
      }
   } 
}

Plugin::instance()->widgets_manager->register_widget_type( new prolancer_Widget_Service_Categories );