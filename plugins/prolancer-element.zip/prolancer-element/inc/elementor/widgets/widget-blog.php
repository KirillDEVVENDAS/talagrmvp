<?php 
namespace Elementor;
 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
// blog
class prolancer_Widget_Blog extends Widget_Base {
 
   public function get_name() {
      return 'blog';
   }
 
   public function get_title() {
      return esc_html__( 'Latest Blog', 'prolancer' );
   }
 
   public function get_icon() { 
        return 'eicon-posts-carousel';
   }
 
   public function get_categories() {
      return [ 'prolancer-elements' ];
   }
   protected function register_controls() {

      $this->start_controls_section(
         'blog_section',
         [
            'label' => esc_html__( 'Blog', 'prolancer' ),
            'type' => Controls_Manager::SECTION,
         ]
      );

      $this->add_control(
         'columns',
         [
            'label' => esc_html__( 'Columns', 'prolancer' ),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'col-xl-4',
            'options' => [
               'col-xl-12'  => esc_html__( 'Column 1', 'prolancer' ),
               'col-xl-6' => esc_html__( 'Column 2', 'prolancer' ),
               'col-xl-4 col-md-6' => esc_html__( 'Column 3', 'prolancer' ),
               'col-xl-3 col-lg-4 col-md-6' => esc_html__( 'Column 4', 'prolancer' ),
               'col-xl-2' => esc_html__( 'Column 6', 'prolancer' ),
               'col-xl-1' => esc_html__( 'Column 12', 'prolancer' ),
            ],
         ]
      );

      $this->add_control(
         'ppp',
         [
            'label' => esc_html__( 'Number of Items', 'prolancer' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
               'no' => [
                  'min' => 0,
                  'max' => 100,
                  'step' => 1,
               ],
            ],
            'default' => [
               'size' => 3,
            ]
         ]
      );

      $this->add_control(
         'order',
         [
            'label' => esc_html__( 'Order', 'prolancer' ),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'DESC',
            'options' => [
               'ASC'  => esc_html__( 'Ascending', 'prolancer' ),
               'DESC' => esc_html__( 'Descending', 'prolancer' )
            ],
         ]
      );

      $this->end_controls_section();
   }

   protected function render( $instance = [] ) {
 
      // get our input from the widget settings.
       
      $settings = $this->get_settings_for_display();
      
      //Inline Editing
      $this->add_inline_editing_attributes( 'ppp', 'basic' );
      ?>

      <div class="row justify-content-center">
         <?php
         $blog = new \WP_Query( array( 
            'post_type' => 'post',
            'posts_per_page' => $settings['ppp']['size'],
            'ignore_sticky_posts' => true,
            'order' => $settings['order'],
         ));
         /* Start the Loop */
         while ( $blog->have_posts() ) : $blog->the_post();
         ?>
         <!-- blog -->
         <div class="<?php echo esc_attr($settings['columns']) ?> col-md-6">
            <div class="blog-item">
               <?php if (has_post_thumbnail()): ?>
               <div class="blog-thumb">
                  <a href="<?php the_permalink() ?>">
                     <?php the_post_thumbnail( 'prolancer-600x399' ) ?>
                  </a>
               </div>
               <?php endif ?> 
               <div class="blog-content">
                  <div class="blog-meta">
                     <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ); ?>">
                     <img src="<?php echo esc_url( get_avatar_url( get_the_author_meta( 'ID' ) ) ); ?>" alt="<?php the_author(); ?>"></a>
                     <span class="pr-10"> - <?php the_author(); ?></span>
                     |
                     <span class="pl-10">
                        <?php $categories = get_the_category();
                        if ( ! empty( $categories ) ) {
                            echo '<a href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>';
                        }?>
                     </span>
                  </div>
                  <h4><a href="<?php the_permalink() ?>"><?php echo mb_strimwidth( get_the_title(), 0, 55, '...' );?></a></h4>
               </div>
            </div>
         </div>
         <?php 
         endwhile; 
         wp_reset_postdata();
         ?>
      </div>
      <?php
   }
 
}
Plugin::instance()->widgets_manager->register_widget_type( new prolancer_Widget_Blog );