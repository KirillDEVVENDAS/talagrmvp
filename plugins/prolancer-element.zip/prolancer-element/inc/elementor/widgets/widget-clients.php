<?php 
namespace Elementor;
 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
// Clients item
class prolancer_Widget_Clients extends Widget_Base {
 
   public function get_name() {
      return 'clients';
   }
 
   public function get_title() {
      return esc_html__( 'Clients', 'prolancer' );
   }
 
   public function get_icon() { 
        return 'eicon-welcome';
   }
 
   public function get_categories() {
      return [ 'prolancer-elements' ];
   }
   protected function register_controls() {
      $this->start_controls_section(
         'clients_section',
         [
            'label' => esc_html__( 'Clients', 'prolancer' ),
            'type' => Controls_Manager::SECTION,
         ]
      );

      $clients = new \Elementor\Repeater();

      $clients->add_control(
         'logo',
         [
            'label' => esc_html__( 'Choose logo', 'prolancer' ),
            'type' => \Elementor\Controls_Manager::MEDIA,
            'default' => [
               'url' => \Elementor\Utils::get_placeholder_image_src(),
            ]
         ]
      );
      $clients->add_control(
         'url',
         [
            'label' => esc_html__( 'URL', 'prolancer' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => '#',
         ]
      );

      $this->add_control(
         'clients',
         [
            'label' => esc_html__( 'Clients', 'prolancer' ),
            'type' => \Elementor\Controls_Manager::REPEATER,
            'fields' => $clients->get_controls()
         ]
      );
      
      $this->end_controls_section();
   }
   protected function render( $instance = [] ) {
 
      // get our input from the widget settings.       
      $settings = $this->get_settings_for_display(); ?>
      <div class="clients">
         <?php 
         foreach (  $settings['clients'] as $client ) { ?>
            <a href="<?php echo esc_url( $client['url'] ); ?>"><img src="<?php echo esc_url( $client['logo']['url'] ); ?>" alt="<?php echo esc_attr( $client['logo']['alt'] ); ?>"></a>
         <?php 
         } ?>
      </div>
      <?php
   }
 
}
Plugin::instance()->widgets_manager->register_widget_type( new prolancer_Widget_Clients );