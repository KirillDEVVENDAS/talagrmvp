<?php 
namespace Elementor;
 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Login and Register
class prolancer_Login_and_Register extends Widget_Base {
 
   public function get_name() {
      return 'login_and_register';
   }
 
   public function get_title() {
      return esc_html__( 'Login and Register', 'prolancer' );
   }
 
   public function get_icon() { 
        return 'eicon-accordion';
   }
 
   public function get_categories() {
      return [ 'prolancer-elements' ];
   }

   protected function register_controls() {

      $this->start_controls_section(
         'login_and_register_section',
         [
            'label' => esc_html__( 'Login and Register', 'prolancer' ),
            'type' => Controls_Manager::SECTION,
         ]
      );

      $this->end_controls_section();

   }

   protected function render( $instance = [] ) {

   global $prolancer_opt;

   $prolancer_signup_email_verification = !empty( $prolancer_opt['prolancer_signup_email_verification'] ) ? $prolancer_opt['prolancer_signup_email_verification'] : '';
 
   // get our input from the widget settings. 
   if(!is_user_logged_in()){ ?>
      <div class="login-and-register">
         <?php the_custom_logo(); ?>
         <nav class="mb-3">
           <div class="nav nav-tabs" id="nav-tab" role="tablist">
             <div class="nav-link active" data-bs-toggle="tab" data-bs-target="#login"aria-controls="nav-home" aria-selected="true"><?php echo esc_html__( 'Login', 'prolancer' ) ?></div>
             <div class="nav-link" data-bs-toggle="tab" data-bs-target="#register" aria-controls="nav-profile" aria-selected="false"><?php echo esc_html__( 'Register', 'prolancer' ) ?></div>
           </div>
         </nav>
         <div class="tab-content" id="nav-tabContent">
            <div class="tab-pane fade show active" id="login" role="tabpanel">
               <form id="login-form">
                  <input type="text" name="username" placeholder="<?php echo esc_html__( 'Username', 'prolancer' ) ?>">
                  <input type="password" name="password" placeholder="<?php echo esc_html__( 'Password', 'prolancer' ) ?>">
                  <a href="#" id="login-submit" data-nonce="<?php echo wp_create_nonce('login_nonce'); ?>" class="prolancer-btn"><?php echo esc_html__( 'Login','prolancer' ) ?></a>
               </form>
               <a href="<?php echo esc_url( home_url( '/wp-login.php?action=lostpassword' )); ?>" class="mt-4 pt-2 d-block lost-password" alt="<?php echo esc_attr__( 'Lost password', 'prolancer' ); ?>">
                   <?php echo esc_html__( 'Lost password', 'prolancer' ); ?>
               </a>
            </div>
            <div class="tab-pane fade" id="register" role="tabpanel">
               <form id="register-form">
                  <div class="row">
                     <div class="col-md-6"><input type="text" name="firstname" placeholder="<?php echo esc_html__( 'First name', 'prolancer' ) ?>"></div>
                     <div class="col-md-6"><input type="text" name="lastname" placeholder="<?php echo esc_html__( 'Last name', 'prolancer' ) ?>"></div>
                  </div>
                  <input type="text" name="username" placeholder="<?php echo esc_html__( 'Username', 'prolancer' ) ?>">
                  <input type="email" name="email" placeholder="<?php echo esc_html__( 'Email', 'prolancer' ) ?>">
                  <?php

                   if(true ==! $prolancer_signup_email_verification ){ ?>
                     <input type="password" name="password" placeholder="<?php echo esc_html__( 'Password', 'prolancer' ) ?>">
                     <input type="password" name="re-password" placeholder="<?php echo esc_html__( 'Repeat password', 'prolancer' ) ?>">
                  <?php } ?>
                  <a href="#" id="register-submit" data-nonce="<?php echo wp_create_nonce('register_nonce'); ?>" class="prolancer-btn"><?php echo esc_html__( 'Register','prolancer' ) ?></a>
               </form>
            </div>
         </div>
      </div>
   <?php } else { ?>
      <script type="text/javascript">
         <?php if($_GET['action']!=='elementor'){ ?>
            location.href = '<?php echo esc_url( home_url( '/' ) ); ?>';
         <?php } ?>            
      </script>
   <?php }
   }

}

Plugin::instance()->widgets_manager->register_widget_type( new prolancer_Login_and_Register );