<?php 
namespace Elementor;
 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Banner
class prolancer_Widget_Search_Banner extends Widget_Base {
 
   public function get_name() {
      return 'search_banner';
   }
 
   public function get_title() {
      return esc_html__( 'Search Banner', 'prolancer' );
   }
 
   public function get_icon() { 
        return 'eicon-slider-video';
   }
 
   public function get_categories() {
      return [ 'prolancer-elements' ];
   }

   protected function register_controls() {

      $this->start_controls_section(
         'search_banner_section',
         [
            'label' => esc_html__( 'Search Banner', 'prolancer' ),
            'type' => Controls_Manager::SECTION,
         ]
      );

      $this->add_control(
         'title',
         [
            'label' => esc_html__( 'Title', 'prolancer' ),
            'type' => \Elementor\Controls_Manager::TEXTAREA,
            'default' => esc_html__('Hire Expert & Get ','prolancer' )
         ]
      );

      $this->add_control(
         'colored_title',
         [
            'label' => esc_html__( 'Colored Title', 'prolancer' ),
            'type' => \Elementor\Controls_Manager::TEXTAREA,
            'default' => esc_html__('Your Job Done','prolancer' ),
            'condition' => [
              'style' => ['style-2']
            ]
         ]
      ); 

      $this->add_control(
         'description',
         [
            'label' => esc_html__( 'Description', 'prolancer' ),
            'type' => \Elementor\Controls_Manager::TEXTAREA,
            'default' => esc_html__('Work with talented people at the most affordable price to get the most out of your time and cost on a secure platform.','prolancer' )
         ]
      );

      $this->add_control(
        'text_color',
        [
          'label' => esc_html__( 'Text Color', 'prolancer' ),
          'type' => \Elementor\Controls_Manager::COLOR
        ]
      );

      $this->add_control(
         'search_display',
         [
            'label' => esc_html__( 'Search', 'prolancer' ),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'label_on' => esc_html__( 'On', 'prolancer' ),
            'label_off' => esc_html__( 'Off', 'prolancer' ),
            'return_value' => 'on',
            'default' => 'on'
         ]
      );

      $this->add_control(
         'align',
         [
            'label' => esc_html__( 'Alignment', 'prolancer' ),
            'type' => \Elementor\Controls_Manager::CHOOSE,
            'options' => [
               'start' => [
                  'title' => esc_html__( 'Left', 'prolancer' ),
                  'icon' => 'fa fa-align-left',
               ],
               'center' => [
                  'title' => esc_html__( 'Center', 'prolancer' ),
                  'icon' => 'fa fa-align-center',
               ],
               'end' => [
                  'title' => esc_html__( 'Right', 'prolancer' ),
                  'icon' => 'fa fa-align-right',
               ],
            ],
            'default' => 'start',
            'toggle' => true
         ]
      );
      
            
      $this->end_controls_section();

   }

  protected function render( $instance = [] ) {
 
      // get our input from the widget settings.
       
      $settings = $this->get_settings_for_display(); ?>
      <section class="banner text-<?php echo esc_attr( $settings['align'] ); ?>">
        <div class="banner-content">
          <h1 style="color: <?php echo esc_attr( $settings['text_color']) ?> ">
            <?php echo esc_html( $settings['title'] ); ?>
          </h1>
          <p style="color: <?php echo esc_attr( $settings['text_color']) ?> "><?php echo esc_html($settings['description']); ?></p>
        </div>
        <?php if ( $settings['search_display'] == 'on' ){ ?>
          <div class="brands_form">
            <form class="prolancer-select-search" method="GET" action="<?php echo esc_url(home_url( '/' )); ?>">
               <input type="text" name="s" placeholder="<?php echo esc_attr__('Search for...', 'prolancer') ?>">
               <select name="post_type">
                 <option value='services' selected><?php echo esc_html__( 'Services', 'prolancer' )?></option>
                 <option value='projects'><?php echo esc_html__( 'Projects', 'prolancer' )?></option>
                 <option value='sellers'><?php echo esc_html__( 'Talent', 'prolancer' )?></option>
               </select>
               <input type="submit" value="<?php echo esc_attr__('Search', 'prolancer') ?>">
            </form>
          </div>
        <?php } ?>
      </section>
      <?php
   }
 
}

Plugin::instance()->widgets_manager->register_widget_type( new prolancer_Widget_Search_Banner );