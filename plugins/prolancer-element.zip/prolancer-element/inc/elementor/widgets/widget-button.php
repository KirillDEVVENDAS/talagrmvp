<?php 
namespace Elementor;
 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Button
class prolancer_Widget_Button extends Widget_Base {
 
   public function get_name() {
      return 'button';
   }
 
   public function get_title() {
      return esc_html__( 'Button', 'prolancer' );
   }
 
   public function get_icon() { 
        return 'eicon-button';
   }
 
   public function get_categories() {
      return [ 'prolancer-elements' ];
   }

   protected function register_controls() {

      $this->start_controls_section(
         'button_section',
         [
            'label' => esc_html__( 'Button', 'prolancer' ),
            'type' => Controls_Manager::SECTION,
         ]
      );

      $this->add_control(
         'button_text', [
            'label' => esc_html__( 'Button Text', 'prolancer' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => esc_html__('Learn More','prolancer')
         ]
      );

      $this->add_control(
         'button_url', [
            'label' => esc_html__( 'Button URL', 'prolancer' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => '#'
         ]
      );
      
      $this->add_control(
         'align',
         [
            'label' => esc_html__( 'Align', 'prolancer' ),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'left',
            'options' => [
               'center'  => esc_html__( 'Center', 'prolancer' ),
               'left' => esc_html__( 'Left', 'prolancer' ),
               'right' => esc_html__( 'Right', 'prolancer' )
            ],
         ]
      );

      $this->add_control(
         'border',
         [
            'label' => esc_html__( 'border', 'prolancer' ),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'label_on' => esc_html__( 'On', 'prolancer' ),
            'label_off' => esc_html__( 'Off', 'prolancer' ),
            'return_value' => 'bordered',
            'default' => 'no',
         ]
      );

      $this->end_controls_section();

   }

   protected function render( $instance = [] ) {
 
      // get our input from the widget settings.
       
      $settings = $this->get_settings_for_display(); ?>

      <div style="text-align: <?php echo esc_attr($settings['align']) ?>">
         <a class="prolancer-btn <?php echo esc_attr($settings['border']) ?>" href="<?php echo esc_url( $settings['button_url'] ); ?>">
            <?php echo esc_html( $settings['button_text'] ); ?></a>
      </div>
      <?php
   }
 
}

Plugin::instance()->widgets_manager->register_widget_type( new prolancer_Widget_Button );