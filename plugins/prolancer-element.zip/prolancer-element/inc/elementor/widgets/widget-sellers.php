<?php 
namespace Elementor;
 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Sellers
class prolancer_Widget_Sellers extends Widget_Base {
 
   public function get_name() {
      return 'sellers';
   }
 
   public function get_title() {
      return esc_html__( 'Sellers', 'prolancer' );
   }
 
   public function get_icon() { 
        return 'eicon-form-vertical';
   }
 
   public function get_categories() {
      return [ 'prolancer-elements' ];
   }

   protected function register_controls() {

      $this->start_controls_section(
         'sellers_section',
         [
            'label' => esc_html__( 'Sellers', 'prolancer' ),
            'type' => Controls_Manager::SECTION,
         ]
      );

      $this->add_control(
         'style',
         [
            'label' => esc_html__( 'Style', 'prolancer' ),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'style-1',
            'options' => [
               'style-1'  => esc_html__( 'Card', 'prolancer' ),
               'style-2' => esc_html__( 'Bar', 'prolancer' )
            ],
         ]
      );

      $this->add_control(
         'slide',
         [
            'label' => esc_html__( 'Slide', 'prolancer' ),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'label_on' => esc_html__( 'On', 'prolancer' ),
            'label_off' => esc_html__( 'Off', 'prolancer' ),
            'return_value' => 'true',
            'default' => false,
         ]
      );

      $this->add_control(
         'slidestoshow',
         [
            'label' => esc_html__('Slides To Show', 'prolancer' ),
            'type' => Controls_Manager::NUMBER,
            'min' => 1,
            'max' => 100,
            'step' => 1,
            'default' => 4,
            'condition' => [
               'slide' => 'true'
            ]
         ]
      );

      $this->add_control(
         'slidestoscroll',
         [
            'label' => esc_html__( 'Slides To Scroll', 'prolancer' ),
            'type' => Controls_Manager::NUMBER,
            'min' => 1,
            'max' => 10,
            'step' => 1,
            'default' => 4,
            'condition' => [
               'slide' => 'true'
            ]
         ]
      );

      $this->add_control(
         'columns',
         [
            'label' => esc_html__( 'Columns', 'prolancer' ),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'col-md-4',
            'options' => [
               'col-xl-12 col-6'  => esc_html__( 'Column 1', 'prolancer' ),
               'col-xl-6 col-6' => esc_html__( 'Column 2', 'prolancer' ),
               'col-xl-4 col-md-6 col-6' => esc_html__( 'Column 3', 'prolancer' ),
               'col-xl-3 col-lg-4 col-md-6 col-6' => esc_html__( 'Column 4', 'prolancer' ),
               'col-xl-2 col-6' => esc_html__( 'Column 6', 'prolancer' ),
               'col-xl-1 col-6' => esc_html__( 'Column 12', 'prolancer' ),
            ],
         ]
      );

      $this->add_control(
         'ppp',
         [
            'label' => esc_html__( 'Number of Items', 'prolancer' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
               'no' => [
                  'min' => 0,
                  'max' => 100,
                  'step' => 1,
               ],
            ],
            'default' => [
               'size' => 3,
            ]
         ]
      );

      $this->add_control(
         'order',
         [
            'label' => esc_html__( 'order', 'prolancer' ),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'DESC',
            'options' => [
               'ASC'  => esc_html__( 'Ascending', 'prolancer' ),
               'DESC' => esc_html__( 'Descending', 'prolancer' )
            ],
         ]
      );

      $this->end_controls_section();

   }

   protected function render( $instance = [] ) {
 
      // get our input from the widget settings.
       
      $settings = $this->get_settings_for_display(); ?>
      
      <div class="row justify-content-center <?php if($settings['slide'] == true){echo esc_attr('sellers');} ?>" <?php if ($settings['slide'] == true){ ?>data-slick='{"slidesToShow": <?php echo esc_attr( $settings['slidestoshow'] ) ?>, "slidesToScroll": <?php echo esc_attr( $settings['slidestoscroll'] ) ?>}'<?php } ?>>
         <?php
         global $post;

         $sellers = new \WP_Query( array( 
            'post_type' => 'sellers',
            'posts_per_page' => $settings['ppp']['size'],
            'order' => $settings['order']
         ));

         /* Start the Loop */
         while ( $sellers->have_posts() ) : $sellers->the_post(); ?>
            <!-- Item -->
            <div class="<?php echo esc_attr($settings['columns']) ?> <?php if ($settings['slide'] == true){echo esc_attr('pr-15 pl-15');} ?>">
               <?php if ($settings['style'] == 'style-1') { ?>
                  <?php do_action( 'get_prolancer_seller_item', $settings['style'] ); ?>
               <?php } elseif($settings['style'] == 'style-2') { ?>
                  <?php do_action( 'get_prolancer_seller_item', $settings['style'] ); ?>
               <?php } ?>
            </div>

         <?php 
         endwhile; 
      wp_reset_postdata();
      ?>
      </div>
      
   <?php
   }
 
}

Plugin::instance()->widgets_manager->register_widget_type( new prolancer_Widget_Sellers );