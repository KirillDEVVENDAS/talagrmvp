<?php

// Enqueue script
function prolancer_plugin_enqueue_script() {

	// CSS
    wp_enqueue_style('richtext', plugin_dir_url( __FILE__ ) . '../assets/css/richtext.min.css');
    wp_enqueue_style('prolancer-select2', plugin_dir_url( __FILE__ ) . '../assets/css/select2.min.css');
    wp_enqueue_style('prolancer-dashboard', plugin_dir_url( __FILE__ ) . '../assets/css/dashboard.css');
	wp_enqueue_style('slick-theme', plugin_dir_url( __FILE__ ) . '../assets/css/slick-theme.css');
    wp_enqueue_style('prolancer-plugns', plugin_dir_url( __FILE__ ) . '../assets/css/plugins.css');
	wp_enqueue_style('prolancer-plugn', plugin_dir_url( __FILE__ ) . '../assets/css/plugin.css');

	// JS
    wp_enqueue_script( 'richtext', plugin_dir_url( __FILE__ ) . '../assets/js/richtext.min.js', array('jquery'), wp_get_theme()->get( 'Version' ) );
    wp_enqueue_script( 'charts', 'https://www.gstatic.com/charts/loader.js', array('jquery'), wp_get_theme()->get( 'Version' ), true );
    wp_enqueue_script( 'rating', plugin_dir_url( __FILE__ ) . '../assets/js/rating.js', array('jquery'), wp_get_theme()->get( 'Version' ), true );
    wp_enqueue_script( 'sweetalert2', plugin_dir_url( __FILE__ ) . '../assets/js/sweetalert2.min.js', array('jquery'), wp_get_theme()->get( 'Version' ), true );
    wp_enqueue_script( 'prolancer-select2', plugin_dir_url( __FILE__ ) . '../assets/js/select2.min.js', array('jquery'), wp_get_theme()->get( 'Version' ), true );
	wp_enqueue_script( 'prolancer-plugins', plugin_dir_url( __FILE__ ) . '../assets/js/plugins.js', array('jquery'), wp_get_theme()->get( 'Version' ), true );
    wp_enqueue_script( 'prolancer-app', plugin_dir_url( __FILE__ ) . '../assets/js/app.js', array('jquery','jquery-ui-sortable'), wp_get_theme()->get( 'Version' ), true );
	wp_enqueue_script( 'prolancer-plugin', plugin_dir_url( __FILE__ ) . '../assets/js/plugin.js', array('jquery','prolancer-main'), wp_get_theme()->get( 'Version' ), true );
	wp_localize_script( 'prolancer-plugin', 'prolancerPluginAjaxObj', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));
}
add_action('wp_enqueue_scripts', 'prolancer_plugin_enqueue_script');

// Admin scripts
function prolancer_admin_scripts(){
    // JS
    wp_enqueue_media();
    wp_enqueue_script( 'jquery-ui-sortable' );
    wp_enqueue_style( 'prolancer-admin-style', plugin_dir_url( __FILE__ ) . '../assets/css/admin.css');
    wp_enqueue_script( 'prolancer-admin-script', plugin_dir_url( __FILE__ ) . '../assets/js/admin.js', array('jquery'), wp_get_theme()->get( 'Version' ), true);
    wp_localize_script( 'prolancer-admin-script', 'prolancerAjaxUrlObj', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));
}
add_action( 'admin_enqueue_scripts', 'prolancer_admin_scripts' );

// Includes files
include_once(dirname( __FILE__ ). '/elementor/elementor.php');
include_once(dirname( __FILE__ ). '/social-share.php');
include_once(dirname( __FILE__ ). '/mega-menu/mega-menu.php');
include_once(dirname( __FILE__ ). '/widgets/widget-filter-by-attribute.php');
include_once(dirname( __FILE__ ). '/widgets/widget-recent-posts.php');
include_once(dirname( __FILE__ ). '/widgets/widget-seller-details.php');
include_once(dirname( __FILE__ ). '/widgets/widget-buyer-details.php');
include_once(dirname( __FILE__ ). '/templates.php');
include_once(dirname( __FILE__ ). '/ajax-actions.php');
include_once(dirname( __FILE__ ). '/cmb2.php');
include_once(dirname( __FILE__ ). '/create-database-table.php');
include_once(dirname( __FILE__ ). '/custom-posts.php');

/**
 * Adding Fields
 */
function prolancer_add_extra_category_fields( $term ) { ?>
    <!-- Image  -->
	<div class="form-field">
		<label for="category-image-id"><?php echo esc_html__('Category image', 'prolancer'); ?></label>
		<input type="hidden" id="category-image-id" name="category-image-id">
		<div id="category-image-wrapper"></div>
		<p>
			<input type="button" class="button prolancer_category_image_add_button" id="prolancer_category_image_add_button" name="prolancer_category_image_add_button" value="<?php echo esc_html__( 'Add Image', 'prolancer' ); ?>">
			<input type="button" class="button" id="prolancer_category_image_remove_button" name="prolancer_category_image_remove_button" value="<?php echo esc_html__( 'Remove Image', 'prolancer' ); ?>">
		</p>
	</div>
<?php
}
add_action( 'service-categories_add_form_fields', 'prolancer_add_extra_category_fields', 10 );

/**
 * Edit Fields
 */
function prolancer_edit_extra_category_fields( $term ) { ?>	
	<!-- Image -->
	<tr class="form-field term-group-wrap">
     <th scope="row">
       <label for="category-image-id"><?php echo esc_html__( 'Category image', 'prolancer' ); ?></label>
     </th>
     <td>
       <input type="hidden" id="category-image-id" name="category-image-id">
       <div id="category-image-wrapper">
           <?php echo wp_get_attachment_image ( get_term_meta ( $term->term_id, 'category-image-id', true ), 'thumbnail' ); ?>
       </div>
       <p>
        <input type="button" class="button prolancer_category_image_add_button" id="prolancer_category_image_add_button" name="prolancer_category_image_add_button" value="<?php echo esc_html__( 'Add Image', 'prolancer' ); ?>">
		<input type="button" class="button" id="prolancer_category_image_remove_button" name="prolancer_category_image_remove_button" value="<?php echo esc_html__( 'Remove Image', 'prolancer' ); ?>">
       </p>
     </td>
   </tr>

<?php
}
add_action( 'service-categories_edit_form_fields', 'prolancer_edit_extra_category_fields', 10 );

// Project item
function prolancer_project_item($style) {
    global $post;

    $featured_project = get_post_meta(get_the_ID(), 'featured_project', true );
    $buyer_id = get_user_meta( $post->post_author, 'buyer_id' , true ); 
    $buyer_profile_attachment = get_post_meta($buyer_id, 'buyer_profile_attachment', true );
    if ($style == 'style-1') { ?>
        <div class="prolancer-project-item style-1">
            <?php if ($featured_project == true) {?>
                <div class="featured-post"><?php echo esc_html__('Featured','prolancer') ?><i class="fas fa-bolt"></i></div>
            <?php } ?>
            <div class="text-center">
                <a class="project-buyer" href="<?php echo esc_url(get_the_permalink($buyer_id)) ?>">
                <?php $buyer_image = wp_get_attachment_image ( prolancer_get_image_id(get_post_meta($buyer_id, 'buyer_profile_attachment', true )),array('150', '150') ,false);
                if (!empty($buyer_image)) {
                    echo wp_kses($buyer_image,array(
                        "img" => array(
                            "src" => array(),
                            "alt" => array(),
                            "style" => array()
                        )
                    ));
                } else {
                    echo get_avatar( get_post_field('post_author', $buyer_id), 150 );
                } ?>           
                <h5><?php echo esc_html(get_post_meta($buyer_id, 'buyer_profile_name', true)) ; ?><?php prolancer_verification(); ?></h5>
                </a>
                <a class="project-title" href="<?php the_permalink(); ?>"><h3><?php echo mb_strimwidth( get_the_title(), 0, 45, '..' );?></h3></a>
                <ul class="list-inline mb-0">
                    <?php if (get_post_meta( get_the_ID(), 'project_type' , true )){ ?>
                        <li class="list-inline-item"><i class="fad fa-file-chart-pie"></i> <?php echo esc_html(esc_html(get_post_meta( get_the_ID(), 'project_type' , true ))); ?></li>
                    <?php }                    
                    if(get_the_terms( get_the_ID(), 'project-duration' )){ ?>
                        <li class="list-inline-item"><i class="fad fa-clock"></i> <?php echo esc_html(get_the_terms( get_the_ID(), 'project-duration' )[0]->name); ?></li>
                    <?php } ?>
                </ul>
            </div>            
        </div>
    <?php }elseif ($style == 'style-2') { ?>
        <div class="prolancer-project-item style-2">
            <?php if ($featured_project == true) {?>
                <div class="featured-post"><?php echo esc_html__('Featured','prolancer') ?><i class="fas fa-bolt"></i></div>
            <?php } ?>
            <div class="row"> 
                <div class="col-md-1 my-auto">
                    <a class="project-buyer" href="<?php echo esc_url(get_the_permalink($buyer_id)) ?>">
                        <?php $buyer_image = wp_get_attachment_image ( prolancer_get_image_id(get_post_meta($buyer_id, 'buyer_profile_attachment', true )),array('170', '170') ,false);
                        if (!empty($buyer_image)) {
                            echo wp_kses($buyer_image,array(
                                "img" => array(
                                    "src" => array(),
                                    "alt" => array(),
                                    "style" => array()
                                )
                            ));
                        } else {
                            echo get_avatar( get_post_field('post_author', $buyer_id), 170 );
                        }

                        prolancer_verification(); ?>
                    </a>
                </div>
                <div class="col-md-6 my-auto">
                   <a class="project-title" href="<?php the_permalink(); ?>"><h3><?php echo mb_strimwidth( get_the_title(), 0, 50, '..' );?></h3></a>
                   <ul class="list-inline">
                        <?php if (get_the_terms( get_the_ID(), 'project-duration' )) { ?>
                            <li class="list-inline-item"><i class="fad fa-clock"></i> <?php echo esc_html(get_the_terms( get_the_ID(), 'project-duration' )[0]->name); ?></li>
                        <?php }
                        if(get_the_terms( get_the_ID(), 'project-level' )){ ?>
                            <li class="list-inline-item"><i class="fad fa-signal-alt-3"></i> <?php echo esc_html(get_the_terms( get_the_ID(), 'project-level' )[0]->name); ?></li>
                        <?php } ?>
                   </ul>
                </div>

                <div class="col-md-2 my-auto text-center">
                    <h2>
                        <?php $price = get_post_meta(get_the_ID(), 'project_price', true);
                        
                        if (function_exists('prolancer_get_currency_symbol')) {
                            echo esc_html(prolancer_get_currency_symbol($price));
                        } ?>
                    </h2>
                   <?php echo esc_html(get_post_meta( get_the_ID(), 'project_type' , true )); ?>
                </div>
                <div class="col-md-3 my-auto">
                   <a href="<?php the_permalink(); ?>" class="prolancer-rgb-btn float-lg-end"><?php echo esc_html__( 'Detail', 'prolancer' ); ?></a>
                </div>
            </div>
        </div>
    <?php }
}
add_action( 'get_prolancer_project_item', 'prolancer_project_item', 10, 1 );

// Service item
function prolancer_service_item($style) {
    global $post;
    $featured_service = get_post_meta(get_the_ID(), 'featured_service', true );
    $service_attachments = get_post_meta( get_the_ID(), 'service_attachments' );
    if ($service_attachments) {
        foreach ($service_attachments as $attachment) {
            if ($attachment) {
                $image_ids = array_keys($attachment);
            }            
        }
    } 

    $seller_id = get_user_meta( $post->post_author, 'seller_id' , true );
    if ($style == 'style-1') { ?>
        <div class="prolancer-service-item style-1">
            <?php if ($featured_service == true) {?>
                <div class="featured-post"><?php echo esc_html__('Featured','prolancer') ?><i class="fas fa-bolt"></i></div>
            <?php } ?>
            <?php if ($service_attachments){?>
                <div class="service-item-images">
                <?php foreach ($image_ids as $image_id){ ?>
                   <img src="<?php echo esc_url( wp_get_attachment_image_src($image_id,'prolancer-600x399')[0] ); ?>" alt="Img">
                <?php } ?>
                </div>
            <?php } ?>
            <div class="seller-profile-attachment">
                <a href="<?php echo esc_url(get_the_permalink($seller_id)) ?>">
                    <?php $seller_image = wp_get_attachment_image ( prolancer_get_image_id(get_post_meta($seller_id, 'seller_profile_attachment', true )),array('60', '60') ,false);

                    if (!empty($seller_image)) {
                        echo wp_kses($seller_image,array(
                            "img" => array(
                                "src" => array(),
                                "alt" => array(),
                                "style" => array()
                            )
                        ));
                    } else {
                        echo get_avatar( get_post_field('post_author', $seller_id), 60 );
                    } ?>
                </a>
            </div>
            <div class="service-content">
                <div class="service-item-seller">
                    <div class="row">
                        <div class="col-9">
                            <div class="d-flex">
                            
                            <div class="my-auto">
                                <h6 class="mb-0"><?php echo esc_html(get_post_meta($seller_id, 'seller_profile_name', true)) ; ?><?php prolancer_verification(); ?></h6>
                                <span><?php echo esc_html__( 'Delivery:', 'prolancer' ); ?>
                                    <b>
                                    <?php $delivery_time = get_term_by( 'id', json_decode(get_post_meta(get_the_ID(), 'packages', true ), true)[0]['delivery_time'], 'delivery-time' );
                                        if ($delivery_time) {
                                            echo esc_html($delivery_time->name);
                                        } else {
                                            echo esc_html__('Undefined','prolancer');
                                        } ?>
                                    </b>
                                </span>
                            </div>
                          </div>    
                        </div>
                        <div class="col-3">
                            <div class="service-price float-end">
                                <?php
                                $check_if_exist = get_user_meta(get_current_user_id(), 'service_wishlist_id_'.get_the_ID(),true);

                                if ($check_if_exist){ ?>
                                    <a href="#" class="wishlist-service" data-id="<?php echo get_the_ID(); ?>" data-nonce="<?php echo wp_create_nonce('wishlist_service_nonce'); ?>"><i class="fas fa-lg fa-heart"></i></a>
                                <?php }else{ ?>
                                    <a href="#" class="wishlist-service" data-id="<?php echo get_the_ID(); ?>" data-nonce="<?php echo wp_create_nonce('wishlist_service_nonce'); ?>"><i class="fal fa-lg fa-heart"></i></a>
                                <?php } ?> 
                            </div>
                        </div>
                    </div>
                </div>
                <h3><a href="<?php the_permalink(); ?>"><?php echo mb_strimwidth( get_the_title(), 0, 55, '..' );?></a></h3>
                <div class="d-flex">
                    <div class="col-9 my-auto">
                        <?php if (get_the_terms( get_the_ID(), 'service-categories' )) { ?>
                            <ul class="list-inline mb-0">
                                <li class="list-inline-item"><i class="fad fa-tag"></i>
                                <?php echo esc_html(get_the_terms( get_the_ID(), 'service-categories' )[0]->name); ?></li>
                            </ul>
                        <?php } ?>
                    </div>
                    <div class="col-3 my-auto">
                        <ul class="list-inline mb-0 float-end">
                            <div class="service-price">
                                <h4>
                                    <?php $price = json_decode(get_post_meta(get_the_ID(), 'packages', true ), true)[0]['price'];

                                    if (function_exists('prolancer_get_currency_symbol')) {
                                        echo esc_html(prolancer_get_currency_symbol($price));
                                    } ?>
                                </h4>
                            </div>
                        </ul>                           
                    </div>
                </div>              
            </div>
        </div>
    <?php }elseif ($style == 'style-2') { ?>
        <div class="prolancer-service-item style-2">
            <?php if ($featured_service == true) {?>
                <div class="featured-post"><?php echo esc_html__('Featured','prolancer') ?><i class="fas fa-bolt"></i></div>
            <?php } ?>
            <div class="row">
                <?php if (!empty($service_attachments)){?>
                <div class="col-md-4 my-auto">
                   <div class="service-item-images">
                      <?php foreach ($image_ids as $image_id){ ?>
                         <img src="<?php echo esc_url( wp_get_attachment_image_src($image_id,'prolancer-600x399')[0] ); ?>" alt="Img">
                      <?php } ?>
                   </div>
                </div>
                <?php } ?>              
                <div class="col-md-<?php if (!empty($service_attachments)){ echo '8';}else{ echo '12'; } ?> my-auto">
                   <div class="service-content">
                      <div class="service-item-seller">
                        <div class="row">
                            <div class="col-6">
                                <div class="d-flex">
                                <div class="my-auto">
                                   <a href="<?php echo esc_url(get_the_permalink($seller_id)) ?>">
                                      <?php $seller_image = wp_get_attachment_image ( prolancer_get_image_id(get_post_meta($seller_id, 'seller_profile_attachment', true )),array('40', '40') ,false);

                                        if (!empty($seller_image)) {
                                            echo wp_kses($seller_image,array(
                                                "img" => array(
                                                    "src" => array(),
                                                    "alt" => array(),
                                                    "style" => array()
                                                )
                                            ));
                                        } else {
                                            echo get_avatar( get_post_field('post_author', $seller_id), 40 );
                                        } ?>
                                   </a>
                                </div>
                                <div class="my-auto">
                                    <h6 class="mb-0"><?php echo esc_html(get_post_meta($seller_id, 'seller_profile_name', true)) ; ?><?php prolancer_verification(); ?></h6>
                                    <span><?php echo esc_html__( 'Delivery:', 'prolancer' ); ?>
                                        <b>
                                            <?php $delivery_time = get_term_by( 'id', json_decode(get_post_meta(get_the_ID(), 'packages', true ), true)[0]['delivery_time'], 'delivery-time' );
                                            if ($delivery_time) {
                                                echo esc_html($delivery_time->name);
                                            } else {
                                                echo esc_html__('Undefined','prolancer');
                                            } ?>                                          
                                        </b>
                                    </span>
                                </div>
                              </div>    
                            </div>
                            <div class="col-6">
                                <div class="service-price float-end">
                                    <h4>
                                        <?php $price = json_decode(get_post_meta(get_the_ID(), 'packages', true ), true)[0]['price'];

                                        if (function_exists('prolancer_get_currency_symbol')) {
                                            echo esc_html(prolancer_get_currency_symbol($price));
                                        } ?>                            
                                    </h4>
                                  </div>
                            </div>
                        </div>
                      </div>
                      <h3><a href="<?php the_permalink(); ?>"><?php echo mb_strimwidth( get_the_title(), 0, 80, '..' );?></a></h3>
                      <ul class="list-inline">
                        <?php if(get_the_terms( get_the_ID(), 'service-categories' )) { ?>
                            <li class="list-inline-item"><i class="fad fa-tags"></i><?php echo esc_html(get_the_terms( get_the_ID(), 'service-categories' )[0]->name); ?></li>
                        <?php }
                        if(get_the_terms( get_the_ID(), 'service-english-level' )){ ?>
                            <li class="list-inline-item"><i class="fad fa-language"></i><?php echo esc_html(get_the_terms( get_the_ID(), 'service-english-level' )[0]->name); ?></li>
                        <?php }
                        if(get_the_terms( get_the_ID(), 'service-locations' )){ ?>
                            <li class="list-inline-item"><i class="fad fa-location-circle"></i><?php echo esc_html(get_the_terms( get_the_ID(), 'service-locations' )[0]->name); ?></li>
                        <?php } ?>
                     </ul>
                   </div>
                </div>
            </div>
        </div>
    <?php }
}
add_action( 'get_prolancer_service_item', 'prolancer_service_item', 10, 1 );

// buyer item
function prolancer_buyer_item($style) {
  $buyer_locations = get_the_terms( get_the_ID(), 'buyer-locations' );
  $employees_number = get_the_terms( get_the_ID(), 'employees-number' );
  $buyer_profile_attachment = get_post_meta( get_the_ID(), 'buyer_profile_attachment', true );
  $buyer_profile_name = get_post_meta(get_the_ID(), 'buyer_profile_name', true);
  $complete_project = get_post_meta(get_the_ID(), 'complete_project', true);

  global $wpdb;
    $project_table ='prolancer_project_proposals';
     
    if($wpdb->get_var("SHOW TABLES LIKE '$project_table'") == $project_table) {
      $proposal_query = "SELECT * FROM ".$project_table." WHERE `buyer_id` = '" . get_the_ID() . "' AND status = 'pending'";
      $proposals = $wpdb->get_results($proposal_query, ARRAY_A);
    }
  if (count($proposals)>0) {
        $proposal = count($proposals);
    }else{
        $proposal = 0;
    }

    if ($style == 'style-1') { ?>
        <div class="prolancer-buyer-item style-1 text-center">
            <?php if (!empty($buyer_profile_attachment)){ ?>
                <a href="<?php the_permalink(); ?>" class="buyer-item-images">
                    <?php $buyer_image = wp_get_attachment_image ( prolancer_get_image_id($buyer_profile_attachment),array('250', '250') ,false);
                    if (!empty($buyer_image)) {
                        echo wp_kses($buyer_image,array(
                            "img" => array(
                                "src" => array(),
                                "alt" => array(),
                                "style" => array()
                            )
                        ));
                    } else {
                        echo get_avatar( get_post_field('post_author', get_the_ID()), 250 );
                    } ?>
                </a>
            <?php } ?>      
            <div class="buyer-content">
                <h2><a href="<?php the_permalink(); ?>"><?php echo esc_html($buyer_profile_name) ; ?><?php prolancer_verification(); ?></a></h2>
                <p class="mb-0"><?php echo esc_html__( 'Member since', 'prolancer' ).' '.get_the_date('M Y'); ?></p>
                <ul class="list-inline">
                    <?php if ($buyer_locations){ ?>
                        <li class="list-inline-item">
                            <i class="fas fa-globe-asia"></i><?php echo esc_html($buyer_locations[0]->name); ?>
                        </li>
                    <?php } ?>
                    <?php if ($employees_number) { ?>
                        <li class="list-inline-item"><i class="fas fa-users"></i><?php echo esc_html( $employees_number[0]->name ); ?></li>
                    <?php } ?>
                </ul>
            </div>
        </div>
    <?php } elseif ($style == 'style-2') { ?>
        <div class="prolancer-buyer-item style-2">
            <div class="row">               
                <?php if (!empty($buyer_profile_attachment)){ ?>
                <div class="col-md-3 my-auto">
                    <a href="<?php the_permalink(); ?>" class="buyer-item-images">
                        <?php $buyer_image = wp_get_attachment_image ( prolancer_get_image_id($buyer_profile_attachment),array('250', '250') ,false);
                        if (!empty($buyer_image)) {
                            echo wp_kses($buyer_image,array(
                                "img" => array(
                                    "src" => array(),
                                    "alt" => array(),
                                    "style" => array()
                                )
                            ));
                        } else {
                            echo get_avatar( get_post_field('post_author', get_the_ID()), 250 );
                        } ?>
                    </a>
                </div>
                <?php } ?>
                <div class="col-md-<?php if (!empty($buyer_profile_attachment)){ echo '6';}else{ echo '9'; } ?> my-auto">
                   <div class="buyer-content">
                        <h4><?php echo esc_html(get_post_meta(get_the_ID(), 'buyer_profile_title', true)) ; ?></h4>
                        <h3 class="mb-2"><a href="<?php the_permalink(); ?>"><?php echo mb_strimwidth( get_the_title(), 0, 60, '..' );?></a><?php prolancer_verification(); ?></h3>

                        <p class="mb-4"><?php echo esc_html__( 'Member since', 'prolancer' ).' '.get_the_date('M Y'); ?></p>
                        <ul class="list-inline mb-lg-0">
                            <?php if ($buyer_locations){ ?>
                                <li class="list-inline-item"><i class="fas fa-map-marked-alt"></i><?php echo esc_html($buyer_locations[0]->name); ?></li>
                            <?php } ?>
                            <?php if ($employees_number) { ?>
                                <li class="list-inline-item"><i class="fas fa-users"></i><?php echo esc_html( $employees_number[0]->name ); ?></li>
                            <?php } ?>
                        </ul>
                   </div>
                </div>
                <div class="col-md-3 my-auto text-center">
                    <h5><?php echo esc_html($proposal); ?></h5>
                  <span>(<?php echo esc_html__( 'Proposals', 'prolancer' ) ?>)</span>
                  <div>
                        <a href="<?php echo esc_url(get_the_permalink($buyer_id)) ?>" class="mt-3 prolancer-rgb-btn"><?php echo esc_html__( 'Profile', 'prolancer' ) ?></a>
                    </div>
                </div>
            </div>
        </div>
    <?php }
}
add_action( 'get_prolancer_buyer_item', 'prolancer_buyer_item', 10, 1 );

// seller item
function prolancer_seller_item($style) {
    global $wpdb;

    $seller_english_level = get_the_terms( get_the_ID(), 'seller-english-level' );
    $seller_locations = get_the_terms( get_the_ID(), 'seller-locations' );
    $seller_type = get_the_terms( get_the_ID(), 'seller-type' );
    $seller_hourly_rate = get_post_meta( get_the_ID(), 'seller_hourly_rate' , true );
    $seller_profile_attachment = get_post_meta( get_the_ID(), 'seller_profile_attachment',true );

    //Rating
    $ratings = prolancer_seller_reviews(get_the_ID());

    $max = 0;
    $n = count($ratings);
    if ($ratings) {
      foreach ($ratings as $rate => $count) {
          $max = $max + $count['star'];
      }
      $average_rating = $max / $n;
    }

    if ($style == 'style-1') { ?>
        <div class="prolancer-seller-item style-1 text-center">
            <?php if ($seller_profile_attachment){ ?>
            <div class="seller-item-images">
                <a href="<?php the_permalink(); ?>">
                    <?php $seller_image = wp_get_attachment_image ( prolancer_get_image_id($seller_profile_attachment),array('250', '250') ,false);
                    if (!empty($seller_image)) {
                        echo wp_kses($seller_image,array(
                            "img" => array(
                                "src" => array(),
                                "alt" => array(),
                                "style" => array()
                            )
                        ));
                    } else {
                        echo get_avatar( get_post_field('post_author', get_the_ID()), 250 );
                    } ?>
                </a>
            </div>
            <?php } ?>
            <div class="seller-content">
                <h2 class="mb-2"><a href="<?php the_permalink(); ?>"><?php echo mb_strimwidth( get_the_title(), 0, 60, '..' );?></a><?php prolancer_verification(); ?></h2>
                <?php if ($seller_hourly_rate){ ?>
                    <div class="seller-hourly-rate">
                        <h4><?php echo esc_html__( 'Hourly rate: ', 'prolancer' ) ?><?php if (function_exists('prolancer_get_currency_symbol')) { echo esc_html(prolancer_get_currency_symbol($seller_hourly_rate)); } ?></h4>
                    </div>
                <?php } ?>
                <div class="star-rating">
              <span style="width:<?php if (isset($average_rating)) { echo( ( $average_rating / 5 ) * 100 ); }?>%"></span>
          </div>
                <?php if ($seller_type || $seller_locations){ ?>
                <ul class="list-inline">
                    <?php if ($seller_type){ ?>
                        <li class="list-inline-item"><i class="fas fa-user-shield"></i><span><?php echo esc_html($seller_type[0]->name); ?></span></li>
                    <?php } ?>
                    <?php if ($seller_locations){ ?>
                        <li class="list-inline-item"><i class="fas fa-globe-asia"></i><span><?php echo esc_html($seller_locations[0]->name); ?></span></li>
                    <?php } ?>
                </ul>
                <?php } ?>
            </div>
        </div>
    <?php }elseif ($style == 'style-2') { ?>
        <div class="prolancer-seller-item style-2">
            <div class="row">
                <?php if ($seller_profile_attachment){ ?>
                <div class="col-md-3 my-auto">
                    <a href="<?php the_permalink(); ?>">
                        <?php $seller_image = wp_get_attachment_image ( prolancer_get_image_id($seller_profile_attachment),array('250', '250') ,false);
                        if (!empty($seller_image)) {
                            echo wp_kses($seller_image,array(
                                "img" => array(
                                    "src" => array(),
                                    "alt" => array(),
                                    "style" => array()
                                )
                            ));
                        } else {
                            echo get_avatar( get_post_field('post_author', get_the_ID()), 250 );
                        } ?>
                    </a>
                </div>                
                <?php } ?>
                <div class="col-md-<?php if ($seller_profile_attachment){ echo '6';}else{ echo '9'; } ?> my-auto">
                   <div class="seller-content">
                        <h4 ><?php echo esc_html(get_post_meta(get_the_ID(), 'seller_profile_title', true)) ; ?></h4>
                        <h3 class="mb-2"><a href="<?php the_permalink(); ?>"><?php the_title() ; ?></a><?php prolancer_verification(); ?></h3>
                        
                        <p class="mb-4"><?php echo esc_html__( 'Member since', 'prolancer' ).' '.get_the_date('M Y'); ?></p>

                        <ul class="list-inline mb-lg-0">
                            <?php if ($seller_english_level){ ?>
                                <li class="list-inline-item"><i class="fad fa-users-medical"></i><?php echo esc_html($seller_type[0]->name); ?></b></li>
                            <?php } ?>
                            <?php if ($seller_locations){ ?>
                                <li class="list-inline-item"><i class="fas fa-map-marked-alt"></i><?php echo esc_html($seller_locations[0]->name); ?></b></li>
                            <?php } ?>
                        </ul>
                   </div>
                </div>
                <div class="col-md-3 my-auto text-center">
                    <?php if ($seller_hourly_rate){ ?>
                    <div class="seller-hourly-rate">
                        <h5><?php if (function_exists('prolancer_get_currency_symbol')) { echo esc_html(prolancer_get_currency_symbol($seller_hourly_rate)); } ?></h5>
                        <span>(<?php echo esc_html__( 'Hourly rate', 'prolancer' ) ?>)</span>
                    </div>
                <?php } ?>
                    <div class="star-rating mx-auto mb-4">
                <span style="width:<?php echo ( ( $average_rating / 5 ) * 100 )?>%"></span>
            </div>
            <a href="<?php the_permalink(); ?>" class="prolancer-rgb-btn"><?php echo esc_html__( 'Hire me', 'prolancer' ) ?></a>
                </div>
            </div>
        </div>
    <?php }
}
add_action( 'get_prolancer_seller_item', 'prolancer_seller_item', 10, 1 );

/**
 * Saving Fields
 */
function prolancer_save_category_fields( $term_id ) {
	// Image
	if( isset( $_POST['category-image-id'] ) && '' !== $_POST['category-image-id'] ){
		add_term_meta( $term_id, 'category-image-id', $_POST['category-image-id'], true );
	}
}  
add_action( 'create_service-categories', 'prolancer_save_category_fields' );  

/*
 * Update fields
 */
function prolancer_edit_category_fields ( $term_id ) {
	// Image
    if( isset( $_POST['category-image-id'] ) && '' !== $_POST['category-image-id'] ){
		update_term_meta ( $term_id, 'category-image-id', $_POST['category-image-id'] );
	} else {
		update_term_meta ( $term_id, 'category-image-id', '' );
   	}
}
add_action( 'edited_service-categories', 'prolancer_edit_category_fields' );

/**
 * Returns page url by template file name
 *
 * @param string $template name of template file including .php
 */
function prolancer_get_page_url_by_template( $template ) {
    $args = [
        'post_type'  => 'page',
        'fields'     => 'ids',
        'nopaging'   => true,
        'meta_key'   => '_wp_page_template',
        'meta_value' => $template
    ];
    $pages = get_posts( $args );
    if ($pages) {
        return get_permalink($pages[0]);
    }
}

/**
 * Returns page id by template file name
 *
 * @param string $template name of template file including .php
 */
function prolancer_get_page_id_by_template( $template ) {
    $args = [
        'post_type'  => 'page',
        'fields'     => 'ids',
        'nopaging'   => true,
        'meta_key'   => '_wp_page_template',
        'meta_value' => $template
    ];
    $pages = get_posts( $args );
    if ($pages) {
        return $pages[0];
    }
}

/*
 * Add extra query string
 */

function prolancer_append_query_string( $url, $id ) {
    if( prolancer_get_page_id_by_template('prolancer-dashboard.php') == $id ) {
        $url = add_query_arg( 'fed','', $url );
    }
    return $url;
}
add_filter( 'page_link', 'prolancer_append_query_string', 10, 2 );


// set hierarchical terms
if (!function_exists('prolancer_set_hierarchical_terms'))
{
    function prolancer_set_hierarchical_terms( $texonomy_name ='', $term_id ='', $pid ='')
    {
        $term = get_term( $term_id, $texonomy_name );
        $values[] = $term->term_id;
        if($term->parent >0)
        {
            $parent_one_term = get_term( $term->parent, $texonomy_name );
            $values[] = $parent_one_term->term_id;
            if($parent_one_term->parent >0)
            {
                $parent_two_term = get_term( $parent_one_term->parent, $texonomy_name );
                $values[] = $parent_two_term->term_id;
                if($parent_two_term->parent > 0)
                {
                    $parent_three_term = get_term( $parent_two_term->parent, $texonomy_name );
                    $values[] = $parent_three_term->term_id;
                }
            }
        }
    
        $integerIDs = array_map('intval', $values);
        $integerIDs = array_unique($integerIDs);
        wp_set_post_terms( $pid, $integerIDs, $texonomy_name );
    }
}

// Get option list
function prolancer_get_option_list($taxonomy, $meta, $post_id) { 
    $current_term = get_the_terms( $post_id, $taxonomy )[0]->slug;

    $terms = get_terms( array(
        'taxonomy' => $taxonomy,
        'hide_empty' => false,
        'orderby'   => 'name',
    ) );
    $hierarchy ='';
    $hierarchy = _get_term_hierarchy($taxonomy);

    foreach ($terms as $term) { 
        if($term->parent) {
            continue;
        } ?>                        
        <option <?php if ($term->slug == $current_term ){echo'selected ="selected"';} ?> value="<?php echo esc_attr( $term->term_id ); ?>"><?php echo esc_html( $term->name ); ?></option>

            <?php if (isset($hierarchy[$term->term_id])) {
                foreach ($hierarchy[$term->term_id] as $child){
                    $child = get_term($child, $taxonomy); ?>

                    <option <?php if ($child->slug == $current_term ){echo'selected ="selected"';} ?> value="<?php echo esc_attr( $child->term_id ); ?>">- <?php echo esc_html( $child->name ); ?></option>

                    <?php if (isset($hierarchy[$child->term_id])) {
                        foreach ($hierarchy[$child->term_id] as $child2){
                            $child2 = get_term($child2, $taxonomy); ?>

                            <option <?php if ($child2->slug == $current_term ){echo'selected ="selected"';} ?> value="<?php echo esc_attr( $child2->term_id ); ?>">-- <?php echo esc_html( $child2->name ); ?></option>

                                <?php if (isset($hierarchy[$child2->term_id])) {
                                    foreach ($hierarchy[$child2->term_id] as $child3){
                                        $child3 = get_term($child3, $taxonomy); ?>

                                        <option <?php if ($child3->slug == $current_term ){echo'selected ="selected"';} ?> value="<?php echo esc_attr( $child3->term_id ); ?>">--- <?php echo esc_html( $child3->name ); ?></option>
                                    <?php }
                                } ?>
                        <?php }
                    } ?>
                <?php }
            } ?>
    <?php }
}


// Search available only for post
function prolancer_search_filter($query) {
 
    if ($query->is_search) {
        if(!empty($_GET['post_type'])){
            $post_type = $_GET['post_type'];            
            if ($post_type == 'projects') {
                $query->set('post_type',array('projects'));
            } elseif($post_type == 'services'){
                $query->set('post_type',array('services'));
            } elseif($post_type == 'sellers'){
                $query->set('post_type',array('sellers'));
            }
        } else {
        $query->set('post_type',array('post'));
      }
    }
 
    return $query;
}
 
add_filter('pre_get_posts','prolancer_search_filter');

// Projects archive post count
function prolancer_projects_archive_post_count( $query ){
    global $prolancer_opt;
    if ( ! is_admin() && is_post_type_archive( 'projects' ) && $query->is_main_query() ) {
        $query->set( 'posts_per_page', isset($prolancer_opt['prolancer_project_per_page']) ? $prolancer_opt['prolancer_project_per_page'] : 10 );
        $query->set( 'meta_key', 'featured_project' );
        $query->set( 'orderby', 'meta_value_num' );
    }
}
add_action( 'pre_get_posts' ,'prolancer_projects_archive_post_count', 1, 1 );

// Services archive post count
function prolancer_services_archive_post_count( $query ) {
    global $prolancer_opt;
    if ( ! is_admin() && is_post_type_archive( 'services' ) && $query->is_main_query() ) {
        $query->set( 'posts_per_page', isset($prolancer_opt['prolancer_service_per_page']) ? $prolancer_opt['prolancer_service_per_page'] : 10 );
        $query->set( 'meta_key', 'featured_service' );
        $query->set( 'orderby', 'meta_value_num' );
    }
}
add_action( 'pre_get_posts' ,'prolancer_services_archive_post_count', 1, 1 );

// Buyers archive post count
function prolancer_buyers_archive_post_count( $query ) {
    global $prolancer_opt;
    if ( ! is_admin() && is_post_type_archive( 'buyers' ) && $query->is_main_query() ) {
        $query->set( 'posts_per_page', isset($prolancer_opt['prolancer_buyer_per_page']) ? $prolancer_opt['prolancer_buyer_per_page'] : 10 );
    }
}
add_action( 'pre_get_posts' ,'prolancer_buyers_archive_post_count', 1, 1 );

// Sellers archive post count
function prolancer_sellers_archive_post_count( $query ) {
    global $prolancer_opt;
    if ( ! is_admin() && is_post_type_archive( 'sellers' ) && $query->is_main_query() ) {
        $query->set( 'posts_per_page', isset($prolancer_opt['prolancer_seller_per_page']) ? $prolancer_opt['prolancer_seller_per_page'] : 10 );
    }
}
add_action( 'pre_get_posts' ,'prolancer_sellers_archive_post_count', 1, 1 );

// add user social media meta
function prolancer_add_social_links( $user ) { ?>
    <h3><?php echo esc_html__( 'Social Media Profile', 'prolancer' ) ?></h3>

    <table class="form-table">
        <tr>
            <th><label for="facebook"><?php echo esc_html__( 'Facebook', 'prolancer' ) ?></label></th>
            <td><input type="text" name="facebook" value="<?php echo esc_attr(get_the_author_meta( 'facebook', $user->ID )); ?>" class="regular-text" /></td>
        </tr>

        <tr>
            <th><label for="twitter"><?php echo esc_html__( 'Twitter', 'prolancer' ) ?></label></th>
            <td><input type="text" name="twitter" value="<?php echo esc_attr(get_the_author_meta( 'twitter', $user->ID )); ?>" class="regular-text" /></td>
        </tr>

        <tr>
            <th><label for="linkedin"><?php echo esc_html__( 'Linkedin', 'prolancer' ) ?></label></th>
            <td><input type="text" name="linkedin" value="<?php echo esc_attr(get_the_author_meta( 'linkedin', $user->ID )); ?>" class="regular-text" /></td>
        </tr>

        <tr>
            <th><label for="github"><?php echo esc_html__( 'Github', 'prolancer' ) ?></label></th>
            <td><input type="text" name="github" value="<?php echo esc_attr(get_the_author_meta( 'github', $user->ID )); ?>" class="regular-text" /></td>
        </tr>

        <tr>
            <th><label for="dribbble"><?php echo esc_html__( 'Dribbble', 'prolancer' ) ?></label></th>
            <td><input type="text" name="dribbble" value="<?php echo esc_attr(get_the_author_meta( 'dribbble', $user->ID )); ?>" class="regular-text" /></td>
        </tr>

    </table>
    <?php
}
add_action( 'show_user_profile', 'prolancer_add_social_links' );
add_action( 'edit_user_profile', 'prolancer_add_social_links' );
 
function prolancer_save_social_links( $user_id ) {
    update_user_meta( $user_id,'facebook', sanitize_text_field( $_POST['facebook'] ) );
    update_user_meta( $user_id,'twitter', sanitize_text_field( $_POST['twitter'] ) );
    update_user_meta( $user_id,'linkedin', sanitize_text_field( $_POST['linkedin'] ) );
    update_user_meta( $user_id,'github', sanitize_text_field( $_POST['github'] ) );
    update_user_meta( $user_id,'dribbble', sanitize_text_field( $_POST['dribbble'] ) );
}
add_action( 'personal_options_update', 'prolancer_save_social_links' );
add_action( 'edit_user_profile_update', 'prolancer_save_social_links' );

// User list
function prolancer_get_users( $query_args ) {

    $args = wp_parse_args( $query_args, array(

        'fields' => array( 'user_login' ),

    ) );

    $users = get_users(  );

    $user_options = array();
    if ( $users ) {
        foreach ( $users as $user ) {
          $user_options[ $user->ID ] = $user->user_login;
        }
    }

    return $user_options;
}

 // Remove shipping and billing fields
function prolancer_remove_woo_checkout_fields( $fields ) {

    // remove billing fields
    unset($fields['billing']['billing_company']);
    unset($fields['billing']['billing_address_1']);
    unset($fields['billing']['billing_address_2']);
    unset($fields['billing']['billing_city']);
    unset($fields['billing']['billing_postcode']);
    unset($fields['billing']['billing_country']);
    unset($fields['billing']['billing_state']);
    unset($fields['billing']['billing_phone']);
    unset($fields['billing']['billing_email']);
   
    // remove shipping fields 
    unset($fields['shipping']['shipping_first_name']);    
    unset($fields['shipping']['shipping_last_name']);  
    unset($fields['shipping']['shipping_company']);
    unset($fields['shipping']['shipping_address_1']);
    unset($fields['shipping']['shipping_address_2']);
    unset($fields['shipping']['shipping_city']);
    unset($fields['shipping']['shipping_postcode']);
    unset($fields['shipping']['shipping_country']);
    unset($fields['shipping']['shipping_state']);
    
    return $fields;
}
add_filter( 'woocommerce_checkout_fields' , 'prolancer_remove_woo_checkout_fields' );

// Action after order status is complete
function prolancer_woocommerce_order_status_completed( $order_id ) {
    $order = wc_get_order( $order_id );
    $balance = $order->get_subtotal();
    
    $available_balance = get_user_meta( $order->get_user_id(), 'wallet_balance', true );

    foreach ( $order->get_items() as $product ) {
        if ($product->get_name() == 'Recharge wallet') {
            if (isset($available_balance) && $available_balance != '') {
                update_user_meta($order->get_user_id(), 'wallet_balance', $available_balance+$balance);
            } else {
                update_user_meta($order->get_user_id(), 'wallet_balance', $balance);            
            }
        }
    }
}
add_action( 'woocommerce_order_status_completed', 'prolancer_woocommerce_order_status_completed', 10, 1 );

// After wallet recharge
function prolancer_after_wallet_recharge_done( $order_id){
    $order = wc_get_order( $order_id );
    foreach ($order->get_items() as $product) {
        if ($product->get_name() == 'Recharge wallet') {
            wp_delete_post($product->get_product_id());
            wp_redirect( prolancer_get_page_url_by_template('prolancer-dashboard.php').'=wallet' ) ;
        }
    }   
}
add_action('woocommerce_thankyou', 'prolancer_after_wallet_recharge_done', 10, 1);
 
// After a new user is registered.
function prolancer_user_register( $user_id ) {
 
    $user_info = get_userdata($user_id);

    $buyers = array(
        'post_title' => sanitize_text_field($user_info->user_login),
        'post_status' => 'publish',
        'post_author' => $user_id,
        'post_type' => 'buyers'
    );

    $buyer_id = wp_insert_post($buyers);

    update_user_meta( $user_id, 'visit_as', 'buyer' );
    update_user_meta( $user_id, 'buyer_id', $buyer_id );
    update_post_meta( $buyers, 'buyer_profile_name', $user_info->display_name);

    $sellers = array(
        'post_title' => sanitize_text_field($user_info->user_login),
        'post_status' => 'publish',
        'post_author' => $user_id,
        'post_type' => 'sellers'
    );

    $seller_id = wp_insert_post($sellers);

    update_user_meta( $user_id, 'seller_id', $seller_id );
    update_post_meta( $sellers, 'seller_profile_name', $user_info->display_name);
    update_post_meta( $sellers, 'is_seller_verified', 0);
}
add_action( 'user_register', 'prolancer_user_register' );

// Delete user
function prolancer_delete_user( $user_id ) {

    $user_posts = get_posts(array (
        'numberposts' => -1,
        'post_type' => 'any',
        'author' => $user_id
    ));

    if (empty($user_posts)) return;

    // delete all the user posts
    foreach ($user_posts as $user_post) {
        wp_delete_post($user_post->ID, true);
    }
}
add_action( 'delete_user', 'prolancer_delete_user' );

// See http://codex.wordpress.org/Plugin_API/Filter_Reference/cron_schedules
function prolancer_every_three_minutes( $schedules ) {
    $schedules['every_three_minutes'] = array(
            'interval'  => 60 * 3,
            'display'   => __( 'Every 3 Minutes', 'prolancer' )
    );
    return $schedules;
}
add_filter( 'cron_schedules', 'prolancer_every_three_minutes' );

// Schedule an action if it's not already scheduled
if ( ! wp_next_scheduled( 'prolancer_every_three_minutes' ) ) {
    wp_schedule_event( time(), 'every_three_minutes', 'prolancer_every_three_minutes' );
}

// Hook into that action that'll fire every three minutes
function prolancer_delete_wallet_every_three_minutes() {
    $products = get_posts( array(
        'post_type'      => 'product',
        'product_cat'    => 'wallet-deleted'
    ));
    foreach ($products as $product) {
        // Delete all products.
        wp_delete_post( $product->ID, true);
    }
}
add_action( 'prolancer_every_three_minutes', 'prolancer_delete_wallet_every_three_minutes' );

// retrieves the attachment ID from the file URL
function prolancer_get_image_id($image_url) {
    global $wpdb;
    $attachment = $wpdb->get_col($wpdb->prepare("SELECT ID FROM $wpdb->posts WHERE guid='%s';", $image_url )); 
    if ($attachment) {
        return $attachment[0];
    }
}

// Profile Views
function prolancer_profile_views($id) {
    $today =  date('Y-m-d',current_time('timestamp', 0));
    $monthly_view = get_post_meta($id, 'prolancer_'.get_post_type( $id ).'_views', true);
    if($monthly_view =='' || !is_array($monthly_view)){
        $monthly_view         =   array();
        $monthly_view[$today] = 1;
    } else {
        if( !isset($monthly_view[$today] ) ){
            if( count($monthly_view) > 30 ) {
                array_shift($monthly_view);
            }
            $monthly_view[$today]=1;
        } else {
            $monthly_view[$today]=intval($monthly_view[$today])+1;
        }
    }
    update_post_meta($id, 'prolancer_'.get_post_type( $id ).'_views', $monthly_view);   
}

// Generate views data by id
function prolancer_generate_views_data_by_id($id) {
    $data = get_post_meta($id, 'prolancer_'.get_post_type( $id ).'_views', true);

    wp_localize_script( 'prolancer-app', 'prolancer_'.get_post_type( $id ).'_views', array('data' => $data));
}
add_action( 'wp_enqueue_scripts', 'prolancer_generate_views_data_by_id' );

// Seller reviews
function prolancer_seller_reviews($id){
    global $wpdb;
    $review_table ='prolancer_reviews';

    if($wpdb->get_var("SHOW TABLES LIKE '$review_table'") == $review_table) {
      $query = "SELECT * FROM ".$review_table." WHERE `seller_id` = '" . $id . "'";
      return $wpdb->get_results($query, ARRAY_A);
    }
}

// Remove trash button
function prolancer_remove_trash_button( $caps, $cap, $user_id, $args ) {
    // Nothing to do
    if( 'delete_post' !== $cap || empty( $args[0] ) )
        return $caps;

    // Target the post types
    if( in_array( get_post_type( $args[0] ), [ 'sellers', 'buyers', 'payouts', 'disputes','verification' ], true ) )
        $caps[] = 'do_not_allow';       

    return $caps;    
}

add_filter( 'map_meta_cap', 'prolancer_remove_trash_button', 10, 4);

// Remove menu items from end users
function prolancer_remove_menu_items() {
    if( !current_user_can( 'administrator' ) ){
        remove_menu_page( 'edit.php?post_type=sellers' );
        remove_menu_page( 'edit.php?post_type=buyers' );
        remove_menu_page( 'edit.php?post_type=payouts' );
        remove_menu_page( 'edit.php?post_type=disputes' );
        remove_menu_page( 'edit.php?post_type=verification' );
    };
}
add_action( 'admin_menu', 'prolancer_remove_menu_items' );

// Verification
function prolancer_verification() {
    $verification = json_decode( get_user_meta( get_the_author_meta( 'ID' ), 'verification' , true ), true );
    if ($verification) {
        if ($verification['verified'] == 'yes') {
            echo '<i class="fas fa-check-circle verified" title="'.esc_attr__('Verified','prolancer').'"></i>';
        }
    }
}

// Notifications
function prolancer_notifications($sender_id, $receiver_id, $type, $title, $image, $url) {  
    global $wpdb;
    $wpdb->insert('prolancer_notifications',array(
        'timestamp' => current_time('mysql'),
        'updated_on' => current_time('mysql'),
        'type' => $type,
        'title' => $title,
        'image' => $image,
        'url' => $url,
        'sender_id' => $sender_id,
        'receiver_id' => $receiver_id,
        'read' => 'false'
    ));
}

// Get author mail by post id
function prolancer_get_author_mail($post_id){
    return get_the_author_meta( 'user_email', get_post_field( 'post_author', $post_id ) );
}

// Publish disputes
function prolancer_publish_disputes($id, $post){

    $author = $post->post_author;
    $buyer_id = $post->dispute_buyer_id;
    $seller_id = $post->dispute_seller_id;
    $dispute_price = $post->dispute_price;
        
    $buyer_user_id = get_users(array( 
      'meta_key' => 'buyer_id', 
      'meta_value' => $buyer_id
    ))[0]->data->ID;

    $buyer_wallet_balance = get_user_meta( $buyer_user_id, 'wallet_balance', true );
    update_user_meta( $buyer_user_id, 'wallet_balance', $buyer_wallet_balance+$dispute_price);

    //prolancer_notifications($sender_id, $receiver_id, $type, $title, $image, $url)
    prolancer_notifications(
      $seller_id, 
      $buyer_id,
      'other',
      esc_html__( 'Your dispute finished and you have received a refund of ', 'prolancer' ).prolancer_get_currency_symbol($dispute_price),
      esc_url( get_avatar_url( $author ) ), 
      esc_url(prolancer_get_page_url_by_template('prolancer-dashboard.php').'=disputes')
    );

    //Send the notification
    wp_mail(prolancer_get_author_mail($buyer_id), esc_html__( 'Your dispute finished', 'prolancer' ), esc_html__( 'Your dispute finished and you have received a refund of ', 'prolancer' ).prolancer_get_currency_symbol($dispute_price));

    wp_update_post( array( 'ID' => $id, 'post_status' => 'private' ));
}
add_action('publish_disputes', 'prolancer_publish_disputes', 10, 2);

// Publish projects
function prolancer_publish_projects($id, $post) {
    global $prolancer_opt;

    $email_on_project_approval = !empty( $prolancer_opt['email_on_project_approval'] ) ? $prolancer_opt['email_on_project_approval'] : '';
    $email_on_project_approval_subject = !empty( $prolancer_opt['email_on_project_approval_subject'] ) ? $prolancer_opt['email_on_project_approval_subject'] : '';
    $email_on_project_approval_content = !empty( $prolancer_opt['email_on_project_approval_content'] ) ? $prolancer_opt['email_on_project_approval_content'] : '';
    $prolancer_project_featuring_fee = !empty( $prolancer_opt['prolancer_project_featuring_fee'] ) ? $prolancer_opt['prolancer_project_featuring_fee'] : 0;

    $author = $post->post_author; 
    $wallet_balance = get_user_meta( $author, 'wallet_balance', true );
    
    if ($post->featured_project == true) {
        if (get_post_meta( $id, 'project_update', true) != true) {
            update_user_meta( $author, 'wallet_balance', $wallet_balance-$prolancer_project_featuring_fee);
            update_post_meta( $id, 'project_update', true);
        }
    }

    if ($email_on_project_approval) {
      // wp_mail( $to, $subject, $message, $headers)
      wp_mail( 
        get_userdata($author)->user_email, 
        $email_on_project_approval_subject,
        str_replace(
          array( '{{site_name}}', '{{buyer_name}}', '{{project_link}}', '{{project_title}}'),
          array(wp_specialchars_decode(get_bloginfo('name'),ENT_QUOTES), get_userdata($author)->display_name,get_the_permalink($id), get_the_title($id)), 
          $email_on_project_approval_content
        ), 
        array('Content-Type: text/html; charset=UTF-8', 'From: '.get_option('admin_email'))
      );    
    }
    
}
add_action('publish_projects', 'prolancer_publish_projects', 10, 2);

// Publish services
function prolancer_publish_services($id, $post) {
    global $prolancer_opt;
    
    $email_on_service_approval = !empty( $prolancer_opt['email_on_service_approval'] ) ? $prolancer_opt['email_on_service_approval'] : '';
    $email_on_service_approval_subject = !empty( $prolancer_opt['email_on_service_approval_subject'] ) ? $prolancer_opt['email_on_service_approval_subject'] : '';
    $email_on_service_approval_content = !empty( $prolancer_opt['email_on_service_approval_content'] ) ? $prolancer_opt['email_on_service_approval_content'] : '';
    $prolancer_service_featuring_fee = !empty( $prolancer_opt['prolancer_service_featuring_fee'] ) ? $prolancer_opt['prolancer_service_featuring_fee'] : 0;

    $author = $post->post_author;
    $wallet_balance = get_user_meta( $author, 'wallet_balance', true );

    if ($post->featured_service == true) {
        if (get_post_meta( $id, 'service_update', true) != true) {
            update_user_meta( $author, 'wallet_balance', $wallet_balance-$prolancer_service_featuring_fee);
            update_post_meta( $id, 'service_update', true);
        }
    }

    if ($email_on_service_approval) {
      // wp_mail( $to, $subject, $message, $headers)
      wp_mail( 
        get_userdata($author)->user_email, 
        $email_on_service_approval_subject,
        str_replace(
          array( '{{site_name}}', '{{seller_name}}', '{{service_link}}', '{{service_title}}'),
          array(wp_specialchars_decode(get_bloginfo('name'),ENT_QUOTES), get_userdata($author)->display_name,get_the_permalink($id), get_the_title($id)), 
          $email_on_service_approval_content
        ), 
        array('Content-Type: text/html; charset=UTF-8', 'From: '.get_option('admin_email'))
      );    
    }
}
add_action('publish_services', 'prolancer_publish_services', 10, 2);

// Badges
function prolancer_badges($id = null){

    if ($id) {
        $user_id = $id;
    } else {
        $user_id = get_the_ID();
    }

    global $wpdb;
    global $prolancer_opt;

    $id_verified = !empty( $prolancer_opt['id_verified'] ) ? $prolancer_opt['id_verified'] : '';
    $id_verified_badge = !empty( $prolancer_opt['id_verified_badge'] ) ? $prolancer_opt['id_verified_badge']['url'] : '';
    $new_member = !empty( $prolancer_opt['new_member'] ) ? $prolancer_opt['new_member'] : '';
    $new_member_badge = !empty( $prolancer_opt['new_member_badge'] ) ? $prolancer_opt['new_member_badge']['url'] : '';
    $buyer_first_order = !empty( $prolancer_opt['buyer_first_order'] ) ? $prolancer_opt['buyer_first_order'] : '';
    $buyer_first_order_badge = !empty( $prolancer_opt['buyer_first_order_badge'] ) ? $prolancer_opt['buyer_first_order_badge']['url'] : '';
    $seller_first_order_received = !empty( $prolancer_opt['seller_first_order_received'] ) ? $prolancer_opt['seller_first_order_received'] : '';
    $seller_first_order_received_badge = !empty( $prolancer_opt['seller_first_order_received_badge'] ) ? $prolancer_opt['seller_first_order_received_badge']['url'] : '';
    $seller_level_1 = !empty( $prolancer_opt['seller_level_1'] ) ? $prolancer_opt['seller_level_1'] : '';
    $seller_level_1_badge = !empty( $prolancer_opt['seller_level_1_badge'] ) ? $prolancer_opt['seller_level_1_badge']['url'] : '';
    $seller_level_1_earnings = !empty( $prolancer_opt['seller_level_1_earnings'] ) ? $prolancer_opt['seller_level_1_earnings'] : '';
    $seller_level_2 = !empty( $prolancer_opt['seller_level_2'] ) ? $prolancer_opt['seller_level_2'] : '';
    $seller_level_2_badge = !empty( $prolancer_opt['seller_level_2_badge'] ) ? $prolancer_opt['seller_level_2_badge']['url'] : '';
    $seller_level_2_earnings = !empty( $prolancer_opt['seller_level_2_earnings'] ) ? $prolancer_opt['seller_level_2_earnings'] : '';
    $seller_level_3 = !empty( $prolancer_opt['seller_level_3'] ) ? $prolancer_opt['seller_level_3'] : '';
    $seller_level_3_badge = !empty( $prolancer_opt['seller_level_3_badge'] ) ? $prolancer_opt['seller_level_3_badge']['url'] : '';
    $seller_level_3_earnings = !empty( $prolancer_opt['seller_level_3_earnings'] ) ? $prolancer_opt['seller_level_3_earnings'] : '';
    $buyer_level_1 = !empty( $prolancer_opt['buyer_level_1'] ) ? $prolancer_opt['buyer_level_1'] : '';
    $buyer_level_1_badge = !empty( $prolancer_opt['buyer_level_1_badge'] ) ? $prolancer_opt['buyer_level_1_badge']['url'] : '';
    $buyer_level_1_spent = !empty( $prolancer_opt['buyer_level_1_spent'] ) ? $prolancer_opt['buyer_level_1_spent'] : '';
    $buyer_level_2 = !empty( $prolancer_opt['buyer_level_2'] ) ? $prolancer_opt['buyer_level_2'] : '';
    $buyer_level_2_badge = !empty( $prolancer_opt['buyer_level_2_badge'] ) ? $prolancer_opt['buyer_level_2_badge']['url'] : '';
    $buyer_level_2_spent = !empty( $prolancer_opt['buyer_level_2_spent'] ) ? $prolancer_opt['buyer_level_2_spent'] : '';
    $buyer_level_3 = !empty( $prolancer_opt['buyer_level_3'] ) ? $prolancer_opt['buyer_level_3'] : '';
    $buyer_level_3_badge = !empty( $prolancer_opt['buyer_level_3_badge'] ) ? $prolancer_opt['buyer_level_3_badge']['url'] : '';
    $buyer_level_3_spent = !empty( $prolancer_opt['buyer_level_3_spent'] ) ? $prolancer_opt['buyer_level_3_spent'] : '';
    $new_member_days = !empty( $prolancer_opt['new_member_days'] ) ? $prolancer_opt['new_member_days'] : '';
    $current_day = number_format(abs(strtotime( wp_date(get_userdata(get_the_author_meta( 'ID' ))->user_registered)) - current_time('timestamp'))/60/60/24);
    $verification = json_decode( get_user_meta( get_the_author_meta( 'ID' ), 'verification' , true ), true );

    $complete_project_query = "SELECT * FROM prolancer_project_proposals WHERE `buyer_id` = '" . $user_id . "' AND status='complete'";
    $complete_projects = $wpdb->get_results($complete_project_query, ARRAY_A);  

    $complete_service_query = "SELECT * FROM prolancer_service_orders WHERE `seller_id` = '" . $user_id . "' AND status='complete'";
    $complete_services = $wpdb->get_results($complete_service_query, ARRAY_A);  

    // Total earnings
    $earnings = new WP_Query( array( 
        'post_type' => 'payouts',
        'author' => get_the_author_meta( 'ID' ),
        'post_status' => array( 'pending', 'publish', 'private' ),
        'posts_per_page' => -1
    ));

    $total_earnings = (int)'';

    /* Start the Loop */
    if ( $earnings->have_posts()) {
        while ( $earnings->have_posts()) : $earnings->the_post();
            $total_earnings += get_post_meta( get_the_ID(), 'payout_amount' , true );
        endwhile;
		wp_reset_postdata();
    }

    if(class_exists( 'WooCommerce' )){
        //Total deposit 
        $deposits = get_posts(array(
            'meta_key' => '_customer_user',
            'meta_value' => get_the_author_meta( 'ID' ),
            'post_type' => wc_get_order_types('view-orders'),
            'posts_per_page' => -1,
            'post_status' => 'wc-completed'
        ));

        $total_deposits = (int)'';

        // Start the Loop 
        foreach ($deposits as $deposit) {
        $deposit = wc_get_order($deposit);
            $deposit_items = $deposit->get_items();
            foreach ( $deposit_items as $item ) {
                $product_name = $item->get_name();
            }

            if ($product_name == 'Recharge wallet') {
                $total_deposits += $deposit->get_total();
            }
        }
    } ?>
    
    <ul class="list-inline mt-2 mb-2 badges">
        <?php if ($id_verified and $verification) { 
            if ($verification['verified'] == 'yes') {?>
                <li class="list-inline-item"><img src="<?php echo esc_url( $id_verified_badge ); ?>" title="<?php echo esc_attr__('ID Verified','prolancer'); ?>" alt="badge"></li>
            <?php }
        }

        if ($new_member and $current_day<$new_member_days) {?>
            <li class="list-inline-item"><img src="<?php echo esc_url( $new_member_badge ); ?>" title="<?php echo esc_attr__('New member','prolancer'); ?>" alt="badge"></li>
        <?php
        }

        if ($buyer_first_order and count($complete_projects)>0) {?>
            <li class="list-inline-item"><img src="<?php echo esc_url( $buyer_first_order_badge ); ?>" title="<?php echo esc_attr__('Spent money for hiring','prolancer'); ?>" alt="badge"></li>
        <?php
        }

        if ($seller_first_order_received and count($complete_services)>0) {?>
            <li class="list-inline-item"><img src="<?php echo esc_url( $seller_first_order_received_badge ); ?>" title="<?php echo esc_attr__('Completed first order','prolancer'); ?>" alt="badge"></li>
        <?php
        }

        if ($seller_level_3 and $total_earnings>=$seller_level_3_earnings) {?>
            <li class="list-inline-item"><img src="<?php echo esc_url( $seller_level_3_badge ); ?>" title="<?php echo esc_attr__('Seller Level 3: Has sold ','prolancer') .prolancer_get_currency_symbol($seller_level_3_earnings).esc_attr__('+ On '.get_bloginfo( 'name', 'display' ),'prolancer'); ?>" alt="badge"></li>
        <?php
        } elseif ($seller_level_2 and $total_earnings>=$seller_level_2_earnings) {?>
            <li class="list-inline-item"><img src="<?php echo esc_url( $seller_level_2_badge ); ?>" title="<?php echo esc_attr__('Seller Level 2: Has sold ','prolancer') .prolancer_get_currency_symbol($seller_level_2_earnings).esc_attr__('+ On '.get_bloginfo( 'name', 'display' ),'prolancer'); ?>" alt="badge"></li>
        <?php
        } elseif ($seller_level_1 and $total_earnings>=$seller_level_1_earnings) {?>
            <li class="list-inline-item"><img src="<?php echo esc_url( $seller_level_1_badge ); ?>" title="<?php echo esc_attr__('Seller Level 1: Has sold ','prolancer') .prolancer_get_currency_symbol($seller_level_1_earnings).esc_attr__('+ On '.get_bloginfo( 'name', 'display' ),'prolancer'); ?>" alt="badge"></li>
        <?php
        }
        
        if(class_exists( 'WooCommerce' )){
            if ($buyer_level_3 and $total_deposits>=$buyer_level_3_spent) {?>
                <li class="list-inline-item"><img src="<?php echo esc_url( $buyer_level_3_badge ); ?>" title="<?php echo esc_attr__('Buyer Level 3: Has spent ','prolancer') .prolancer_get_currency_symbol($buyer_level_3_spent).esc_attr__('+ On '.get_bloginfo( 'name', 'display' ),'prolancer'); ?>" alt="badge"></li>
            <?php
            } elseif ($buyer_level_2 and $total_deposits>=$buyer_level_2_spent) {?>
                <li class="list-inline-item"><img src="<?php echo esc_url( $buyer_level_2_badge ); ?>" title="<?php echo esc_attr__('Buyer Level 2: Has spent ','prolancer') .prolancer_get_currency_symbol($buyer_level_2_spent).esc_attr__('+ On '.get_bloginfo( 'name', 'display' ),'prolancer'); ?>" alt="badge"></li>
            <?php
            } elseif ($buyer_level_1 and $total_deposits>=$buyer_level_1_spent) {?>
                <li class="list-inline-item"><img src="<?php echo esc_url( $buyer_level_1_badge ); ?>" title="<?php echo esc_attr__('Buyer Level 1: Has spent ','prolancer') .prolancer_get_currency_symbol($buyer_level_1_spent).esc_attr__('+ On '.get_bloginfo( 'name', 'display' ),'prolancer'); ?>" alt="badge"></li>
            <?php
            }
        } ?>
    </ul>    
    <?php
}

// All category ids
function prolancer_get_category_ids($category){
  $all_categories = get_terms( array('taxonomy' => $category,'hide_empty' => false, 'parent' => 0));
  if (is_wp_error($all_categories)) {
      return [];
  }
  foreach ($all_categories as $key => $term) {
      $options[$key] = $term->term_id;
  }
  return $options;
}

// Deposit fee
function prolancer_woocommerce_deposit_surcharge() {
    global $woocommerce;
    global $prolancer_opt;

    $prolancer_deposit_fee = !empty( $prolancer_opt['prolancer_deposit_fee'] ) ? $prolancer_opt['prolancer_deposit_fee'] : 0;

    if ( is_admin() && ! defined( 'DOING_AJAX' ) )
        return;

    $percentage = $prolancer_deposit_fee/100;
    $surcharge = ( $woocommerce->cart->cart_contents_total + $woocommerce->cart->shipping_total ) * $percentage;    
    $woocommerce->cart->add_fee( esc_html__('Deposit Fee','prolancer'), $surcharge, true, '' );
}
add_action( 'woocommerce_cart_calculate_fees','prolancer_woocommerce_deposit_surcharge' );